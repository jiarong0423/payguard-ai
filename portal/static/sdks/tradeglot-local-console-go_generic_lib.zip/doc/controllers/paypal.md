# Paypal

PayPal Sandbox connection, disputes and the gated evidence request (local console only).

```go
paypalController := client.PaypalController()
```

## Class Name

`PaypalController`

## Methods

* [Post Paypal Connect](../../doc/controllers/paypal.md#post-paypal-connect)
* [Get Paypal Disputes](../../doc/controllers/paypal.md#get-paypal-disputes)
* [Post Paypal Disputes Add Tracking](../../doc/controllers/paypal.md#post-paypal-disputes-add-tracking)
* [Post Paypal Disputes Provide Evidence](../../doc/controllers/paypal.md#post-paypal-disputes-provide-evidence)
* [Get Paypal Disputes Dispute Id](../../doc/controllers/paypal.md#get-paypal-disputes-dispute-id)
* [Post Paypal Invoices Draft](../../doc/controllers/paypal.md#post-paypal-invoices-draft)
* [Post Paypal Invoices Review](../../doc/controllers/paypal.md#post-paypal-invoices-review)
* [Get Paypal Status](../../doc/controllers/paypal.md#get-paypal-status)
* [Post Paypal Webhooks Verify](../../doc/controllers/paypal.md#post-paypal-webhooks-verify)


# Post Paypal Connect

Connect. Local console route POST /api/v1/paypal/connect on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostPaypalConnect(
    ctx context.Context,
    body interface{}) (
    models.ApiResponse[models.PaypalStatusResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `interface{}` | Body, Required | JSON body for: Connect. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaypalStatusResponse](../../doc/models/paypal-status-response.md).

## Example Usage

```go
ctx := context.Background()

body := interface{}("")

apiResponse, err := paypalController.PostPaypalConnect(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes

List Disputes. Local console route GET /api/v1/paypal/disputes on synthetic data; advisory only.

```go
GetPaypalDisputes(
    ctx context.Context) (
    models.ApiResponse[models.DisputeListResponse],
    error)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.DisputeListResponse](../../doc/models/dispute-list-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := paypalController.GetPaypalDisputes(ctx)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Add Tracking

Add Tracking. Local console route POST /api/v1/paypal/disputes/add-tracking on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostPaypalDisputesAddTracking(
    ctx context.Context,
    body models.AddTrackingRequest) (
    models.ApiResponse[models.AddTrackingResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AddTrackingRequest`](../../doc/models/add-tracking-request.md) | Body, Required | JSON body for: Add Tracking. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AddTrackingResponse](../../doc/models/add-tracking-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.AddTrackingRequest{
    CaseRef:      "case-ref-001",
    DisputeId:    "PP-R-BNP-XXXX7173",
}

apiResponse, err := paypalController.PostPaypalDisputesAddTracking(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Provide Evidence

Provide Evidence. Local console route POST /api/v1/paypal/disputes/provide-evidence on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostPaypalDisputesProvideEvidence(
    ctx context.Context,
    body models.ProvideEvidenceRequest) (
    models.ApiResponse[models.ProvideEvidenceResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.ProvideEvidenceRequest`](../../doc/models/provide-evidence-request.md) | Body, Required | JSON body for: Provide Evidence. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ProvideEvidenceResponse](../../doc/models/provide-evidence-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.ProvideEvidenceRequest{
    CaseRef:      "case-ref-001",
    DisputeId:    "PP-R-BNP-XXXX7173",
    Submit:       models.ToPointer(false),
}

apiResponse, err := paypalController.PostPaypalDisputesProvideEvidence(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes Dispute Id

Get Dispute. Local console route GET /api/v1/paypal/disputes/{dispute_id} on synthetic data; advisory only.

```go
GetPaypalDisputesDisputeId(
    ctx context.Context,
    disputeId string) (
    models.ApiResponse[models.DisputeDetailResponse],
    error)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disputeId` | `string` | Template, Required | Dispute id. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.DisputeDetailResponse](../../doc/models/dispute-detail-response.md).

## Example Usage

```go
ctx := context.Background()

disputeId := "PP-R-BNP-XXXX7173"

apiResponse, err := paypalController.GetPaypalDisputesDisputeId(ctx, disputeId)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Draft

Invoice Draft. Local console route POST /api/v1/paypal/invoices/draft on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostPaypalInvoicesDraft(
    ctx context.Context,
    body models.InvoiceDraftRequest) (
    models.ApiResponse[models.InvoiceDraftResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.InvoiceDraftRequest`](../../doc/models/invoice-draft-request.md) | Body, Required | JSON body for: Invoice Draft. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.InvoiceDraftResponse](../../doc/models/invoice-draft-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.InvoiceDraftRequest{
    Amount:        "amount8",
    Currency:      models.CurrencyEnum_USD,
    Description:   "description4",
    PayloadDigest: "payload_digest4",
    ReviewToken:   "review_token4",
}

apiResponse, err := paypalController.PostPaypalInvoicesDraft(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Review

Invoice Review. Local console route POST /api/v1/paypal/invoices/review on synthetic data; advisory only.

```go
PostPaypalInvoicesReview(
    ctx context.Context,
    body models.InvoiceReviewRequest) (
    models.ApiResponse[models.InvoiceReviewResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.InvoiceReviewRequest`](../../doc/models/invoice-review-request.md) | Body, Required | JSON body for: Invoice Review. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.InvoiceReviewResponse](../../doc/models/invoice-review-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.InvoiceReviewRequest{
    Amount:               "42.50",
    ConfirmSandboxDraft:  false,
    Currency:             models.CurrencyEnum_USD,
    Description:          "example",
}

apiResponse, err := paypalController.PostPaypalInvoicesReview(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Status

Paypal Status. Local console route GET /api/v1/paypal/status on synthetic data; advisory only.

```go
GetPaypalStatus(
    ctx context.Context) (
    models.ApiResponse[models.PaypalStatusResponse],
    error)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaypalStatusResponse](../../doc/models/paypal-status-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := paypalController.GetPaypalStatus(ctx)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Webhooks Verify

Verify Webhook. Local console route POST /api/v1/paypal/webhooks/verify on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostPaypalWebhooksVerify(
    ctx context.Context) (
    models.ApiResponse[models.WebhookVerifyResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.WebhookVerifyResponse](../../doc/models/webhook-verify-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := paypalController.PostPaypalWebhooksVerify(ctx)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

