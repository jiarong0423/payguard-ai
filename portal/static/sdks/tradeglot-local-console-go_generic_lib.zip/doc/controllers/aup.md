# Aup

Acceptable-use keyword check and the invoice review that follows it.

```go
aupController := client.AupController()
```

## Class Name

`AupController`

## Methods

* [Post Aup Acknowledge](../../doc/controllers/aup.md#post-aup-acknowledge)
* [Post Aup Category Signal](../../doc/controllers/aup.md#post-aup-category-signal)
* [Post Aup Product Reference](../../doc/controllers/aup.md#post-aup-product-reference)
* [Post Aup Product Reference Confirm](../../doc/controllers/aup.md#post-aup-product-reference-confirm)
* [Post Aup Review](../../doc/controllers/aup.md#post-aup-review)


# Post Aup Acknowledge

Acknowledge Aup. Local console route POST /api/v1/aup/acknowledge on synthetic data; advisory only.

```go
PostAupAcknowledge(
    ctx context.Context,
    body models.AupAcknowledgeRequest) (
    models.ApiResponse[models.AupAcknowledgeResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AupAcknowledgeRequest`](../../doc/models/aup-acknowledge-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AupAcknowledgeResponse](../../doc/models/aup-acknowledge-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.AupAcknowledgeRequest{
    Choice:            models.ChoiceEnum_CANCEL,
    DescriptionDigest: "description_digest4",
    EvaluationId:      "evaluation_id0",
}

apiResponse, err := aupController.PostAupAcknowledge(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Category Signal

Aup Category Signal. Local console route POST /api/v1/aup/category-signal on synthetic data; advisory only.

```go
PostAupCategorySignal(
    ctx context.Context,
    body models.AupCategorySignalRequest) (
    models.ApiResponse[models.AupCategorySignalResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AupCategorySignalRequest`](../../doc/models/aup-category-signal-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AupCategorySignalResponse](../../doc/models/aup-category-signal-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.AupCategorySignalRequest{
    Description:  "description4",
    EvaluationId: "evaluation_id0",
}

apiResponse, err := aupController.PostAupCategorySignal(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference

Aup Product Reference. Local console route POST /api/v1/aup/product-reference on synthetic data; advisory only.

```go
PostAupProductReference(
    ctx context.Context,
    body models.ProductReferenceRequest) (
    models.ApiResponse[models.ProductReferenceResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.ProductReferenceRequest`](../../doc/models/product-reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ProductReferenceResponse](../../doc/models/product-reference-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.ProductReferenceRequest{
    Description:  "description4",
    EvaluationId: "evaluation_id0",
}

apiResponse, err := aupController.PostAupProductReference(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference Confirm

Aup Product Confirm. Local console route POST /api/v1/aup/product-reference/confirm on synthetic data; advisory only.

```go
PostAupProductReferenceConfirm(
    ctx context.Context,
    body models.ProductConfirmRequest) (
    models.ApiResponse[models.ProductConfirmResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.ProductConfirmRequest`](../../doc/models/product-confirm-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ProductConfirmResponse](../../doc/models/product-confirm-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.ProductConfirmRequest{
    Description:  "description4",
    EvaluationId: "evaluation_id0",
    ProductId:    models.ProductConfirmRequestProductIdContainer.FromString("String3"),
}

apiResponse, err := aupController.PostAupProductReferenceConfirm(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Review

Aup. Local console route POST /api/v1/aup/review on synthetic data; advisory only.

```go
PostAupReview(
    ctx context.Context,
    body models.AupRequest) (
    models.ApiResponse[models.AupResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AupRequest`](../../doc/models/aup-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AupResponse](../../doc/models/aup-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.AupRequest{
    Description: "description4",
}

apiResponse, err := aupController.PostAupReview(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

