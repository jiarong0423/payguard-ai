# References

Pinned official references and search over them.

```go
referencesController := client.ReferencesController()
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```go
PostReferencesSearch(
    ctx context.Context,
    body models.ReferenceRequest) (
    models.ApiResponse[models.ReferenceResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ReferenceResponse](../../doc/models/reference-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.ReferenceRequest{
    CaseStage:              models.ToPointer(models.CaseStage2Enum_ANY),
    Jurisdiction:           "US",
    Limit:                  models.ToPointer(3),
    Query:                  "query6",
    RequireKnownSourceDate: models.ToPointer(false),
    Theme:                  models.ThemeEnum_DISPUTEMEDIATION,
}

apiResponse, err := referencesController.PostReferencesSearch(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

