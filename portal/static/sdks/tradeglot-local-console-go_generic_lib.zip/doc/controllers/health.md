# Health

Liveness check.

```go
healthController := client.HealthController()
```

## Class Name

`HealthController`


# Get Health

Health. Local console route GET /api/v1/health on synthetic data; advisory only.

:information_source: **Note** This endpoint does not require authentication.

```go
GetHealth(
    ctx context.Context) (
    models.ApiResponse[models.HealthResponse],
    error)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.HealthResponse](../../doc/models/health-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := healthController.GetHealth(ctx)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "mode": "demo",
  "source": "synthetic",
  "status": "ok",
  "version": "0.0.0-example"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

