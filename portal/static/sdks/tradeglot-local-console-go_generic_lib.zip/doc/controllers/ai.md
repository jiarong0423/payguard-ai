# Ai

Evidence brief (local console with a model profile only).

```go
aiController := client.AiController()
```

## Class Name

`AiController`

## Methods

* [Post Ai Evidence Brief](../../doc/controllers/ai.md#post-ai-evidence-brief)
* [Get Ai Usage](../../doc/controllers/ai.md#get-ai-usage)


# Post Ai Evidence Brief

Evidence Brief. Local console route POST /api/v1/ai/evidence-brief on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```go
PostAiEvidenceBrief(
    ctx context.Context,
    body models.AiBriefHttpRequest) (
    models.ApiResponse[models.AiBriefResponse],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.AiBriefHttpRequest`](../../doc/models/ai-brief-http-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AiBriefResponse](../../doc/models/ai-brief-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.AiBriefHttpRequest{
    Stage:   models.StageEnum_VELOCITYGUARD,
}

apiResponse, err := aiController.PostAiEvidenceBrief(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        case *errors.HTTPValidationError:
            log.Fatalln("HTTPValidationErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Ai Usage

(optimise r24) This session's AI calls: stage, model, tokens, latency, estimated cost. No prompt or reply
text is ever stored; the hosted demo makes no model call and answers an empty list.

```go
GetAiUsage(
    ctx context.Context) (
    models.ApiResponse[models.AiUsageResponse],
    error)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AiUsageResponse](../../doc/models/ai-usage-response.md).

## Example Usage

```go
ctx := context.Background()

apiResponse, err := aiController.GetAiUsage(ctx)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

