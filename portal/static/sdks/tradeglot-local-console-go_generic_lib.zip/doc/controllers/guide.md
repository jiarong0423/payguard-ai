# Guide

Evidence guide: gap filling over closed form items.

```go
guideController := client.GuideController()
```

## Class Name

`GuideController`

## Methods

* [Post Guide Form](../../doc/controllers/guide.md#post-guide-form)
* [Post Guide Review](../../doc/controllers/guide.md#post-guide-review)
* [Post Guide Start](../../doc/controllers/guide.md#post-guide-start)
* [Get Guide State](../../doc/controllers/guide.md#get-guide-state)
* [Post Guide Turn](../../doc/controllers/guide.md#post-guide-turn)


# Post Guide Form

Guide Form. Local console route POST /api/v1/guide/form on synthetic data; advisory only.

```go
PostGuideForm(
    ctx context.Context,
    body models.GuideFormRequest) (
    models.ApiResponse[models.GuideStateResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GuideFormRequest`](../../doc/models/guide-form-request.md) | Body, Required | JSON body for: Guide Form. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GuideStateResponse](../../doc/models/guide-state-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.GuideFormRequest{
}

apiResponse, err := guideController.PostGuideForm(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Review

Guide Review. Local console route POST /api/v1/guide/review on synthetic data; advisory only.

```go
PostGuideReview(
    ctx context.Context,
    body models.GuideReviewRequest) (
    models.ApiResponse[models.GuideStateResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GuideReviewRequest`](../../doc/models/guide-review-request.md) | Body, Required | JSON body for: Guide Review. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GuideStateResponse](../../doc/models/guide-state-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.GuideReviewRequest{
}

apiResponse, err := guideController.PostGuideReview(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Start

Guide Start. Local console route POST /api/v1/guide/start on synthetic data; advisory only.

```go
PostGuideStart(
    ctx context.Context,
    body models.GuideStartRequest) (
    models.ApiResponse[models.GuideStateResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GuideStartRequest`](../../doc/models/guide-start-request.md) | Body, Required | JSON body for: Guide Start. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GuideStateResponse](../../doc/models/guide-state-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.GuideStartRequest{
    Scenario:  models.Scenario2Enum_PREFLIGHT,
}

apiResponse, err := guideController.PostGuideStart(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Guide State

Guide State. Local console route GET /api/v1/guide/state on synthetic data; advisory only.

```go
GetGuideState(
    ctx context.Context,
    scenario *models.GetGuideStateScenario) (
    models.ApiResponse[models.GuideStateResponse],
    error)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`*models.GetGuideStateScenario`](../../doc/models/containers/get-guide-state-scenario.md) | Query, Optional | This is a container for any-of cases. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GuideStateResponse](../../doc/models/guide-state-response.md).

## Example Usage

```go
ctx := context.Background()

scenario := models.GetGuideStateScenarioContainer.FromScenario1(models.Scenario1Enum_PREFLIGHT)

apiResponse, err := guideController.GetGuideState(ctx, &scenario)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Turn

Guide Turn. Local console route POST /api/v1/guide/turn on synthetic data; advisory only.

```go
PostGuideTurn(
    ctx context.Context,
    body models.GuideTurnRequest) (
    models.ApiResponse[models.GuideStateResponse],
    error)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GuideTurnRequest`](../../doc/models/guide-turn-request.md) | Body, Required | JSON body for: Guide Turn. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.GuideStateResponse](../../doc/models/guide-state-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.GuideTurnRequest{
    Text:     "example",
}

apiResponse, err := guideController.PostGuideTurn(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.ErrorBody:
            log.Fatalln("ErrorBodyException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

