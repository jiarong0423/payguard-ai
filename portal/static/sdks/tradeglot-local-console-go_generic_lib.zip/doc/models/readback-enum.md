
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADDTRACKINGPREVIEW` |
| `ADDTRACKINGSUBMITTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    readback := models.ReadbackEnum_ADDTRACKINGPREVIEW

}
```

