
# Dispute Evidence Row

DisputeEvidenceRow.

## Structure

`DisputeEvidenceRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`*models.DisputeEvidenceRowAction`](../../doc/models/containers/dispute-evidence-row-action.md) | Optional | This is a container for any-of cases. |
| `Date` | [`*models.DisputeEvidenceRowDate`](../../doc/models/containers/dispute-evidence-row-date.md) | Optional | This is a container for any-of cases. |
| `EvidenceType` | `string` | Required | Evidence type.<br><br>**Constraints**: *Pattern*: `^[A-Z][A-Z0-9_]{0,63}$` |
| `Source` | [`models.Source3Enum`](../../doc/models/source-3-enum.md) | Required | Source. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    disputeEvidenceRow := models.DisputeEvidenceRow{
        Action:       models.ToPointer(models.DisputeEvidenceRowActionContainer.FromString("String7")),
        Date:         models.ToPointer(models.DisputeEvidenceRowDateContainer.FromString("String3")),
        EvidenceType: "evidence_type8",
        Source:       models.Source3Enum_REQUESTEDFROMSELLER,
    }

}
```

