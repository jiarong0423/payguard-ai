
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    currency := models.CurrencyEnum_USD

}
```

