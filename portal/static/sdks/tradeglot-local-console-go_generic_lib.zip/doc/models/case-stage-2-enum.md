
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `ANY` |
| `PROCEDURALORDER` |
| `NOTAPPLICABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    caseStage2 := models.CaseStage2Enum_ANY

}
```

