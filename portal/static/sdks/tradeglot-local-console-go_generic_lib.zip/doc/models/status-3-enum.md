
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITINGFORSELLERRESPONSE` |
| `WAITINGFORBUYERRESPONSE` |
| `UNDERREVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status3 := models.Status3Enum_OPEN

}
```

