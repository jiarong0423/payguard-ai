
# Country Rules Search Request

CountryRulesSearchRequest.

## Structure

`CountryRulesSearchRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Limit` | `*int` | Optional | Limit.<br><br>**Default**: `5`<br><br>**Constraints**: `>= 1`, `<= 10` |
| `Query` | `string` | Required | Query.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    countryRulesSearchRequest := models.CountryRulesSearchRequest{
        Limit: models.ToPointer(5),
        Query: "query4",
    }

}
```

