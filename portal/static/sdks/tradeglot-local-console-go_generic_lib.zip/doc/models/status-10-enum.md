
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status10 := models.Status10Enum_CONNECTED

}
```

