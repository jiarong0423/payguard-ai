
# Evidence Class Enum

Evidence class.

## Enumeration

`EvidenceClassEnum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |
| `SYNTHETICFIXTURE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    evidenceClass := models.EvidenceClassEnum_SYNTHETICFIXTURE

}
```

