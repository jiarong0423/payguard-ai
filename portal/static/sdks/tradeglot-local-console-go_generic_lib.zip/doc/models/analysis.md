
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reason` | [`*models.AnalysisReason`](../../doc/models/containers/analysis-reason.md) | Optional | This is a container for any-of cases. |
| `Status` | [`*models.Status8Enum`](../../doc/models/status-8-enum.md) | Optional | Status. |
| `Turn` | `*int` | Optional | Turn. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    analysis := models.Analysis{
        Reason:               models.ToPointer(models.AnalysisReasonContainer.FromReason5(models.Reason5Enum_INVALIDREPLY)),
        Status:               models.ToPointer(models.Status8Enum_REPLACED),
        Turn:                 models.ToPointer(198),
    }

}
```

