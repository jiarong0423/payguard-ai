
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Reason` | [`models.Reason6Enum`](../../doc/models/reason-6-enum.md) | Required | Reason. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideDropped := models.GuideDropped{
        Item:   "item6",
        Reason: models.Reason6Enum_OTHERPARTY,
    }

}
```

