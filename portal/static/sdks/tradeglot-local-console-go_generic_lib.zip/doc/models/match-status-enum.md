
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NOMATCH` |
| `REVIEWSIGNAL` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    matchStatus := models.MatchStatusEnum_NOMATCH

}
```

