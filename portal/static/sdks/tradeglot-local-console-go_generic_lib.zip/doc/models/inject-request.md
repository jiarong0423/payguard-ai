
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Scenario` | [`models.Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    injectRequest := models.InjectRequest{
        Scenario: models.Scenario5Enum_BURST,
    }

}
```

