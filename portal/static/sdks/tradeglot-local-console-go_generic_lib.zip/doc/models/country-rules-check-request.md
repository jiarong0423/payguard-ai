
# Country Rules Check Request

Seller and buyer countries plus closed choices; no free text reaches the check.

## Structure

`CountryRulesCheckRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountOpened` | [`*models.AccountOpenedEnum`](../../doc/models/account-opened-enum.md) | Optional | Account opened.<br><br>**Default**: `"unknown"` |
| `AccountType` | [`*models.AccountTypeEnum`](../../doc/models/account-type-enum.md) | Optional | Account type.<br><br>**Default**: `"business"` |
| `Amount` | [`*models.CountryRulesCheckRequestAmount`](../../doc/models/containers/country-rules-check-request-amount.md) | Optional | This is a container for any-of cases. |
| `BuyerCountry` | [`models.BuyerCountryEnum`](../../doc/models/buyer-country-enum.md) | Required | Buyer country. |
| `Checkout` | [`*models.CheckoutEnum`](../../doc/models/checkout-enum.md) | Optional | Checkout.<br><br>**Default**: `"paypal_account"` |
| `Currency` | [`*models.CountryRulesCheckRequestCurrency`](../../doc/models/containers/country-rules-check-request-currency.md) | Optional | This is a container for any-of cases. |
| `GoodsTags` | `[]string` | Optional | Goods tags.<br><br>**Constraints**: *Maximum Items*: `16` |
| `SellerCountry` | [`models.SellerCountryEnum`](../../doc/models/seller-country-enum.md) | Required | Seller country. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    countryRulesCheckRequest := models.CountryRulesCheckRequest{
        AccountOpened: models.ToPointer(models.AccountOpenedEnum_UNKNOWN),
        AccountType:   models.ToPointer(models.AccountTypeEnum_BUSINESS),
        Amount:        models.ToPointer(models.CountryRulesCheckRequestAmountContainer.FromString("String7")),
        BuyerCountry:  models.BuyerCountryEnum_JP,
        Checkout:      models.ToPointer(models.CheckoutEnum_PAYPALACCOUNT),
        Currency:      models.ToPointer(models.CountryRulesCheckRequestCurrencyContainer.FromString("String5")),
        SellerCountry: models.SellerCountryEnum_US,
    }

}
```

