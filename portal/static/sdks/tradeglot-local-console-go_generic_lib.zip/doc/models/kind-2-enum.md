
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `DATE` |
| `CHOICE` |
| `TEXT` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    kind2 := models.Kind2Enum_CHOICE

}
```

