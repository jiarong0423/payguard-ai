
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NEEDSREVIEW` |
| `DRAFTREADY` |
| `LOCALDRAFTREVIEWED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status7 := models.Status7Enum_NEEDSREVIEW

}
```

