
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLYPRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOTAPPLICABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status9 := models.Status9Enum_STRUCTURALLYPRESENT

}
```

