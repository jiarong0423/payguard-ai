
# Time Evidence 1

Time evidence.

## Structure

`TimeEvidence1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AdvisoryOnly` | `*bool` | Optional | Advisory only. |
| `Events` | [`[]models.TimeEvidence1Events`](../../doc/models/containers/time-evidence-1-events.md) | Optional | This is Array of a container for any-of cases.<br><br>**Constraints**: *Minimum Items*: `2`, *Maximum Items*: `30` |
| `Flags` | [`[]models.FlagEnum`](../../doc/models/flag-enum.md) | Optional | Flags.<br><br>**Constraints**: *Maximum Items*: `4` |
| `GapsSeconds` | [`*models.TimeGaps`](../../doc/models/time-gaps.md) | Optional | TimeGaps. |
| `Judgement` | [`*models.JudgementEnum`](../../doc/models/judgement-enum.md) | Optional | Judgement. |
| `SchemaVersion` | [`*models.SchemaVersionEnum`](../../doc/models/schema-version-enum.md) | Optional | Schema version. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    timeEvidence1 := models.TimeEvidence1{
        AdvisoryOnly:         models.ToPointer(false),
        Events:               []models.TimeEvidence1Events{
            models.TimeEvidence1EventsContainer.FromMessageTimeEvent(models.MessageTimeEvent{
                At:                   "at4",
                Channel:              models.ChannelEnum_EMAIL,
                Direction:            models.DirectionEnum_INBOUND,
                Kind:                 "kind6",
                MessageDigest:        "message_digest2",
                Source:               "source4",
                Topic:                models.TopicEnum_ORDERDETAILSPROVIDED,
            }),
            models.TimeEvidence1EventsContainer.FromMessageTimeEvent(models.MessageTimeEvent{
                At:                   "at4",
                Channel:              models.ChannelEnum_EMAIL,
                Direction:            models.DirectionEnum_INBOUND,
                Kind:                 "kind6",
                MessageDigest:        "message_digest2",
                Source:               "source4",
                Topic:                models.TopicEnum_ORDERDETAILSPROVIDED,
            }),
        },
        Flags:                []models.FlagEnum{
            models.FlagEnum_ORDERRECORDABSENT,
            models.FlagEnum_DELIVERYNOTRECORDED,
        },
        GapsSeconds:          models.ToPointer(models.TimeGaps{
            DeliveryToClaim:      models.TimeGapsDeliveryToClaimContainer.FromNumber(210),
            PaymentToClaim:       models.TimeGapsPaymentToClaimContainer.FromNumber(154),
            PaymentToDelivery:    models.TimeGapsPaymentToDeliveryContainer.FromNumber(192),
            PaymentToOrderRecord: models.TimeGapsPaymentToOrderRecordContainer.FromNumber(208),
        }),
        Judgement:            models.ToPointer(models.JudgementEnum_NOTMADE),
    }

}
```

