
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AffectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `"False"` |
| `Reason` | [`models.AupCategorySignalResponseReason`](../../doc/models/containers/aup-category-signal-response-reason.md) | Required | This is a container for any-of cases. |
| `Signal` | [`models.AupCategorySignalResponseSignal`](../../doc/models/containers/aup-category-signal-response-signal.md) | Required | This is a container for any-of cases. |
| `Status` | [`models.Status2Enum`](../../doc/models/status-2-enum.md) | Required | Status. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    aupCategorySignalResponse := models.AupCategorySignalResponse{
        AffectsDecision: "False",
        Reason:          models.AupCategorySignalResponseReasonContainer.FromReason(models.ReasonEnum_BUDGETEXHAUSTED),
        Signal:          models.AupCategorySignalResponseSignalContainer.FromCategorySignal(models.CategorySignal{
            Category:             models.CategorySignalCategoryContainer.FromString("String9"),
            Confidence:           models.CategorySignalConfidenceContainer.FromConfidence(models.ConfidenceEnum_HIGH),
            Source:               "channel3",
        }),
        Status:          models.Status2Enum_NOTSENT,
    }

}
```

