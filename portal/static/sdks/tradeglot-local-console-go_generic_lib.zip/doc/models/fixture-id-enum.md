
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `PAYGUARDFIXEDSYNTHETICBRIEFV1` |
| `PAYGUARDSESSIONBRIEFV1` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    fixtureId := models.FixtureIdEnum_PAYGUARDFIXEDSYNTHETICBRIEFV1

}
```

