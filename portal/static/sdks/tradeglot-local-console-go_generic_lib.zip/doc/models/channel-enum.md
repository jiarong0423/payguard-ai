
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATEMESSAGE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    channel := models.ChannelEnum_EMAIL

}
```

