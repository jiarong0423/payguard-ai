
# Source 8 Enum

Source.

## Enumeration

`Source8Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL` |
| `SUGGESTION` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source8 := models.Source8Enum_OFFICIAL

}
```

