
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source5 := models.Source5Enum_PROVIDER

}
```

