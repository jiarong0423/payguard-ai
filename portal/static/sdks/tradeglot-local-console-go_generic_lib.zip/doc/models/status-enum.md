
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURECOMPATIBLE` |
| `INCOMPLETEEVIDENCE` |
| `REJECTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status := models.StatusEnum_REJECTED

}
```

