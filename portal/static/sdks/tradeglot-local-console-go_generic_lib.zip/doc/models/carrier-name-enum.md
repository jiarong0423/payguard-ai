
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    carrierName := models.CarrierNameEnum_JPJAPANPOST

}
```

