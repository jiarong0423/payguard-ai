
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |
| `FIXTURE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    dataSourceLabel := models.DataSourceLabelEnum_SANDBOX

}
```

