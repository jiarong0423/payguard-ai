
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `*string` | Optional | Item. |
| `Valid` | `*bool` | Optional | Valid. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    formResult := models.FormResult{
        Item:                 models.ToPointer("item8"),
        Valid:                models.ToPointer(false),
    }

}
```

