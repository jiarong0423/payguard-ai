
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `NAME` |
| `ADDRESS` |
| `EMAIL` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    field := models.FieldEnum_ADDRESS

}
```

