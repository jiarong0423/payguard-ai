
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICTESTRESPONSE` |
| `OPERATORLIVERESPONSE` |
| `LOCALRUNTIMERESPONSE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    executionEvidence := models.ExecutionEvidenceEnum_OPERATORLIVERESPONSE

}
```

