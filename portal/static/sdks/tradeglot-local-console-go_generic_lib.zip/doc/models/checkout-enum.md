
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PAYPALACCOUNT` |
| `GUESTCARD` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    checkout := models.CheckoutEnum_PAYPALACCOUNT

}
```

