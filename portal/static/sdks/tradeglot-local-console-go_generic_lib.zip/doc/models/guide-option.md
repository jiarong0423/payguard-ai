
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `string` | Required | Label. |
| `Value` | `string` | Required | Value. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideOption := models.GuideOption{
        Label: "label2",
        Value: "value4",
    }

}
```

