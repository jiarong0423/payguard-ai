
# Disputed Transaction

DisputedTransaction.

## Structure

`DisputedTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GrossAmount` | [`*models.DisputedTransactionGrossAmount`](../../doc/models/containers/disputed-transaction-gross-amount.md) | Optional | This is a container for any-of cases. |
| `SellerProtectionEligible` | [`*models.DisputedTransactionSellerProtectionEligible`](../../doc/models/containers/disputed-transaction-seller-protection-eligible.md) | Optional | This is a container for any-of cases. |
| `SellerTransactionId` | `string` | Required | Seller transaction id.<br><br>**Constraints**: *Pattern*: `^[A-Za-z0-9._-]{1,64}$` |
| `TransactionStatus` | [`*models.DisputedTransactionTransactionStatus`](../../doc/models/containers/disputed-transaction-transaction-status.md) | Optional | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    disputedTransaction := models.DisputedTransaction{
        GrossAmount:              models.ToPointer(models.DisputedTransactionGrossAmountContainer.FromProviderMoney(models.ProviderMoney{
            CurrencyCode:         "currency_code0",
            Value:                "value6",
        })),
        SellerProtectionEligible: models.ToPointer(models.DisputedTransactionSellerProtectionEligibleContainer.FromBoolean(true)),
        SellerTransactionId:      "seller_transaction_id8",
        TransactionStatus:        models.ToPointer(models.DisputedTransactionTransactionStatusContainer.FromString("String3")),
    }

}
```

