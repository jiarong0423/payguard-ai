
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `KEYWORD` |
| `GEMINI` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    chooserMode := models.ChooserModeEnum_KEYWORD

}
```

