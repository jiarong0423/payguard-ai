
# Policy Theme Counts

PolicyThemeCounts.

## Structure

`PolicyThemeCounts`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DisputeMediation` | `int` | Required | Dispute mediation.<br><br>**Constraints**: `>= 0`, `<= 29` |
| `SourceCompliance` | `int` | Required | Source compliance.<br><br>**Constraints**: `>= 0`, `<= 29` |
| `VelocityGuard` | `int` | Required | Velocity guard.<br><br>**Constraints**: `>= 0`, `<= 29` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    policyThemeCounts := models.PolicyThemeCounts{
        DisputeMediation: 29,
        SourceCompliance: 29,
        VelocityGuard:    29,
    }

}
```

