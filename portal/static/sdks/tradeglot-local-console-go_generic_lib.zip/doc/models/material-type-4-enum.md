
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OFFICIALAPIREFERENCE` |
| `OFFICIALPOLICY` |
| `PUBLICCOURTORDERCOPY` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    materialType4 := models.MaterialType4Enum_OFFICIALAPIREFERENCE

}
```

