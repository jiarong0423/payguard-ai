
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDERERROR` |
| `INVALIDREPLY` |
| `LATE` |
| `NOITEMS` |
| `SUPERSEDED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason5 := models.Reason5Enum_INVALIDREPLY

}
```

