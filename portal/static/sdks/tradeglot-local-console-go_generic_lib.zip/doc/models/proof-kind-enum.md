
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POSTRESPONSEONLY` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    proofKind := models.ProofKindEnum_POSTRESPONSEONLY

}
```

