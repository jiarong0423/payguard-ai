
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SOURCECOMPLIANCE` |
| `VELOCITYGUARD` |
| `DISPUTEMEDIATION` |
| `GUIDE` |
| `STUDIOAGENT` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    stage2 := models.Stage2Enum_STUDIOAGENT

}
```

