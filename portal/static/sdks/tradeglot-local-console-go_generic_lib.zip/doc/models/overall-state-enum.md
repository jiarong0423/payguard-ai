
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASENOTACTIONABLE` |
| `MANUALREVIEW` |
| `DUEDATEEXPIRED` |
| `ACTIONNOTAVAILABLE` |
| `NEEDSINPUT` |
| `READYFORLOCALREVIEW` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    overallState := models.OverallStateEnum_DUEDATEEXPIRED

}
```

