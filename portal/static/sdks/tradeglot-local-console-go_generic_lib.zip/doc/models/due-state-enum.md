
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    dueState := models.DueStateEnum_OPEN

}
```

