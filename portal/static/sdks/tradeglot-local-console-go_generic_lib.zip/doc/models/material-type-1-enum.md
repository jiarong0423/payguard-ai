
# Material Type 1 Enum

Material type.

## Enumeration

`MaterialType1Enum`

## Fields

| Name |
|  --- |
| `OFFICIALAPIREFERENCE` |
| `OFFICIALPOLICY` |
| `PUBLICCOURTORDERCOPY` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    materialType1 := models.MaterialType1Enum_OFFICIALPOLICY

}
```

