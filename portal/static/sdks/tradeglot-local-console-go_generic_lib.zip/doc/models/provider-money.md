
# Provider Money

ProviderMoney.

## Structure

`ProviderMoney`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CurrencyCode` | `string` | Required | Currency code.<br><br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `Value` | `string` | Required | Value.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,10}(?:\.[0-9]{1,2})?$` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    providerMoney := models.ProviderMoney{
        CurrencyCode:         "currency_code4",
        Value:                "value0",
    }

}
```

