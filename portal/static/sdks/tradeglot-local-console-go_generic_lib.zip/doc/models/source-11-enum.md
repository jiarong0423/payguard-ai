
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3LIVE` |
| `CHANNEL3RECORDED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source11 := models.Source11Enum_CHANNEL3LIVE

}
```

