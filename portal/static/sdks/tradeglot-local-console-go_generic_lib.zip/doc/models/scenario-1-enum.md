
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    scenario1 := models.Scenario1Enum_VELOCITY

}
```

