
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `ENUMPAYGUARDTIMEEVIDENCEV1` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    schemaVersion := models.SchemaVersionEnum_ENUMPAYGUARDTIMEEVIDENCEV1

}
```

