
# Event

## Structure

`Event`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `*string` | Optional | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `Channel` | [`*models.ChannelEnum`](../../doc/models/channel-enum.md) | Optional | Channel. |
| `Direction` | [`*models.DirectionEnum`](../../doc/models/direction-enum.md) | Optional | Direction. |
| `Kind` | [`*models.Kind1Enum`](../../doc/models/kind-1-enum.md) | Optional | Kind. |
| `MessageDigest` | `*string` | Optional | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `Source` | [`*models.Source6Enum`](../../doc/models/source-6-enum.md) | Optional | Source. |
| `Topic` | [`*models.TopicEnum`](../../doc/models/topic-enum.md) | Optional | Topic. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    event := models.Event{
        At:                   models.ToPointer("at6"),
        Channel:              models.ToPointer(models.ChannelEnum_EMAIL),
        Direction:            models.ToPointer(models.DirectionEnum_INBOUND),
        Kind:                 models.ToPointer(models.Kind1Enum_MESSAGE),
        MessageDigest:        models.ToPointer("message_digest6"),
    }

}
```

