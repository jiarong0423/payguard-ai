
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`*models.ActionEnum`](../../doc/models/action-enum.md) | Optional | Action. |
| `Environment` | [`*models.EnvironmentEnum`](../../doc/models/environment-enum.md) | Optional | Environment. |
| `EvidenceClass` | [`*models.EvidenceClass3Enum`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. |
| `ExternalSend` | [`*models.ExternalSend1Enum`](../../doc/models/external-send-1-enum.md) | Optional | External send. |
| `InvoiceId` | [`*models.EvidenceReceiptInvoiceId`](../../doc/models/containers/evidence-receipt-invoice-id.md) | Optional | This is a container for any-of cases. |
| `ObservedAt` | `*string` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `PaypalDebugId` | [`*models.EvidenceReceiptPaypalDebugId`](../../doc/models/containers/evidence-receipt-paypal-debug-id.md) | Optional | This is a container for any-of cases. |
| `ProofKind` | [`*models.ProofKindEnum`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. |
| `SchemaVersion` | [`*models.SchemaVersion1Enum`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. |
| `SeparateGetReadback` | `*bool` | Optional | Separate get readback. |
| `Status` | [`*models.Status10Enum`](../../doc/models/status-10-enum.md) | Optional | Status. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    evidenceReceipt := models.EvidenceReceipt{
        Action:               models.ToPointer(models.ActionEnum_OAUTHCONNECT),
        Environment:          models.ToPointer(models.EnvironmentEnum_SANDBOX),
        EvidenceClass:        models.ToPointer(models.EvidenceClass3Enum_AUTHENTICSANDBOXRESPONSE),
        ExternalSend:         models.ToPointer(models.ExternalSend1Enum_FROZEN),
        InvoiceId:            models.ToPointer(models.EvidenceReceiptInvoiceIdContainer.FromString("String1")),
    }

}
```

