
# Reason Code Enum

## Enumeration

`ReasonCodeEnum`

## Fields

| Name |
|  --- |
| `ACTIONCLAIMFORBIDDEN` |
| `ASSURANCECLAIMFORBIDDEN` |
| `CITATIONUNKNOWN` |
| `CITATIONREGIONMISMATCH` |
| `CITATIONTHEMEMISMATCH` |
| `CLAIMREFERENCETYPEMISMATCH` |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `DOCUMENTUPDATEINFUTURE` |
| `CURRENTPOLICYNOTESTABLISHED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reasonCode := models.ReasonCodeEnum_FUTUREOBSERVATION

}
```

