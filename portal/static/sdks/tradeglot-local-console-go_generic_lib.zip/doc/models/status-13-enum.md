
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `REFERENCESFOUND` |
| `EVIDENCEMISSING` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status13 := models.Status13Enum_REFERENCESFOUND

}
```

