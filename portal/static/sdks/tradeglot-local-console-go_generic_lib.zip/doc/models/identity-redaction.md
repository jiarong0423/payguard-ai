
# Identity Redaction

IdentityRedaction.

## Structure

`IdentityRedaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fields` | [`[]models.FieldEnum`](../../doc/models/field-enum.md) | Required | Fields. |
| `Method` | `string` | Required, Constant | Method.<br><br>**Value**: `"HMAC-SHA256 pseudonymization"` |
| `Synthetic` | `string` | Required, Constant | Synthetic.<br><br>**Value**: `"True"` |
| `Tokens` | [`models.IdentityTokens`](../../doc/models/identity-tokens.md) | Required | IdentityTokens. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    identityRedaction := models.IdentityRedaction{
        Fields:    []models.FieldEnum{
            models.FieldEnum_NAME,
            models.FieldEnum_ADDRESS,
        },
        Method:    "HMAC-SHA256 pseudonymization",
        Synthetic: "True",
        Tokens:    models.IdentityTokens{
            AddressToken: "address_token0",
            EmailToken:   "email_token2",
            NameToken:    "name_token0",
        },
    }

}
```

