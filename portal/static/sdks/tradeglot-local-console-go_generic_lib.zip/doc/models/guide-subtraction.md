
# Guide Subtraction

GuideSubtraction.

## Structure

`GuideSubtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Left` | `int` | Required | Left. |
| `Needed` | `int` | Required | Needed. |
| `Taken` | `int` | Required | Taken. |
| `Text` | `string` | Required | Text. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideSubtraction := models.GuideSubtraction{
        Left:                 18,
        Needed:               112,
        Taken:                124,
        Text:                 "text8",
    }

}
```

