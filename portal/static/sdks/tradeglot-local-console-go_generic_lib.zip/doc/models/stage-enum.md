
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SOURCECOMPLIANCE` |
| `VELOCITYGUARD` |
| `DISPUTEMEDIATION` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    stage := models.StageEnum_DISPUTEMEDIATION

}
```

