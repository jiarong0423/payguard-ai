
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Kind` | [`*models.Kind2Enum`](../../doc/models/kind-2-enum.md) | Optional | Kind. |
| `Options` | [`[]models.GuideOption`](../../doc/models/guide-option.md) | Optional | Options. |
| `Placeholder` | [`*models.FormPlaceholder`](../../doc/models/containers/form-placeholder.md) | Optional | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    form := models.Form{
        Kind:                 models.ToPointer(models.Kind2Enum_TEXT),
        Options:              []models.GuideOption{
            models.GuideOption{
                Label: "label2",
                Value: "value4",
            },
            models.GuideOption{
                Label: "label2",
                Value: "value4",
            },
            models.GuideOption{
                Label: "label2",
                Value: "value4",
            },
        },
        Placeholder:          models.ToPointer(models.FormPlaceholderContainer.FromString("String9")),
    }

}
```

