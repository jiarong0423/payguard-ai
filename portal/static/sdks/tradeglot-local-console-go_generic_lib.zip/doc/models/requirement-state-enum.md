
# Requirement State Enum

Requirement state.

## Enumeration

`RequirementStateEnum`

## Fields

| Name |
|  --- |
| `CONTEXTONLY` |
| `UNMAPPEDEVIDENCETYPE` |
| `PROVIDERREQUESTOUTSIDELOCALMATRIX` |
| `STRUCTURALLYPRESENT` |
| `MANDATORYEVIDENCEMISSING` |
| `OPTIONALEVIDENCEMISSING` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    requirementState := models.RequirementStateEnum_MANDATORYEVIDENCEMISSING

}
```

