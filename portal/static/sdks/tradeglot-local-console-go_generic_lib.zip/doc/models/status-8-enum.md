
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `ANALYSING` |
| `REPLACED` |
| `KEPT` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status8 := models.Status8Enum_REPLACED

}
```

