
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICBASELINE` |
| `CALLERSUPPLIEDUNVERIFIED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    baselineProvenance := models.BaselineProvenanceEnum_SYNTHETICBASELINE

}
```

