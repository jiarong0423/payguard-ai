
# Dispute Record

DisputeRecord.

## Structure

`DisputeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreateTime` | `string` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` |
| `DisputeAmount` | [`models.ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. |
| `DisputeId` | `string` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` |
| `DisputeLifeCycleStage` | [`models.DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `DisputeState` | [`*models.DisputeRecordDisputeState`](../../doc/models/containers/dispute-record-dispute-state.md) | Optional | This is a container for any-of cases. |
| `Reason` | [`models.Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `SellerResponseDueDate` | [`*models.DisputeRecordSellerResponseDueDate`](../../doc/models/containers/dispute-record-seller-response-due-date.md) | Optional | This is a container for any-of cases. |
| `Status` | [`models.Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |
| `UpdateTime` | [`*models.DisputeRecordUpdateTime`](../../doc/models/containers/dispute-record-update-time.md) | Optional | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    disputeRecord := models.DisputeRecord{
        CreateTime:            "create_time0",
        DisputeAmount:         models.ProviderMoney{
            CurrencyCode:         "currency_code6",
            Value:                "value0",
        },
        DisputeId:             "dispute_id6",
        DisputeLifeCycleStage: models.DisputeLifeCycleStageEnum_ARBITRATION,
        DisputeState:          models.ToPointer(models.DisputeRecordDisputeStateContainer.FromString("String7")),
        Reason:                models.Reason2Enum_MERCHANDISEORSERVICENOTRECEIVED,
        SellerResponseDueDate: models.ToPointer(models.DisputeRecordSellerResponseDueDateContainer.FromString("String3")),
        Status:                models.Status3Enum_OPEN,
        UpdateTime:            models.ToPointer(models.DisputeRecordUpdateTimeContainer.FromString("String7")),
    }

}
```

