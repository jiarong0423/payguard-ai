
# Reference Filters

ReferenceFilters.

## Structure

`ReferenceFilters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgeBasis` | `string` | Required, Constant | Age basis.<br><br>**Value**: `"source_updated_date_utc_calendar"` |
| `AsOf` | [`models.ReferenceFiltersAsOf`](../../doc/models/containers/reference-filters-as-of.md) | Required | This is a container for any-of cases. |
| `CaseStage` | [`models.CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Required | Case stage. |
| `Jurisdiction` | `string` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` |
| `Limit` | `int` | Required | Limit.<br><br>**Constraints**: `>= 1`, `<= 10` |
| `MaterialTypes` | [`[]models.MaterialType4Enum`](../../doc/models/material-type-4-enum.md) | Required | Material types.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `3` |
| `MaxSourceAgeDays` | [`models.ReferenceFiltersMaxSourceAgeDays`](../../doc/models/containers/reference-filters-max-source-age-days.md) | Required | This is a container for any-of cases. |
| `RequireKnownSourceDate` | `bool` | Required | Require known source date. |
| `Theme` | [`models.ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    referenceFilters := models.ReferenceFilters{
        AgeBasis:               "source_updated_date_utc_calendar",
        AsOf:                   models.ReferenceFiltersAsOfContainer.FromString("String9"),
        CaseStage:              models.CaseStage2Enum_PROCEDURALORDER,
        Jurisdiction:           "US",
        Limit:                  10,
        MaterialTypes:          []models.MaterialType4Enum{
            models.MaterialType4Enum_OFFICIALPOLICY,
            models.MaterialType4Enum_PUBLICCOURTORDERCOPY,
        },
        MaxSourceAgeDays:       models.ReferenceFiltersMaxSourceAgeDaysContainer.FromNumber(238),
        RequireKnownSourceDate: false,
        Theme:                  models.ThemeEnum_DISPUTEMEDIATION,
    }

}
```

