
# Error

What was refused and why.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Required | Stable machine-readable reason, for example session_required. |
| `Message` | `string` | Required | A plain sentence for a person. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    mError := models.Error{
        Code:                 "code2",
        Message:              "message4",
    }

}
```

