
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `EXACT` |
| `CLOSE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    matchType := models.MatchTypeEnum_EXACT

}
```

