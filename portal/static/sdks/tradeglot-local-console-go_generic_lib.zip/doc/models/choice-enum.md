
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURNTOEDIT` |
| `CANCEL` |
| `ACKNOWLEDGEANDCONTINUE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    choice := models.ChoiceEnum_RETURNTOEDIT

}
```

