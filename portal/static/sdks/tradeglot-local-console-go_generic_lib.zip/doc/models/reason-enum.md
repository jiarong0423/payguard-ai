
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NOTHINGTOSEND` |
| `BUDGETEXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAMERROR` |
| `CONTRACTREJECTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason := models.ReasonEnum_CONTRACTREJECTED

}
```

