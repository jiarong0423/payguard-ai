
# Dispute Amount

Dispute amount.

## Structure

`DisputeAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CurrencyCode` | `*string` | Optional | Currency code.<br><br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `Value` | `*string` | Optional | Value.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,10}(?:\.[0-9]{1,2})?$` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    disputeAmount := models.DisputeAmount{
        CurrencyCode:         models.ToPointer("currency_code0"),
        Value:                models.ToPointer("value6"),
    }

}
```

