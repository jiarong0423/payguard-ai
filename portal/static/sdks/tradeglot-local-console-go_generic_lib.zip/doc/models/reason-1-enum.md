
# Reason 1 Enum

Reason.

## Enumeration

`Reason1Enum`

## Fields

| Name |
|  --- |
| `CATALOGUEMATCH` |
| `LIVECATALOGUEMATCH` |
| `DIGITALWORD` |
| `SERVICEWORD` |
| `FILTEREDCONFLICT` |
| `NOCLOSEMATCH` |
| `NOTHINGTOMATCH` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason1 := models.Reason1Enum_DIGITALWORD

}
```

