
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOTPERFORMED` |
| `PERFORMED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    providerSubmission := models.ProviderSubmissionEnum_NOTPERFORMED

}
```

