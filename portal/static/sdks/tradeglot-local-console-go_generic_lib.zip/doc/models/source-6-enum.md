
# Source 6 Enum

Source.

## Enumeration

`Source6Enum`

## Fields

| Name |
|  --- |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source6 := models.Source6Enum_SELLERPROVIDEDUNVERIFIED

}
```

