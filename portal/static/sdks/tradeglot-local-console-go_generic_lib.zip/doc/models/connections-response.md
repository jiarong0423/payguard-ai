
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Mode` | [`models.ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    connectionsResponse := models.ConnectionsResponse{
        Mode: models.ModeEnum_LOCAL,
    }

}
```

