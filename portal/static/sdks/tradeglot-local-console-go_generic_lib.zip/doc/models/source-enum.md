
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PAYPALSANDBOX` |
| `SYNTHETICFIXTURE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source := models.SourceEnum_PAYPALSANDBOX

}
```

