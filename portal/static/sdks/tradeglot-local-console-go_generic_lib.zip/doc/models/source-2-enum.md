
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source2 := models.Source2Enum_CHANNEL3

}
```

