
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDERRECORDCREATED` |
| `DELIVERY` |
| `CLAIMOPENED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    kind := models.KindEnum_DELIVERY

}
```

