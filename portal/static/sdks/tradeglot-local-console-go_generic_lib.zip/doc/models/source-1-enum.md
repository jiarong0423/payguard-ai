
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SESSIONMEMORY` |
| `HOSTEDDEMO` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source1 := models.Source1Enum_SESSIONMEMORY

}
```

