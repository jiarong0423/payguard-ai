
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ENUMERROR` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    outcome := models.OutcomeEnum_OK

}
```

