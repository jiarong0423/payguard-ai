
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`*models.SignalCategory`](../../doc/models/containers/signal-category.md) | Optional | This is a container for any-of cases. |
| `Confidence` | [`*models.SignalConfidence`](../../doc/models/containers/signal-confidence.md) | Optional | This is a container for any-of cases. |
| `Source` | [`*models.Source2Enum`](../../doc/models/source-2-enum.md) | Optional | Source. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    signal := models.Signal{
        Category:             models.ToPointer(models.SignalCategoryContainer.FromString("String1")),
        Confidence:           models.ToPointer(models.SignalConfidenceContainer.FromConfidence(models.ConfidenceEnum_HIGH)),
        Source:               models.ToPointer(models.Source2Enum_CHANNEL3),
    }

}
```

