
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    environment := models.EnvironmentEnum_SANDBOX

}
```

