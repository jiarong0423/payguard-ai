
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `HOSTEDDEMO` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    mode := models.ModeEnum_LOCAL

}
```

