
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `ENUM1` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    schemaVersion1 := models.SchemaVersion1Enum_ENUM1

}
```

