
# Tracking Info

TrackingInfo.

## Structure

`TrackingInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierName` | [`models.CarrierNameEnum`](../../doc/models/carrier-name-enum.md) | Required | Carrier name. |
| `CarrierNameOther` | [`*models.TrackingInfoCarrierNameOther`](../../doc/models/containers/tracking-info-carrier-name-other.md) | Optional | This is a container for any-of cases. |
| `TrackingNumber` | `string` | Required | Tracking number.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    trackingInfo := models.TrackingInfo{
        CarrierName:      models.CarrierNameEnum_TWCHUNGHWAPOST,
        CarrierNameOther: models.ToPointer(models.TrackingInfoCarrierNameOtherContainer.FromString("String9")),
        TrackingNumber:   "tracking_number4",
    }

}
```

