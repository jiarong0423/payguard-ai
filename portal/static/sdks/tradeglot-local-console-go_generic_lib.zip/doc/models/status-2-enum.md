
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status2 := models.Status2Enum_NOTSENT

}
```

