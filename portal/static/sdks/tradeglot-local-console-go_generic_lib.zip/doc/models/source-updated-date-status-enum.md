
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `MISSING` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    sourceUpdatedDateStatus := models.SourceUpdatedDateStatusEnum_DOCUMENTSTATED

}
```

