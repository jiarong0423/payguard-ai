
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENTNOTICE` |
| `ORDERDETAILSREQUEST` |
| `ORDERDETAILSPROVIDED` |
| `DELIVERYNOTICE` |
| `REFUNDREQUEST` |
| `OTHER` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    topic := models.TopicEnum_ORDERDETAILSPROVIDED

}
```

