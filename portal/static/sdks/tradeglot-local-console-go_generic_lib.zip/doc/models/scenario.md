
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Burst` | `bool` | Required | Burst. |
| `Dispute` | `bool` | Required | Dispute. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    scenario := models.Scenario{
        Burst:   false,
        Dispute: false,
    }

}
```

