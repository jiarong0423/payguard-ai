
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    externalSend := models.ExternalSendEnum_FROZEN

}
```

