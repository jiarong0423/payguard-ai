
# Guide Review Row

GuideReviewRow.

## Structure

`GuideReviewRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Source` | [`models.Source9Enum`](../../doc/models/source-9-enum.md) | Required | Source. |
| `Value` | `string` | Required | Value.<br><br>**Constraints**: *Maximum Length*: `120` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideReviewRow := models.GuideReviewRow{
        Item:   "item6",
        Source: models.Source9Enum_WORDS,
        Value:  "value6",
    }

}
```

