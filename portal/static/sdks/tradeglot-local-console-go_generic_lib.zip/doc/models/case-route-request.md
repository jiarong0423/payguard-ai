
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    caseRouteRequest := models.CaseRouteRequest{
        Text: "text6",
    }

}
```

