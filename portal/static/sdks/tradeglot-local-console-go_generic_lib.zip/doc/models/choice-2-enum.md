
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONEMATCH` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    choice2 := models.Choice2Enum_CONFIRMED

}
```

