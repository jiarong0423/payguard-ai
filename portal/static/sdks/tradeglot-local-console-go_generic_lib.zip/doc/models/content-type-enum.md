
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUMIMAGEJPEG` |
| `ENUMIMAGEGIF` |
| `ENUMIMAGEPNG` |
| `ENUMAPPLICATIONPDF` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    contentType := models.ContentTypeEnum_ENUMIMAGEPNG

}
```

