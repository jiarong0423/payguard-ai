
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    accountType := models.AccountTypeEnum_PERSONAL

}
```

