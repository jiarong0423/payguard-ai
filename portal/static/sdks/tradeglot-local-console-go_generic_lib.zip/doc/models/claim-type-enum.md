
# Claim Type Enum

Claim type.

## Enumeration

`ClaimTypeEnum`

## Fields

| Name |
|  --- |
| `POLICYREFERENCE` |
| `CURRENTPOLICY` |
| `PROCEDURALREFERENCE` |
| `APIREFERENCE` |
| `FINANCIALACTION` |
| `ASSURANCE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    claimType := models.ClaimTypeEnum_POLICYREFERENCE

}
```

