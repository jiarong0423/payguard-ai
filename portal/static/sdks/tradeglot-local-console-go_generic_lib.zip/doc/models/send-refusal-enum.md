
# Send Refusal Enum

## Enumeration

`SendRefusalEnum`

## Fields

| Name |
|  --- |
| `ACCOUNTIDENTITYUNKNOWN` |
| `DISPUTENOTTHISACCOUNT` |
| `DISPUTEDETAILREQUIRED` |
| `SELLEREVIDENCEALREADYSUBMITTED` |
| `DISPUTENOTAWAITINGSELLER` |
| `DISPUTEEVIDENCENOTOFFERED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    sendRefusal := models.SendRefusalEnum_ACCOUNTIDENTITYUNKNOWN

}
```

