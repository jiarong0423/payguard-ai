
# Approve Request

ApproveRequest.

## Structure

`ApproveRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DraftDigest` | `string` | Required | Draft digest.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    approveRequest := models.ApproveRequest{
        DraftDigest: "draft_digest6",
    }

}
```

