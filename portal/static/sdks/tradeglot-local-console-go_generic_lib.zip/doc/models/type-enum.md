
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `USPHONE` |
| `IDLIKE` |
| `NAME` |
| `ADDRESS` |
| `MANUAL` |
| `MIXED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    mType := models.TypeEnum_MIXED

}
```

