
# Aup Category Signal Request

AupCategorySignalRequest.

## Structure

`AupCategorySignalRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |
| `EvaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    aupCategorySignalRequest := models.AupCategorySignalRequest{
        Description:  "description0",
        EvaluationId: "evaluation_id4",
    }

}
```

