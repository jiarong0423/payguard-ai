
# Message Time Event

MessageTimeEvent.

## Structure

`MessageTimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `string` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `Channel` | [`models.ChannelEnum`](../../doc/models/channel-enum.md) | Required | Channel. |
| `Direction` | [`models.DirectionEnum`](../../doc/models/direction-enum.md) | Required | Direction. |
| `Kind` | `string` | Required, Constant | Kind.<br><br>**Value**: `"MESSAGE"` |
| `MessageDigest` | `string` | Required | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `Source` | `string` | Required, Constant | Source.<br><br>**Value**: `"SELLER_PROVIDED_UNVERIFIED"` |
| `Topic` | [`models.TopicEnum`](../../doc/models/topic-enum.md) | Required | Topic. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    messageTimeEvent := models.MessageTimeEvent{
        At:                   "at6",
        Channel:              models.ChannelEnum_EMAIL,
        Direction:            models.DirectionEnum_INBOUND,
        Kind:                 "MESSAGE",
        MessageDigest:        "message_digest4",
        Source:               "SELLER_PROVIDED_UNVERIFIED",
        Topic:                models.TopicEnum_PAYMENTNOTICE,
    }

}
```

