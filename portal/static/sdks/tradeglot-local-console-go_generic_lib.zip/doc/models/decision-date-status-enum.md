
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTSTATEDINREVIEWEDDOCUMENT` |
| `NOTAPPLICABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    decisionDateStatus := models.DecisionDateStatusEnum_DOCUMENTSTATED

}
```

