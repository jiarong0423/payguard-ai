
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    accountStatus := models.AccountStatusEnum_UNKNOWN

}
```

