
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    sellerCountry := models.SellerCountryEnum_AU

}
```

