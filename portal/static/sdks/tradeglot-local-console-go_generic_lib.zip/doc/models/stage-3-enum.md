
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `FUNNEL` |
| `ECHO` |
| `FILL` |
| `REVIEW` |
| `DONE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    stage3 := models.Stage3Enum_DONE

}
```

