
# Guide Form Request

One field ({item, value}) or one round of up to three fields ({fields: [...]}), never both.

## Structure

`GuideFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConfirmReview` | `*bool` | Optional | Confirm review.<br><br>**Default**: `false` |
| `Fields` | [`*models.GuideFormRequestFields`](../../doc/models/containers/guide-form-request-fields.md) | Optional | This is a container for any-of cases. |
| `Item` | [`*models.GuideFormRequestItem`](../../doc/models/containers/guide-form-request-item.md) | Optional | This is a container for any-of cases. |
| `Scenario` | [`*models.GuideFormRequestScenario`](../../doc/models/containers/guide-form-request-scenario.md) | Optional | This is a container for any-of cases. |
| `Value` | [`*models.GuideFormRequestValue`](../../doc/models/containers/guide-form-request-value.md) | Optional | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideFormRequest := models.GuideFormRequest{
        ConfirmReview: models.ToPointer(false),
        Fields:        models.ToPointer(models.GuideFormRequestFieldsContainer.FromArrayOfGuideField([]models.GuideField{
            models.GuideField{
                Item:  "item8",
                Value: "value8",
            },
        })),
        Item:          models.ToPointer(models.GuideFormRequestItemContainer.FromString("String1")),
        Scenario:      models.ToPointer(models.GuideFormRequestScenarioContainer.FromScenario1(models.Scenario1Enum_PREFLIGHT)),
        Value:         models.ToPointer(models.GuideFormRequestValueContainer.FromString("String1")),
    }

}
```

