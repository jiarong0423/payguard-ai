
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Kind` | [`models.Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. |
| `Options` | [`[]models.GuideOption`](../../doc/models/guide-option.md) | Required | Options. |
| `Placeholder` | [`models.GuideFormPlaceholder`](../../doc/models/containers/guide-form-placeholder.md) | Required | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideForm := models.GuideForm{
        Kind:        models.Kind2Enum_CHOICE,
        Options:     []models.GuideOption{
            models.GuideOption{
                Label: "label2",
                Value: "value4",
            },
        },
        Placeholder: models.GuideFormPlaceholderContainer.FromString("String3"),
    }

}
```

