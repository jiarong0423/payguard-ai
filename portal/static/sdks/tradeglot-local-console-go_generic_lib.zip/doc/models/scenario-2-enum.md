
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    scenario2 := models.Scenario2Enum_VELOCITY

}
```

