
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOTFOUND` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status12 := models.Status12Enum_NOTSENT

}
```

