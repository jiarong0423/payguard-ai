
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |
| `SERVICE` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    route := models.RouteEnum_PHYSICAL

}
```

