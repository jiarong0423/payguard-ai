
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OTHERPARTY` |
| `INFERRED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason6 := models.Reason6Enum_OTHERPARTY

}
```

