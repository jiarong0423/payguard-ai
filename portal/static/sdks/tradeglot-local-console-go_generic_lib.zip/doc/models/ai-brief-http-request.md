
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CaseRef` | [`*models.AiBriefHttpRequestCaseRef`](../../doc/models/containers/ai-brief-http-request-case-ref.md) | Optional | This is a container for any-of cases. |
| `Stage` | [`models.StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    aiBriefHttpRequest := models.AiBriefHttpRequest{
        CaseRef: models.ToPointer(models.AiBriefHttpRequestCaseRefContainer.FromString("String9")),
        Stage:   models.StageEnum_VELOCITYGUARD,
    }

}
```

