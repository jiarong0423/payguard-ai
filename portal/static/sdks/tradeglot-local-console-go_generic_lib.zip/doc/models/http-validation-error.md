
# HTTP Validation Error

HTTPValidationError.

## Structure

`HTTPValidationError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Detail` | [`[]models.ValidationError`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    hTTPValidationError := models.HTTPValidationError{
        Detail:               []models.ValidationError{
            models.ValidationError{
                Ctx:                  models.ToPointer(interface{}("[key1, val1][key2, val2]")),
                Input:                models.ToPointer(interface{}("[key1, val1][key2, val2]")),
                Loc:                  []models.ValidationErrorLoc{
                    models.ValidationErrorLocContainer.FromString("String7"),
                    models.ValidationErrorLocContainer.FromString("String8"),
                    models.ValidationErrorLocContainer.FromString("String9"),
                },
                Msg:                  "msg2",
                Type:                 "type4",
            },
            models.ValidationError{
                Ctx:                  models.ToPointer(interface{}("[key1, val1][key2, val2]")),
                Input:                models.ToPointer(interface{}("[key1, val1][key2, val2]")),
                Loc:                  []models.ValidationErrorLoc{
                    models.ValidationErrorLocContainer.FromString("String7"),
                    models.ValidationErrorLocContainer.FromString("String8"),
                    models.ValidationErrorLocContainer.FromString("String9"),
                },
                Msg:                  "msg2",
                Type:                 "type4",
            },
        },
    }

}
```

