
# Time Event

TimeEvent.

## Structure

`TimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `string` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `Kind` | [`models.KindEnum`](../../doc/models/kind-enum.md) | Required | Kind. |
| `Source` | [`models.Source5Enum`](../../doc/models/source-5-enum.md) | Required | Source. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    timeEvent := models.TimeEvent{
        At:                   "at6",
        Kind:                 models.KindEnum_DELIVERY,
        Source:               models.Source5Enum_PROVIDER,
    }

}
```

