
# Invoice Review Request

InvoiceReviewRequest.

## Structure

`InvoiceReviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AcknowledgementToken` | [`*models.InvoiceReviewRequestAcknowledgementToken`](../../doc/models/containers/invoice-review-request-acknowledgement-token.md) | Optional | This is a container for any-of cases. |
| `Amount` | `string` | Required | Amount.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,9}(?:\.[0-9]{1,2})?$` |
| `ConfirmSandboxDraft` | `bool` | Required | Confirm sandbox draft. |
| `Currency` | [`models.CurrencyEnum`](../../doc/models/currency-enum.md) | Required | Currency. |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |
| `DescriptionDigest` | [`*models.InvoiceReviewRequestDescriptionDigest`](../../doc/models/containers/invoice-review-request-description-digest.md) | Optional | This is a container for any-of cases. |
| `EvaluationId` | [`*models.InvoiceReviewRequestEvaluationId`](../../doc/models/containers/invoice-review-request-evaluation-id.md) | Optional | This is a container for any-of cases. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    invoiceReviewRequest := models.InvoiceReviewRequest{
        AcknowledgementToken: models.ToPointer(models.InvoiceReviewRequestAcknowledgementTokenContainer.FromString("String7")),
        Amount:               "amount8",
        ConfirmSandboxDraft:  false,
        Currency:             models.CurrencyEnum_USD,
        Description:          "description6",
        DescriptionDigest:    models.ToPointer(models.InvoiceReviewRequestDescriptionDigestContainer.FromString("String5")),
        EvaluationId:         models.ToPointer(models.InvoiceReviewRequestEvaluationIdContainer.FromString("String1")),
    }

}
```

