
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `KEYWORD` |
| `MODEL` |
| `KEYWORDFALLBACK` |
| `FORM` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    chooser := models.ChooserEnum_FORM

}
```

