
# Source 3 Enum

Source.

## Enumeration

`Source3Enum`

## Fields

| Name |
|  --- |
| `REQUESTEDFROMSELLER` |
| `REQUESTEDFROMBUYER` |
| `SUBMITTEDBYSELLER` |
| `SUBMITTEDBYBUYER` |
| `SUBMITTEDBYPARTNER` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source3 := models.Source3Enum_REQUESTEDFROMSELLER

}
```

