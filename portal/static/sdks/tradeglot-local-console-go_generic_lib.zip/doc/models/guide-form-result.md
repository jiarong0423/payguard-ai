
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Valid` | `bool` | Required | Valid. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideFormResult := models.GuideFormResult{
        Item:  "item2",
        Valid: false,
    }

}
```

