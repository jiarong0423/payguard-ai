
# Policy Source

PolicySource.

## Structure

`PolicySource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CitationChunkIds` | `[]string` | Required | Citation chunk ids.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `29`, *Pattern*: `^[A-Z0-9-]{1,128}$` |
| `ContentClass` | `string` | Required, Constant | Content class.<br><br>**Value**: `"public_reference_summary"` |
| `CurrentPolicyApplicability` | `string` | Required, Constant | Current policy applicability.<br><br>**Value**: `"NOT_ESTABLISHED"` |
| `DecisionAcceptanceDeadline` | [`models.PolicySourceDecisionAcceptanceDeadline`](../../doc/models/containers/policy-source-decision-acceptance-deadline.md) | Required | This is a container for any-of cases. |
| `DecisionDate` | [`models.PolicySourceDecisionDate`](../../doc/models/containers/policy-source-decision-date.md) | Required | This is a container for any-of cases. |
| `DecisionDateStatus` | [`models.DecisionDateStatusEnum`](../../doc/models/decision-date-status-enum.md) | Required | Decision date status. |
| `EffectiveDate` | [`models.PolicySourceEffectiveDate`](../../doc/models/containers/policy-source-effective-date.md) | Required | This is a container for any-of cases. |
| `EffectiveDateStatus` | [`models.EffectiveDateStatusEnum`](../../doc/models/effective-date-status-enum.md) | Required | Effective date status. |
| `Jurisdiction` | `string` | Required | Jurisdiction.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2000` |
| `JurisdictionNormalized` | `string` | Required, Constant | Jurisdiction normalized.<br><br>**Value**: `"US"` |
| `MaterialType` | [`models.MaterialType1Enum`](../../doc/models/material-type-1-enum.md) | Required | Material type. |
| `ObservationAgeBasis` | `string` | Required, Constant | Observation age basis.<br><br>**Value**: `"saved_retrieved_at_exact_elapsed_time"` |
| `ObservationStatus` | [`models.ObservationStatusEnum`](../../doc/models/observation-status-enum.md) | Required | Observation status. |
| `ReasonCodes` | [`[]models.ReasonCode1Enum`](../../doc/models/reason-code-1-enum.md) | Required | Reason codes.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `15` |
| `Representation` | `string` | Required, Constant | Representation.<br><br>**Value**: `"authored_paraphrase_not_full_source"` |
| `RetrievedAt` | `string` | Required | Retrieved at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `64` |
| `SourceId` | `string` | Required | Source id.<br><br>**Constraints**: *Pattern*: `^[A-Z0-9-]{1,128}$` |
| `SourceUpdatedDate` | [`models.PolicySourceSourceUpdatedDate`](../../doc/models/containers/policy-source-source-updated-date.md) | Required | This is a container for any-of cases. |
| `SourceUpdatedDateStatus` | [`models.SourceUpdatedDateStatusEnum`](../../doc/models/source-updated-date-status-enum.md) | Required | Source updated date status. |
| `Title` | `string` | Required | Title.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2000` |
| `Url` | `string` | Required | Url.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `2000` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    policySource := models.PolicySource{
        CitationChunkIds:           []string{
            "citation_chunk_ids4",
        },
        ContentClass:               "public_reference_summary",
        CurrentPolicyApplicability: "NOT_ESTABLISHED",
        DecisionAcceptanceDeadline: models.PolicySourceDecisionAcceptanceDeadlineContainer.FromString("String7"),
        DecisionDate:               models.PolicySourceDecisionDateContainer.FromString("String1"),
        DecisionDateStatus:         models.DecisionDateStatusEnum_NOTAPPLICABLE,
        EffectiveDate:              models.PolicySourceEffectiveDateContainer.FromString("String3"),
        EffectiveDateStatus:        models.EffectiveDateStatusEnum_DOCUMENTSTATED,
        Jurisdiction:               "jurisdiction2",
        JurisdictionNormalized:     "US",
        MaterialType:               models.MaterialType1Enum_OFFICIALAPIREFERENCE,
        ObservationAgeBasis:        "saved_retrieved_at_exact_elapsed_time",
        ObservationStatus:          models.ObservationStatusEnum_STALEOBSERVATION,
        ReasonCodes:                []models.ReasonCode1Enum{
            models.ReasonCode1Enum_STALEOBSERVATION,
        },
        Representation:             "authored_paraphrase_not_full_source",
        RetrievedAt:                "retrieved_at2",
        SourceId:                   "source_id2",
        SourceUpdatedDate:          models.PolicySourceSourceUpdatedDateContainer.FromString("String1"),
        SourceUpdatedDateStatus:    models.SourceUpdatedDateStatusEnum_DOCUMENTSTATED,
        Title:                      "title6",
        Url:                        "url2",
    }

}
```

