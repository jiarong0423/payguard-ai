
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `PROCEDURALORDER` |
| `NOTAPPLICABLE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    caseStage := models.CaseStageEnum_PROCEDURALORDER

}
```

