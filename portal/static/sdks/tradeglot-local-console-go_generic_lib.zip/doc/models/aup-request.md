
# Aup Request

AupRequest.

## Structure

`AupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    aupRequest := models.AupRequest{
        Description: "description8",
    }

}
```

