
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOTMADE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    judgement := models.JudgementEnum_NOTMADE

}
```

