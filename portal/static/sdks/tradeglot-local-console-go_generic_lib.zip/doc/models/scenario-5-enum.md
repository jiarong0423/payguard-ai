
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `BURST` |
| `DISPUTE` |
| `RESET` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    scenario5 := models.Scenario5Enum_DISPUTE

}
```

