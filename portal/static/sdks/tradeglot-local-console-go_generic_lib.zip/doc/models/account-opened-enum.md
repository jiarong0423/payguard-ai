
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `BEFORECUTOFF` |
| `AFTERCUTOFF` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    accountOpened := models.AccountOpenedEnum_AFTERCUTOFF

}
```

