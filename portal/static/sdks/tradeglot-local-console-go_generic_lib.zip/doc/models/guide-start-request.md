
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GoodsType` | [`*models.GuideStartRequestGoodsType`](../../doc/models/containers/guide-start-request-goods-type.md) | Optional | This is a container for any-of cases. |
| `Scenario` | [`models.Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    guideStartRequest := models.GuideStartRequest{
        GoodsType: models.ToPointer(models.GuideStartRequestGoodsTypeContainer.FromGoodsType(models.GoodsTypeEnum_PHYSICAL)),
        Scenario:  models.Scenario2Enum_VELOCITY,
    }

}
```

