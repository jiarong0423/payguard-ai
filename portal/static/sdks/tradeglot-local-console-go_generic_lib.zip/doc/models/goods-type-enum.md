
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    goodsType := models.GoodsTypeEnum_PHYSICAL

}
```

