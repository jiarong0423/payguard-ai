
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    evidenceClass3 := models.EvidenceClass3Enum_AUTHENTICSANDBOXRESPONSE

}
```

