
# Carrier Enum

Carrier.

## Enumeration

`CarrierEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    carrier := models.CarrierEnum_USPS

}
```

