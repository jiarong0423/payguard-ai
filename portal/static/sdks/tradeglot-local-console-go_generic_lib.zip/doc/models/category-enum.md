
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UNSUPPORTEDFINANCIALPROMISE` |
| `WEAPONS` |
| `CONTROLLEDSUBSTANCES` |
| `COUNTERFEITGOODS` |
| `REGULATEDACTIVITY` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    category := models.CategoryEnum_CONTROLLEDSUBSTANCES

}
```

