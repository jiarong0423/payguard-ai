
# Flag Enum

## Enumeration

`FlagEnum`

## Fields

| Name |
|  --- |
| `ORDERRECORDABSENT` |
| `DELIVERYNOTRECORDED` |
| `DELIVERYAFTERCLAIM` |
| `CLAIMTIMEEARLIERTHANPAYMENTTIME` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    flag := models.FlagEnum_ORDERRECORDABSENT

}
```

