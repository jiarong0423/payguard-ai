
# HTTP Validation Error Exception

HTTPValidationError.

## Structure

`HTTPValidationErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Detail` | [`[]models.ValidationError`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```go
if err != nil {
    switch typedErr := err.(type) {
    case *errors.HTTPValidationErrorException:
        log.Fatalln(typedErr)
    default:
        log.Fatalln(err)
    }
}
```

