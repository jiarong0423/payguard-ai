
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTVERIFIED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    effectiveDateStatus := models.EffectiveDateStatusEnum_DOCUMENTSTATED

}
```

