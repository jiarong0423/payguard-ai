
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NOTCONFIGURED` |
| `DISCONNECTED` |
| `CONNECTED` |
| `ENUMERROR` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status11 := models.Status11Enum_CONNECTED

}
```

