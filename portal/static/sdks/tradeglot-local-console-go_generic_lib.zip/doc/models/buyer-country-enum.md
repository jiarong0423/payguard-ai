
# Buyer Country Enum

Buyer country.

## Enumeration

`BuyerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    buyerCountry := models.BuyerCountryEnum_US

}
```

