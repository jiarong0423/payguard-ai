
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    externalSend1 := models.ExternalSend1Enum_FROZEN

}
```

