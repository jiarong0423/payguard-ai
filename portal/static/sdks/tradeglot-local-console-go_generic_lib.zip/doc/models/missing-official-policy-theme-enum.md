
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCECOMPLIANCE` |
| `VELOCITYGUARD` |
| `DISPUTEMEDIATION` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    missingOfficialPolicyTheme := models.MissingOfficialPolicyThemeEnum_SOURCECOMPLIANCE

}
```

