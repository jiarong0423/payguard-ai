
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    kind1 := models.Kind1Enum_MESSAGE

}
```

