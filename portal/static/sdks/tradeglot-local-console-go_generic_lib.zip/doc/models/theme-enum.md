
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCECOMPLIANCE` |
| `VELOCITYGUARD` |
| `DISPUTEMEDIATION` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    theme := models.ThemeEnum_SOURCECOMPLIANCE

}
```

