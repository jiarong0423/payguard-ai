
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`models.CategoryEnum`](../../doc/models/category-enum.md) | Required | Category. |
| `Code` | `string` | Required, Constant | Code.<br><br>**Value**: `"keyword_requires_policy_review"` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    finding := models.Finding{
        Category: models.CategoryEnum_UNSUPPORTEDFINANCIALPROMISE,
        Code:     "keyword_requires_policy_review",
    }

}
```

