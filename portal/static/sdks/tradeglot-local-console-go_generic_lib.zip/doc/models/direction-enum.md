
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    direction := models.DirectionEnum_INBOUND

}
```

