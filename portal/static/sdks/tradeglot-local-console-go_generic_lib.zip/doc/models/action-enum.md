
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTHCONNECT` |
| `CREATEINVOICEDRAFT` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    action := models.ActionEnum_OAUTHCONNECT

}
```

