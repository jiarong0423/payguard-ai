
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `MANUALREVIEW` |
| `REVIEWEVIDENCE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status5 := models.Status5Enum_MANUALREVIEW

}
```

