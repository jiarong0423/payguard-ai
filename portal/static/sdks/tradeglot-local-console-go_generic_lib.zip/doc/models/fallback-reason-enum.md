
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDERERROR` |
| `INVALIDREPLY` |
| `LATE` |
| `NOITEMS` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    fallbackReason := models.FallbackReasonEnum_NOITEMS

}
```

