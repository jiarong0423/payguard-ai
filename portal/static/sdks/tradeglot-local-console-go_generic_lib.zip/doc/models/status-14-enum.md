
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `NORMAL` |
| `REVIEWVELOCITY` |
| `INSUFFICIENTBASELINE` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    status14 := models.Status14Enum_REVIEWVELOCITY

}
```

