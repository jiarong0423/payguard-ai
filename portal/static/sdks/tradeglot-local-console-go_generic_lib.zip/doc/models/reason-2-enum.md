
# Reason 2 Enum

Reason.

## Enumeration

`Reason2Enum`

## Fields

| Name |
|  --- |
| `MERCHANDISEORSERVICENOTRECEIVED` |
| `MERCHANDISEORSERVICENOTASDESCRIBED` |
| `UNAUTHORISED` |
| `CREDITNOTPROCESSED` |
| `DUPLICATETRANSACTION` |
| `INCORRECTAMOUNT` |
| `PAYMENTBYOTHERMEANS` |
| `CANCELEDRECURRINGBILLING` |
| `OTHER` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason2 := models.Reason2Enum_CANCELEDRECURRINGBILLING

}
```

