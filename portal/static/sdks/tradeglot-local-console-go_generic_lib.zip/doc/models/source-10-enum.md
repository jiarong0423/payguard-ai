
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3LIVE` |
| `CHANNEL3RECORDED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source10 := models.Source10Enum_CHANNEL3LIVE

}
```

