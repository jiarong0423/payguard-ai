
# Reply

Reply.

## Structure

`Reply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Chooser` | [`*models.ChooserEnum`](../../doc/models/chooser-enum.md) | Optional | Chooser. |
| `Dropped` | [`[]models.GuideDropped`](../../doc/models/guide-dropped.md) | Optional | Dropped. |
| `FallbackReason` | [`*models.ReplyFallbackReason`](../../doc/models/containers/reply-fallback-reason.md) | Optional | This is a container for any-of cases. |
| `StateChanged` | `*bool` | Optional | State changed. |
| `Template` | [`*models.TemplateEnum`](../../doc/models/template-enum.md) | Optional | Template. |
| `Text` | `*string` | Optional | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reply := models.Reply{
        Chooser:              models.ToPointer(models.ChooserEnum_KEYWORD),
        Dropped:              []models.GuideDropped{
            models.GuideDropped{
                Item:   "item2",
                Reason: models.Reason6Enum_OTHERPARTY,
            },
            models.GuideDropped{
                Item:   "item2",
                Reason: models.Reason6Enum_OTHERPARTY,
            },
        },
        FallbackReason:       models.ToPointer(models.ReplyFallbackReasonContainer.FromFallbackReason(models.FallbackReasonEnum_PROVIDERERROR)),
        StateChanged:         models.ToPointer(false),
        Template:             models.ToPointer(models.TemplateEnum_SUBTRACTION),
    }

}
```

