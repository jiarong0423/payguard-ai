
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `WORDS` |
| `WORDSPENDING` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    source9 := models.Source9Enum_WORDS

}
```

