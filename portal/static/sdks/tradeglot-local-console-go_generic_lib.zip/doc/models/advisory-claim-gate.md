
# Advisory Claim Gate

AdvisoryClaimGate.

## Structure

`AdvisoryClaimGate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClaimIndex` | `int` | Required | Claim index.<br><br>**Constraints**: `>= 0`, `<= 19` |
| `ClaimType` | [`models.ClaimTypeEnum`](../../doc/models/claim-type-enum.md) | Required | Claim type. |
| `ReasonCodes` | [`[]models.ReasonCodeEnum`](../../doc/models/reason-code-enum.md) | Required | Reason codes.<br><br>**Constraints**: *Maximum Items*: `10` |
| `Status` | [`models.StatusEnum`](../../doc/models/status-enum.md) | Required | Status. |
| `TrustedCitationChunkIds` | `[]string` | Required | Trusted citation chunk ids.<br><br>**Constraints**: *Maximum Items*: `10`, *Pattern*: `^[A-Z0-9-]{1,128}$` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    advisoryClaimGate := models.AdvisoryClaimGate{
        ClaimIndex:              19,
        ClaimType:               models.ClaimTypeEnum_FINANCIALACTION,
        ReasonCodes:             []models.ReasonCodeEnum{
            models.ReasonCodeEnum_CLAIMREFERENCETYPEMISMATCH,
            models.ReasonCodeEnum_CITATIONTHEMEMISMATCH,
            models.ReasonCodeEnum_CITATIONREGIONMISMATCH,
        },
        Status:                  models.StatusEnum_STRUCTURECOMPATIBLE,
        TrustedCitationChunkIds: []string{
            "trusted_citation_chunk_ids6",
            "trusted_citation_chunk_ids7",
            "trusted_citation_chunk_ids8",
        },
    }

}
```

