
# Case Outcome Enum

## Enumeration

`CaseOutcomeEnum`

## Fields

| Name |
|  --- |
| `SETTLEMENTAPPROVALNOTFINALMERITS` |
| `ARBITRATIONCOMPELLEDUNDERLYINGMERITSNOTDECIDED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    caseOutcome := models.CaseOutcomeEnum_SETTLEMENTAPPROVALNOTFINALMERITS

}
```

