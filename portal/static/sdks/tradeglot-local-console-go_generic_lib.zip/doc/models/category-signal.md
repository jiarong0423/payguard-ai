
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`models.CategorySignalCategory`](../../doc/models/containers/category-signal-category.md) | Required | This is a container for any-of cases. |
| `Confidence` | [`models.CategorySignalConfidence`](../../doc/models/containers/category-signal-confidence.md) | Required | This is a container for any-of cases. |
| `Source` | `string` | Required, Constant | Source.<br><br>**Value**: `"channel3"` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    categorySignal := models.CategorySignal{
        Category:             models.CategorySignalCategoryContainer.FromString("String1"),
        Confidence:           models.CategorySignalConfidenceContainer.FromConfidence(models.ConfidenceEnum_HIGH),
        Source:               "channel3",
    }

}
```

