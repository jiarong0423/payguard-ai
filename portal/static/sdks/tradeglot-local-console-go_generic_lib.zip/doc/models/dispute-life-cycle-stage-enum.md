
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PREARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    disputeLifeCycleStage := models.DisputeLifeCycleStageEnum_INQUIRY

}
```

