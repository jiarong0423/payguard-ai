
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`models.Error`](../../doc/models/error.md) | Required | What was refused and why. |

## Example

```go
if err != nil {
    switch typedErr := err.(type) {
    case *errors.ErrorBodyException:
        log.Fatalln(typedErr)
    default:
        log.Fatalln(err)
    }
}
```

