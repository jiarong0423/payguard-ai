
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OFFICIALAPIREFERENCE` |
| `OFFICIALPOLICY` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    materialType := models.MaterialTypeEnum_OFFICIALAPIREFERENCE

}
```

