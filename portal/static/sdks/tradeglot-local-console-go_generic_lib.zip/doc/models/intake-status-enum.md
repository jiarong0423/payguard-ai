
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `READYFORLOCALRULES` |
| `MANUALREVIEW` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    intakeStatus := models.IntakeStatusEnum_READYFORLOCALRULES

}
```

