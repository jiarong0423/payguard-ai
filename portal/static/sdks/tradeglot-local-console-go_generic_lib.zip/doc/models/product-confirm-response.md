
# Product Confirm Response

The seller's own choice: one of the cards they were shown, or none of them.

## Structure

`ProductConfirmResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AffectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `"False"` |
| `Card` | [`models.ProductConfirmResponseCard`](../../doc/models/containers/product-confirm-response-card.md) | Required | This is a container for any-of cases. |
| `CardDigest` | [`models.ProductConfirmResponseCardDigest`](../../doc/models/containers/product-confirm-response-card-digest.md) | Required | This is a container for any-of cases. |
| `Choice` | [`models.Choice2Enum`](../../doc/models/choice-2-enum.md) | Required | Choice. |
| `ConfirmedBy` | `string` | Required, Constant | Confirmed by.<br><br>**Value**: `"seller"` |
| `DescriptionDigest` | `string` | Required | Description digest.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |
| `EvaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |
| `RecordedAt` | [`models.ProductConfirmResponseRecordedAt`](../../doc/models/containers/product-confirm-response-recorded-at.md) | Required | This is a container for any-of cases. |
| `Source` | [`models.Source10Enum`](../../doc/models/source-10-enum.md) | Required | Source. |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    productConfirmResponse := models.ProductConfirmResponse{
        AffectsDecision:   "False",
        Card:              models.ProductConfirmResponseCardContainer.FromProductCard(models.ProductCard{
            Brand:       models.ProductCardBrandContainer.FromString("String9"),
            Category:    models.ProductCardCategoryContainer.FromString("String3"),
            ImageUrl:    models.ProductCardImageUrlContainer.FromString("String1"),
            KeyFeatures: []string{
                "key_features0",
                "key_features1",
                "key_features2",
            },
            Materials:   []string{
                "materials5",
                "materials6",
            },
            ProductId:   "product_id0",
            Title:       "title0",
        }),
        CardDigest:        models.ProductConfirmResponseCardDigestContainer.FromString("String1"),
        Choice:            models.Choice2Enum_CONFIRMED,
        ConfirmedBy:       "seller",
        DescriptionDigest: "description_digest2",
        EvaluationId:      "evaluation_id8",
        RecordedAt:        models.ProductConfirmResponseRecordedAtContainer.FromString("String1"),
        Source:            models.Source10Enum_CHANNEL3LIVE,
    }

}
```

