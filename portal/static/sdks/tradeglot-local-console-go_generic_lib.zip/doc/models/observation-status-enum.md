
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `WITHINOBSERVATIONBUDGET` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    observationStatus := models.ObservationStatusEnum_FUTUREOBSERVATION

}
```

