
# Readback 1 Enum

Readback.

## Enumeration

`Readback1Enum`

## Fields

| Name |
|  --- |
| `PROVIDEEVIDENCEPREVIEW` |
| `PROVIDEEVIDENCESUBMITTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    readback1 := models.Readback1Enum_PROVIDEEVIDENCEPREVIEW

}
```

