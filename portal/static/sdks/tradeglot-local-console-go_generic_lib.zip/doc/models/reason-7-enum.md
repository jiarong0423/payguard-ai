
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NOTHINGTOSEND` |
| `NOTRECORDED` |
| `BUDGETEXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAMERROR` |
| `CONTRACTREJECTED` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    reason7 := models.Reason7Enum_NOTHINGTOSEND

}
```

