
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```go
package main

import (
    "tradeglotlocalconsole/models"
)

func main() {
    confidence := models.ConfidenceEnum_HIGH

}
```

