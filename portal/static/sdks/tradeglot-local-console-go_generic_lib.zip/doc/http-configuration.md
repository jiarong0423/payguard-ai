
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `0` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`tradeglotlocalconsoleRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `tradeglotlocalconsole.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "tradeglotlocalconsole"
    "net/http"
)

func main() {
    httpConfiguration := tradeglotlocalconsole.CreateHttpConfiguration(
        tradeglotlocalconsole.WithTimeout(0),
        tradeglotlocalconsole.WithTransport(http.DefaultTransport),
        tradeglotlocalconsole.WithRetryConfiguration(tradeglotlocalconsole.DefaultRetryConfiguration()),
    )
}
```

