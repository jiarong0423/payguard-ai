
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| demoCsrfCredentials | [`DemoCsrfCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |
| demoSessionCredentials | [`DemoSessionCredentials`](auth/custom-header-signature-1.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "tradeglotlocalconsole"
)

func main() {
    client := tradeglotlocalconsole.NewClient(
    tradeglotlocalconsole.CreateConfiguration(
            tradeglotlocalconsole.WithHttpConfiguration(
                tradeglotlocalconsole.CreateHttpConfiguration(
                    tradeglotlocalconsole.WithTimeout(0),
                ),
            ),
            tradeglotlocalconsole.WithDemoCsrfCredentials(
                tradeglotlocalconsole.NewDemoCsrfCredentials("X-CSRF-Token"),
            ),
            tradeglotlocalconsole.WithDemoSessionCredentials(
                tradeglotlocalconsole.NewDemoSessionCredentials("X-Demo-Session"),
            ),
        ),
    )
}
```

## TradeGlot Local Console Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| AiController() | Gets AiController |
| AupController() | Gets AupController |
| DemoController() | Gets DemoController |
| GuideController() | Gets GuideController |
| HealthController() | Gets HealthController |
| OtherController() | Gets OtherController |
| PaypalController() | Gets PaypalController |
| ReferencesController() | Gets ReferencesController |
| StudioController() | Gets StudioController |

