module tradeglotlocalconsole

go 1.18

require github.com/apimatic/go-core-runtime v0.0.29
