
# Getting Started with TradeGlot Local Console

## Introduction

API of the local TradeGlot console (127.0.0.1:8000). It uses synthetic data, expects the demo session headers the console sets, and the hosted demo answers 503 on every route that would reach PayPal. Authentication: create a session with POST /api/v1/demo/sessions, then send X-Demo-Session on every other call and X-CSRF-Token on every POST. POST calls also need an Origin header equal to the console's own origin (browsers add it; scripts must set it), otherwise the API answers 403 origin_required.

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the tradeglotlocalconsole library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace tradeglotlocalconsole => ".\\tradeglot-local-console-go_generic_lib" // local path to the SDK

require tradeglotlocalconsole v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Test the SDK

`Go Testing` is used as the testing framework. To run the unit tests of the SDK, navigate to the root directory of the SDK and run the following command in the terminal:

```bash
$ go test
```

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| demoCsrfCredentials | [`DemoCsrfCredentials`](doc/auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |
| demoSessionCredentials | [`DemoSessionCredentials`](doc/auth/custom-header-signature-1.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

```go
package main

import (
    "tradeglotlocalconsole"
)

func main() {
    client := tradeglotlocalconsole.NewClient(
    tradeglotlocalconsole.CreateConfiguration(
            tradeglotlocalconsole.WithHttpConfiguration(
                tradeglotlocalconsole.CreateHttpConfiguration(
                    tradeglotlocalconsole.WithTimeout(0),
                ),
            ),
            tradeglotlocalconsole.WithDemoCsrfCredentials(
                tradeglotlocalconsole.NewDemoCsrfCredentials("X-CSRF-Token"),
            ),
            tradeglotlocalconsole.WithDemoSessionCredentials(
                tradeglotlocalconsole.NewDemoSessionCredentials("X-Demo-Session"),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`DemoCsrf (Custom Header Signature)`](doc/auth/custom-header-signature.md)
* [`DemoSession (Custom Header Signature)`](doc/auth/custom-header-signature-1.md)

## List of APIs

* [Ai](doc/controllers/ai.md)
* [Aup](doc/controllers/aup.md)
* [Demo](doc/controllers/demo.md)
* [Guide](doc/controllers/guide.md)
* [Health](doc/controllers/health.md)
* [Other](doc/controllers/other.md)
* [Paypal](doc/controllers/paypal.md)
* [References](doc/controllers/references.md)
* [Studio](doc/controllers/studio.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

