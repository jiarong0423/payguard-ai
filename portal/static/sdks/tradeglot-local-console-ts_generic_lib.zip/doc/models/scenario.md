
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `burst` | `boolean` | Required | Burst. |
| `dispute` | `boolean` | Required | Dispute. |

## Example

```ts
import { Scenario } from 'tradeglot-local-consolelib';

const scenario: Scenario = {
  burst: false,
  dispute: false,
};
```

