
# Aup Request

AupRequest.

## Structure

`AupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |

## Example

```ts
import { AupRequest } from 'tradeglot-local-consolelib';

const aupRequest: AupRequest = {
  description: 'description8',
};
```

