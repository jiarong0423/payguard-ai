
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICTESTRESPONSE` |
| `OPERATORLIVERESPONSE` |
| `LOCALRUNTIMERESPONSE` |

## Example

```ts
import { ExecutionEvidenceEnum } from 'tradeglot-local-consolelib';

const executionEvidence = ExecutionEvidenceEnum.OPERATORLIVERESPONSE;
```

