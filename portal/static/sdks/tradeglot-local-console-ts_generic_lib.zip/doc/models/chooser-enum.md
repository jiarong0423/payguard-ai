
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Keyword` |
| `Model` |
| `KeywordFallback` |
| `Form` |

## Example

```ts
import { ChooserEnum } from 'tradeglot-local-consolelib';

const chooser = ChooserEnum.Form;
```

