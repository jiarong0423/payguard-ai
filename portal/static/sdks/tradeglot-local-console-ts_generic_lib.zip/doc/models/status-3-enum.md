
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITINGFORSELLERRESPONSE` |
| `WAITINGFORBUYERRESPONSE` |
| `UNDERREVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```ts
import { Status3Enum } from 'tradeglot-local-consolelib';

const status3 = Status3Enum.OPEN;
```

