
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PaypalAccount` |
| `GuestCard` |

## Example

```ts
import { CheckoutEnum } from 'tradeglot-local-consolelib';

const checkout = CheckoutEnum.PaypalAccount;
```

