
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `goodsType` | [`GuideStartRequestGoodsType \| undefined`](../../doc/models/containers/guide-start-request-goods-type.md) | Optional | This is a container for any-of cases. |
| `scenario` | [`Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. |

## Example

```ts
import {
  GoodsTypeEnum,
  GuideStartRequest,
  Scenario2Enum,
} from 'tradeglot-local-consolelib';

const guideStartRequest: GuideStartRequest = {
  scenario: Scenario2Enum.Velocity,
  goodsType: GoodsTypeEnum.Physical,
};
```

