
# Country Rules Search Request

CountryRulesSearchRequest.

## Structure

`CountryRulesSearchRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `number \| undefined` | Optional | Limit.<br><br>**Default**: `5`<br><br>**Constraints**: `>= 1`, `<= 10` |
| `query` | `string` | Required | Query.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```ts
import { CountryRulesSearchRequest } from 'tradeglot-local-consolelib';

const countryRulesSearchRequest: CountryRulesSearchRequest = {
  query: 'query4',
  limit: 5,
};
```

