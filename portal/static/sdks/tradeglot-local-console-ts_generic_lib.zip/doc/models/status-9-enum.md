
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLYPRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOTAPPLICABLE` |

## Example

```ts
import { Status9Enum } from 'tradeglot-local-consolelib';

const status9 = Status9Enum.STRUCTURALLYPRESENT;
```

