
# Case Outcome Enum

## Enumeration

`CaseOutcomeEnum`

## Fields

| Name |
|  --- |
| `SETTLEMENTAPPROVALNOTFINALMERITS` |
| `ARBITRATIONCOMPELLEDUNDERLYINGMERITSNOTDECIDED` |

## Example

```ts
import { CaseOutcomeEnum } from 'tradeglot-local-consolelib';

const caseOutcome = CaseOutcomeEnum.SETTLEMENTAPPROVALNOTFINALMERITS;
```

