
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `string` | Required | Label. |
| `value` | `string` | Required | Value. |

## Example

```ts
import { GuideOption } from 'tradeglot-local-consolelib';

const guideOption: GuideOption = {
  label: 'label2',
  value: 'value4',
};
```

