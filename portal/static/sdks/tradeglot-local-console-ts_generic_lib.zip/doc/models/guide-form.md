
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. |
| `options` | [`GuideOption[]`](../../doc/models/guide-option.md) | Required | Options. |
| `placeholder` | [`GuideFormPlaceholder`](../../doc/models/containers/guide-form-placeholder.md) | Required | This is a container for any-of cases. |

## Example

```ts
import { GuideForm, Kind2Enum } from 'tradeglot-local-consolelib';

const guideForm: GuideForm = {
  kind: Kind2Enum.Choice,
  options: [
    {
      label: 'label2',
      value: 'value4',
    }
  ],
  placeholder: 'String3',
};
```

