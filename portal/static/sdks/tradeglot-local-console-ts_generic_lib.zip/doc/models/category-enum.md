
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UnsupportedFinancialPromise` |
| `Weapons` |
| `ControlledSubstances` |
| `CounterfeitGoods` |
| `RegulatedActivity` |

## Example

```ts
import { CategoryEnum } from 'tradeglot-local-consolelib';

const category = CategoryEnum.ControlledSubstances;
```

