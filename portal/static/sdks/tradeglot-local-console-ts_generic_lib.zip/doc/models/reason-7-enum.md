
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NothingToSend` |
| `NotRecorded` |
| `BudgetExhausted` |
| `Timeout` |
| `UpstreamError` |
| `ContractRejected` |

## Example

```ts
import { Reason7Enum } from 'tradeglot-local-consolelib';

const reason7 = Reason7Enum.NothingToSend;
```

