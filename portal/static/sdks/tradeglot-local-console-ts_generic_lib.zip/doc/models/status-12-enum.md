
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOTFOUND` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```ts
import { Status12Enum } from 'tradeglot-local-consolelib';

const status12 = Status12Enum.NOTSENT;
```

