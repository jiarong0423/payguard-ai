
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `Words` |
| `WordsPending` |

## Example

```ts
import { Source9Enum } from 'tradeglot-local-consolelib';

const source9 = Source9Enum.Words;
```

