
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |
| `sandboxReads` | [`ConnectionsResponseSandboxReads \| undefined`](../../doc/models/containers/connections-response-sandbox-reads.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import { ConnectionsResponse, ModeEnum } from 'tradeglot-local-consolelib';

const connectionsResponse: ConnectionsResponse = {
  mode: ModeEnum.Local,
  sandboxReads: true,
};
```

