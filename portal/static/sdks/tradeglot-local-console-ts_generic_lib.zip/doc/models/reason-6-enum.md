
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OtherParty` |
| `Inferred` |

## Example

```ts
import { Reason6Enum } from 'tradeglot-local-consolelib';

const reason6 = Reason6Enum.OtherParty;
```

