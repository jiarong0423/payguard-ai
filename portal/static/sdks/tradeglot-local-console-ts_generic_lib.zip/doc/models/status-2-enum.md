
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```ts
import { Status2Enum } from 'tradeglot-local-consolelib';

const status2 = Status2Enum.NOTSENT;
```

