
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `ManualReview` |
| `ReviewEvidence` |

## Example

```ts
import { Status5Enum } from 'tradeglot-local-consolelib';

const status5 = Status5Enum.ManualReview;
```

