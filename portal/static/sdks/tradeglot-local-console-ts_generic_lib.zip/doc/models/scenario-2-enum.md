
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `Preflight` |
| `Velocity` |
| `Dispute` |

## Example

```ts
import { Scenario2Enum } from 'tradeglot-local-consolelib';

const scenario2 = Scenario2Enum.Velocity;
```

