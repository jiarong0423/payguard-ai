
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `Ok` |
| `Error` |

## Example

```ts
import { OutcomeEnum } from 'tradeglot-local-consolelib';

const outcome = OutcomeEnum.Ok;
```

