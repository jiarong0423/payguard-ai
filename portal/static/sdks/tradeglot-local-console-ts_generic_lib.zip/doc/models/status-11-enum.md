
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NotConfigured` |
| `Disconnected` |
| `Connected` |
| `Error` |

## Example

```ts
import { Status11Enum } from 'tradeglot-local-consolelib';

const status11 = Status11Enum.Connected;
```

