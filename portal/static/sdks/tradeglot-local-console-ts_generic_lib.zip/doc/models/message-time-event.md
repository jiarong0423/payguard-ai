
# Message Time Event

MessageTimeEvent.

## Structure

`MessageTimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `string` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `channel` | [`ChannelEnum`](../../doc/models/channel-enum.md) | Required | Channel. |
| `direction` | [`DirectionEnum`](../../doc/models/direction-enum.md) | Required | Direction. |
| `kind` | `string` | Required, Constant | Kind.<br><br>**Value**: `'MESSAGE'` |
| `messageDigest` | `string` | Required | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `source` | `string` | Required, Constant | Source.<br><br>**Value**: `'SELLER_PROVIDED_UNVERIFIED'` |
| `topic` | [`TopicEnum`](../../doc/models/topic-enum.md) | Required | Topic. |

## Example

```ts
import {
  ChannelEnum,
  DirectionEnum,
  MessageTimeEvent,
  TopicEnum,
} from 'tradeglot-local-consolelib';

const messageTimeEvent: MessageTimeEvent = {
  at: 'at6',
  channel: ChannelEnum.EMAIL,
  direction: DirectionEnum.INBOUND,
  kind: 'MESSAGE',
  messageDigest: 'message_digest4',
  source: 'SELLER_PROVIDED_UNVERIFIED',
  topic: TopicEnum.PAYMENTNOTICE,
};
```

