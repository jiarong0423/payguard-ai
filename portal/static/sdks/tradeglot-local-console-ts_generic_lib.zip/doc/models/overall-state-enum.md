
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASENOTACTIONABLE` |
| `MANUALREVIEW` |
| `DUEDATEEXPIRED` |
| `ACTIONNOTAVAILABLE` |
| `NEEDSINPUT` |
| `READYFORLOCALREVIEW` |

## Example

```ts
import { OverallStateEnum } from 'tradeglot-local-consolelib';

const overallState = OverallStateEnum.DUEDATEEXPIRED;
```

