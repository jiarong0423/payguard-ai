
# Send Refusal Enum

## Enumeration

`SendRefusalEnum`

## Fields

| Name |
|  --- |
| `AccountIdentityUnknown` |
| `DisputeNotThisAccount` |
| `DisputeDetailRequired` |
| `SellerEvidenceAlreadySubmitted` |
| `DisputeNotAwaitingSeller` |
| `DisputeEvidenceNotOffered` |

## Example

```ts
import { SendRefusalEnum } from 'tradeglot-local-consolelib';

const sendRefusal = SendRefusalEnum.AccountIdentityUnknown;
```

