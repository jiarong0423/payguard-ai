
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `caseRef` | [`AiBriefHttpRequestCaseRef \| undefined`](../../doc/models/containers/ai-brief-http-request-case-ref.md) | Optional | This is a container for any-of cases. |
| `stage` | [`StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. |

## Example

```ts
import { AiBriefHttpRequest, StageEnum } from 'tradeglot-local-consolelib';

const aiBriefHttpRequest: AiBriefHttpRequest = {
  stage: StageEnum.VelocityGuard,
  caseRef: 'String9',
};
```

