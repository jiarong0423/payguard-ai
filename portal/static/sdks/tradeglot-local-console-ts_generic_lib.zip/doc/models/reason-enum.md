
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NothingToSend` |
| `BudgetExhausted` |
| `Timeout` |
| `UpstreamError` |
| `ContractRejected` |

## Example

```ts
import { ReasonEnum } from 'tradeglot-local-consolelib';

const reason = ReasonEnum.ContractRejected;
```

