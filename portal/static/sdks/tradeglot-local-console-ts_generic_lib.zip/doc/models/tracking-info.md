
# Tracking Info

TrackingInfo.

## Structure

`TrackingInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrierName` | [`CarrierNameEnum`](../../doc/models/carrier-name-enum.md) | Required | Carrier name. |
| `carrierNameOther` | [`TrackingInfoCarrierNameOther \| undefined`](../../doc/models/containers/tracking-info-carrier-name-other.md) | Optional | This is a container for any-of cases. |
| `trackingNumber` | `string` | Required | Tracking number.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` |

## Example

```ts
import { CarrierNameEnum, TrackingInfo } from 'tradeglot-local-consolelib';

const trackingInfo: TrackingInfo = {
  carrierName: CarrierNameEnum.TWCHUNGHWAPOST,
  trackingNumber: 'tracking_number4',
  carrierNameOther: 'String9',
};
```

