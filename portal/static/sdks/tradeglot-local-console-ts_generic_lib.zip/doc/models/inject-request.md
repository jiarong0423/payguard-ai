
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. |

## Example

```ts
import { InjectRequest, Scenario5Enum } from 'tradeglot-local-consolelib';

const injectRequest: InjectRequest = {
  scenario: Scenario5Enum.Burst,
};
```

