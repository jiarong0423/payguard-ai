
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```ts
import { SellerCountryEnum } from 'tradeglot-local-consolelib';

const sellerCountry = SellerCountryEnum.AU;
```

