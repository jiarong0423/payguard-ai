
# Ai Usage Entry

AiUsageEntry.

## Structure

`AiUsageEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `string` | Required | At. |
| `estimatedCostUsd` | [`AiUsageEntryEstimatedCostUsd \| undefined`](../../doc/models/containers/ai-usage-entry-estimated-cost-usd.md) | Optional | This is a container for any-of cases. |
| `latencyMs` | `number` | Required | Latency ms.<br><br>**Constraints**: `>= 0`, `<= 3600000` |
| `model` | [`AiUsageEntryModel \| undefined`](../../doc/models/containers/ai-usage-entry-model.md) | Optional | This is a container for any-of cases. |
| `outcome` | [`OutcomeEnum`](../../doc/models/outcome-enum.md) | Required | Outcome. |
| `stage` | [`Stage2Enum`](../../doc/models/stage-2-enum.md) | Required | Stage. |
| `tokensIn` | [`AiUsageEntryTokensIn \| undefined`](../../doc/models/containers/ai-usage-entry-tokens-in.md) | Optional | This is a container for any-of cases. |
| `tokensOut` | [`AiUsageEntryTokensOut \| undefined`](../../doc/models/containers/ai-usage-entry-tokens-out.md) | Optional | This is a container for any-of cases. |
| `tokensTotal` | [`AiUsageEntryTokensTotal \| undefined`](../../doc/models/containers/ai-usage-entry-tokens-total.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import {
  AiUsageEntry,
  OutcomeEnum,
  Stage2Enum,
} from 'tradeglot-local-consolelib';

const aiUsageEntry: AiUsageEntry = {
  at: 'at4',
  latencyMs: 38,
  outcome: OutcomeEnum.Ok,
  stage: Stage2Enum.VelocityGuard,
  estimatedCostUsd: 'String5',
  model: 'String7',
  tokensIn: 236,
  tokensOut: 94,
  tokensTotal: 158,
};
```

