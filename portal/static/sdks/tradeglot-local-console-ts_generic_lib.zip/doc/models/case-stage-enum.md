
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `ProceduralOrder` |
| `NotApplicable` |

## Example

```ts
import { CaseStageEnum } from 'tradeglot-local-consolelib';

const caseStage = CaseStageEnum.ProceduralOrder;
```

