
# Time Event

TimeEvent.

## Structure

`TimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `string` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `kind` | [`KindEnum`](../../doc/models/kind-enum.md) | Required | Kind. |
| `source` | [`Source5Enum`](../../doc/models/source-5-enum.md) | Required | Source. |

## Example

```ts
import { KindEnum, Source5Enum, TimeEvent } from 'tradeglot-local-consolelib';

const timeEvent: TimeEvent = {
  at: 'at6',
  kind: KindEnum.DELIVERY,
  source: Source5Enum.PROVIDER,
};
```

