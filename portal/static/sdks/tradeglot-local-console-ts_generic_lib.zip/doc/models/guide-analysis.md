
# Guide Analysis

GuideAnalysis.

## Structure

`GuideAnalysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [`GuideAnalysisReason`](../../doc/models/containers/guide-analysis-reason.md) | Required | This is a container for any-of cases. |
| `status` | [`Status8Enum`](../../doc/models/status-8-enum.md) | Required | Status. |
| `turn` | `number` | Required | Turn. |

## Example

```ts
import {
  GuideAnalysis,
  Reason5Enum,
  Status8Enum,
} from 'tradeglot-local-consolelib';

const guideAnalysis: GuideAnalysis = {
  reason: Reason5Enum.InvalidReply,
  status: Status8Enum.Analysing,
  turn: 236,
};
```

