
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `Name` |
| `Address` |
| `Email` |

## Example

```ts
import { FieldEnum } from 'tradeglot-local-consolelib';

const field = FieldEnum.Address;
```

