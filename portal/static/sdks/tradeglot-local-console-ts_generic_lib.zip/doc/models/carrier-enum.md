
# Carrier Enum

Carrier.

## Enumeration

`CarrierEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```ts
import { CarrierEnum } from 'tradeglot-local-consolelib';

const carrier = CarrierEnum.USPS;
```

