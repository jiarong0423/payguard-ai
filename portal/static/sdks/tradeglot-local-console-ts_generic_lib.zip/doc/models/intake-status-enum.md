
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `ReadyForLocalRules` |
| `ManualReview` |

## Example

```ts
import { IntakeStatusEnum } from 'tradeglot-local-consolelib';

const intakeStatus = IntakeStatusEnum.ReadyForLocalRules;
```

