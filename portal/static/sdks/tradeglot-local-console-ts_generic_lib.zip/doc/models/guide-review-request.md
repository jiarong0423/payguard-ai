
# Guide Review Request

GuideReviewRequest.

## Structure

`GuideReviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `change` | `string[] \| undefined` | Optional | Change.<br><br>**Constraints**: *Maximum Items*: `9`, *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-z_]+$` |
| `confirm` | `boolean \| undefined` | Optional | Confirm.<br><br>**Default**: `false` |
| `scenario` | [`GuideReviewRequestScenario \| undefined`](../../doc/models/containers/guide-review-request-scenario.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import {
  GuideReviewRequest,
  Scenario1Enum,
} from 'tradeglot-local-consolelib';

const guideReviewRequest: GuideReviewRequest = {
  change: [
    'change9',
    'change0',
    'change1'
  ],
  confirm: false,
  scenario: Scenario1Enum.Dispute,
};
```

