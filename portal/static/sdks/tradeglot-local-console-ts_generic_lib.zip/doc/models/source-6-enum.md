
# Source 6 Enum

Source.

## Enumeration

`Source6Enum`

## Fields

| Name |
|  --- |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```ts
import { Source6Enum } from 'tradeglot-local-consolelib';

const source6 = Source6Enum.SELLERPROVIDEDUNVERIFIED;
```

