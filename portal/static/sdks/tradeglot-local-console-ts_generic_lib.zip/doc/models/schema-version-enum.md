
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `EnumPayguardtimeEvidencev1` |

## Example

```ts
import { SchemaVersionEnum } from 'tradeglot-local-consolelib';

const schemaVersion = SchemaVersionEnum.EnumPayguardtimeEvidencev1;
```

