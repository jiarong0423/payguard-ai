
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATEMESSAGE` |

## Example

```ts
import { ChannelEnum } from 'tradeglot-local-consolelib';

const channel = ChannelEnum.EMAIL;
```

