
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `WITHINOBSERVATIONBUDGET` |

## Example

```ts
import { ObservationStatusEnum } from 'tradeglot-local-consolelib';

const observationStatus = ObservationStatusEnum.FUTUREOBSERVATION;
```

