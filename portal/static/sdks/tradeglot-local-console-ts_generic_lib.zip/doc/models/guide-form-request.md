
# Guide Form Request

One field ({item, value}) or one round of up to three fields ({fields: [...]}), never both.

## Structure

`GuideFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `confirmReview` | `boolean \| undefined` | Optional | Confirm review.<br><br>**Default**: `false` |
| `fields` | [`GuideFormRequestFields \| undefined`](../../doc/models/containers/guide-form-request-fields.md) | Optional | This is a container for any-of cases. |
| `item` | [`GuideFormRequestItem \| undefined`](../../doc/models/containers/guide-form-request-item.md) | Optional | This is a container for any-of cases. |
| `scenario` | [`GuideFormRequestScenario \| undefined`](../../doc/models/containers/guide-form-request-scenario.md) | Optional | This is a container for any-of cases. |
| `value` | [`GuideFormRequestValue \| undefined`](../../doc/models/containers/guide-form-request-value.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import { GuideFormRequest, Scenario1Enum } from 'tradeglot-local-consolelib';

const guideFormRequest: GuideFormRequest = {
  confirmReview: false,
  fields: [
    {
    item: 'item8',
    value: 'value8',
  }
  ],
  item: 'String1',
  scenario: Scenario1Enum.Preflight,
  value: 'String1',
};
```

