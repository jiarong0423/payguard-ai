
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```ts
import { StageEnum } from 'tradeglot-local-consolelib';

const stage = StageEnum.DisputeMediation;
```

