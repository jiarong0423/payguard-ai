
# Error Body Error

The error body every refusal uses.

## Structure

`ErrorBodyError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof ErrorBodyError) {
    console.log(error.result);
  }
}
```

