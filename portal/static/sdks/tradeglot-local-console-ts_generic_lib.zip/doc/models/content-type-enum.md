
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `EnumImagejpeg` |
| `EnumImagegif` |
| `EnumImagepng` |
| `EnumApplicationpdf` |

## Example

```ts
import { ContentTypeEnum } from 'tradeglot-local-consolelib';

const contentType = ContentTypeEnum.EnumImagepng;
```

