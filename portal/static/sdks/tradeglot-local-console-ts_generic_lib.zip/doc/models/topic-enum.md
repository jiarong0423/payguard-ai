
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENTNOTICE` |
| `ORDERDETAILSREQUEST` |
| `ORDERDETAILSPROVIDED` |
| `DELIVERYNOTICE` |
| `REFUNDREQUEST` |
| `OTHER` |

## Example

```ts
import { TopicEnum } from 'tradeglot-local-consolelib';

const topic = TopicEnum.ORDERDETAILSPROVIDED;
```

