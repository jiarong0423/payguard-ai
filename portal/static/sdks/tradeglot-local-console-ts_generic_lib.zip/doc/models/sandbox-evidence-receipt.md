
# Sandbox Evidence Receipt

SandboxEvidenceReceipt.

## Structure

`SandboxEvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`ActionEnum`](../../doc/models/action-enum.md) | Required | Action. |
| `environment` | `string` | Required, Constant | Environment.<br><br>**Value**: `'sandbox'` |
| `evidenceClass` | [`EvidenceClass3Enum`](../../doc/models/evidence-class-3-enum.md) | Required | Evidence class. |
| `externalSend` | `string` | Required, Constant | External send.<br><br>**Value**: `'FROZEN'` |
| `invoiceId` | [`SandboxEvidenceReceiptInvoiceId`](../../doc/models/containers/sandbox-evidence-receipt-invoice-id.md) | Required | This is a container for any-of cases. |
| `observedAt` | `string` | Required | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `paypalDebugId` | [`SandboxEvidenceReceiptPaypalDebugId`](../../doc/models/containers/sandbox-evidence-receipt-paypal-debug-id.md) | Required | This is a container for any-of cases. |
| `proofKind` | `string` | Required, Constant | Proof kind.<br><br>**Value**: `'POST_RESPONSE_ONLY'` |
| `schemaVersion` | `number` | Required, Constant | Schema version.<br><br>**Value**: `1` |
| `separateGetReadback` | `string` | Required, Constant | Separate get readback.<br><br>**Value**: `'False'` |
| `status` | [`Status10Enum`](../../doc/models/status-10-enum.md) | Required | Status. |

## Example

```ts
import {
  ActionEnum,
  EvidenceClass3Enum,
  SandboxEvidenceReceipt,
  Status10Enum,
} from 'tradeglot-local-consolelib';

const sandboxEvidenceReceipt: SandboxEvidenceReceipt = {
  action: ActionEnum.OAUTHCONNECT,
  environment: 'sandbox',
  evidenceClass: EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE,
  externalSend: 'FROZEN',
  invoiceId: 'String5',
  observedAt: 'observed_at8',
  paypalDebugId: 'String5',
  proofKind: 'POST_RESPONSE_ONLY',
  schemaVersion: 1,
  separateGetReadback: 'False',
  status: Status10Enum.CONNECTED,
};
```

