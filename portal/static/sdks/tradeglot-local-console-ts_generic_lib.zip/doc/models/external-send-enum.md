
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```ts
import { ExternalSendEnum } from 'tradeglot-local-consolelib';

const externalSend = ExternalSendEnum.FROZEN;
```

