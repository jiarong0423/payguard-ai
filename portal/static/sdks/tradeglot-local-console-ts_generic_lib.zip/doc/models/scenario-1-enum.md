
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `Preflight` |
| `Velocity` |
| `Dispute` |

## Example

```ts
import { Scenario1Enum } from 'tradeglot-local-consolelib';

const scenario1 = Scenario1Enum.Velocity;
```

