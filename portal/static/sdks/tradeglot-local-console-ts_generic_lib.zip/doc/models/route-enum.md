
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `Physical` |
| `Digital` |
| `Service` |
| `Unknown` |

## Example

```ts
import { RouteEnum } from 'tradeglot-local-consolelib';

const route = RouteEnum.Physical;
```

