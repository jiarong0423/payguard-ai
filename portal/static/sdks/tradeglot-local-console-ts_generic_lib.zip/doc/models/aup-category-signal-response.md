
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `affectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `'False'` |
| `reason` | [`AupCategorySignalResponseReason`](../../doc/models/containers/aup-category-signal-response-reason.md) | Required | This is a container for any-of cases. |
| `signal` | [`AupCategorySignalResponseSignal`](../../doc/models/containers/aup-category-signal-response-signal.md) | Required | This is a container for any-of cases. |
| `status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Required | Status. |

## Example

```ts
import {
  AupCategorySignalResponse,
  ConfidenceEnum,
  ReasonEnum,
  Status2Enum,
} from 'tradeglot-local-consolelib';

const aupCategorySignalResponse: AupCategorySignalResponse = {
  affectsDecision: 'False',
  reason: ReasonEnum.BudgetExhausted,
  signal: {
    category: 'String9',
    confidence: ConfidenceEnum.HIGH,
    source: 'channel3',
  },
  status: Status2Enum.NOTSENT,
};
```

