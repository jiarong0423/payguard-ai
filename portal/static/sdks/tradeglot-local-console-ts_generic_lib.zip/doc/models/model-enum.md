
# Model Enum

Model.

## Enumeration

`ModelEnum`

## Fields

| Name |
|  --- |
| `EnumGemini38flash` |
| `Nvidianemotron3nano4b` |

## Example

```ts
import { ModelEnum } from 'tradeglot-local-consolelib';

const model = ModelEnum.EnumGemini38flash;
```

