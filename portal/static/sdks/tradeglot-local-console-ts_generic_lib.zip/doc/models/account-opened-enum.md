
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `Unknown` |
| `BeforeCutoff` |
| `AfterCutoff` |

## Example

```ts
import { AccountOpenedEnum } from 'tradeglot-local-consolelib';

const accountOpened = AccountOpenedEnum.AfterCutoff;
```

