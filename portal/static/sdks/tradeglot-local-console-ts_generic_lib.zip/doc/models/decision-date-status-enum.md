
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTSTATEDINREVIEWEDDOCUMENT` |
| `NOTAPPLICABLE` |

## Example

```ts
import { DecisionDateStatusEnum } from 'tradeglot-local-consolelib';

const decisionDateStatus = DecisionDateStatusEnum.DOCUMENTSTATED;
```

