
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `Normal` |
| `ReviewVelocity` |
| `InsufficientBaseline` |

## Example

```ts
import { Status14Enum } from 'tradeglot-local-consolelib';

const status14 = Status14Enum.ReviewVelocity;
```

