
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `Channel3Live` |
| `Channel3Recorded` |

## Example

```ts
import { Source11Enum } from 'tradeglot-local-consolelib';

const source11 = Source11Enum.Channel3Live;
```

