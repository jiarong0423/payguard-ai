
# Reference Filters

ReferenceFilters.

## Structure

`ReferenceFilters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ageBasis` | `string` | Required, Constant | Age basis.<br><br>**Value**: `'source_updated_date_utc_calendar'` |
| `asOf` | [`ReferenceFiltersAsOf`](../../doc/models/containers/reference-filters-as-of.md) | Required | This is a container for any-of cases. |
| `caseStage` | [`CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Required | Case stage. |
| `jurisdiction` | `string` | Required, Constant | Jurisdiction.<br><br>**Value**: `'US'` |
| `limit` | `number` | Required | Limit.<br><br>**Constraints**: `>= 1`, `<= 10` |
| `materialTypes` | [`MaterialType4Enum[]`](../../doc/models/material-type-4-enum.md) | Required | Material types.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `3` |
| `maxSourceAgeDays` | [`ReferenceFiltersMaxSourceAgeDays`](../../doc/models/containers/reference-filters-max-source-age-days.md) | Required | This is a container for any-of cases. |
| `requireKnownSourceDate` | `boolean` | Required | Require known source date. |
| `theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```ts
import {
  CaseStage2Enum,
  MaterialType4Enum,
  ReferenceFilters,
  ThemeEnum,
} from 'tradeglot-local-consolelib';

const referenceFilters: ReferenceFilters = {
  ageBasis: 'source_updated_date_utc_calendar',
  asOf: 'String9',
  caseStage: CaseStage2Enum.ProceduralOrder,
  jurisdiction: 'US',
  limit: 10,
  materialTypes: [
    MaterialType4Enum.OfficialPolicy,
    MaterialType4Enum.PublicCourtOrderCopy
  ],
  maxSourceAgeDays: 238,
  requireKnownSourceDate: false,
  theme: ThemeEnum.DisputeMediation,
};
```

