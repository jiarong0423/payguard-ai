
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDERRECORDCREATED` |
| `DELIVERY` |
| `CLAIMOPENED` |

## Example

```ts
import { KindEnum } from 'tradeglot-local-consolelib';

const kind = KindEnum.DELIVERY;
```

