
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `Channel3Live` |
| `Channel3Recorded` |

## Example

```ts
import { Source10Enum } from 'tradeglot-local-consolelib';

const source10 = Source10Enum.Channel3Live;
```

