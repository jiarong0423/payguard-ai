
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOTPERFORMED` |
| `PERFORMED` |

## Example

```ts
import { ProviderSubmissionEnum } from 'tradeglot-local-consolelib';

const providerSubmission = ProviderSubmissionEnum.NOTPERFORMED;
```

