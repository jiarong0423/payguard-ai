
# Transaction

Transaction.

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `string` | Required | Amount. |
| `currency` | `string` | Required | Currency. |
| `occurredAt` | `string` | Required | Occurred at. |
| `orderId` | `string` | Required | Order id. |

## Example

```ts
import { Transaction } from 'tradeglot-local-consolelib';

const transaction: Transaction = {
  amount: 'amount0',
  currency: 'currency8',
  occurredAt: 'occurred_at2',
  orderId: 'order_id2',
};
```

