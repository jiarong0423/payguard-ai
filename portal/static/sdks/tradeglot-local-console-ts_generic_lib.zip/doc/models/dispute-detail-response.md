
# Dispute Detail Response

DisputeDetailResponse.

## Structure

`DisputeDetailResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `createTime` | `string` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` |
| `dataSourceLabel` | [`DataSourceLabelEnum`](../../doc/models/data-source-label-enum.md) | Required | Data source label. |
| `disputeAmount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. |
| `disputeChannel` | [`DisputeDetailResponseDisputeChannel \| undefined`](../../doc/models/containers/dispute-detail-response-dispute-channel.md) | Optional | This is a container for any-of cases. |
| `disputeId` | `string` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` |
| `disputeLifeCycleStage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `disputeState` | [`DisputeDetailResponseDisputeState \| undefined`](../../doc/models/containers/dispute-detail-response-dispute-state.md) | Optional | This is a container for any-of cases. |
| `disputedTransactions` | [`DisputedTransaction[]`](../../doc/models/disputed-transaction.md) | Required | Disputed transactions.<br><br>**Constraints**: *Maximum Items*: `10` |
| `environment` | `string` | Required, Constant | Environment.<br><br>**Value**: `'sandbox'` |
| `evidenceClass` | [`EvidenceClassEnum`](../../doc/models/evidence-class-enum.md) | Required | Evidence class. |
| `evidences` | [`DisputeEvidenceRow[]`](../../doc/models/dispute-evidence-row.md) | Required | Evidences.<br><br>**Constraints**: *Maximum Items*: `20` |
| `observedAt` | `string` | Required | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `paypalDebugId` | [`DisputeDetailResponsePaypalDebugId \| undefined`](../../doc/models/containers/dispute-detail-response-paypal-debug-id.md) | Optional | This is a container for any-of cases. |
| `providerSubmission` | [`ProviderSubmissionEnum`](../../doc/models/provider-submission-enum.md) | Required | Provider submission. |
| `readback` | `string` | Required, Constant | Readback.<br><br>**Value**: `'GET_DETAIL'` |
| `reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `sellerResponseDueDate` | [`DisputeDetailResponseSellerResponseDueDate \| undefined`](../../doc/models/containers/dispute-detail-response-seller-response-due-date.md) | Optional | This is a container for any-of cases. |
| `source` | [`SourceEnum`](../../doc/models/source-enum.md) | Required | Source. |
| `status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |
| `updateTime` | [`DisputeDetailResponseUpdateTime \| undefined`](../../doc/models/containers/dispute-detail-response-update-time.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import {
  DataSourceLabelEnum,
  DisputeDetailResponse,
  DisputeLifeCycleStageEnum,
  EvidenceClassEnum,
  ProviderSubmissionEnum,
  Reason2Enum,
  Source3Enum,
  SourceEnum,
  Status3Enum,
} from 'tradeglot-local-consolelib';

const disputeDetailResponse: DisputeDetailResponse = {
  createTime: 'create_time6',
  dataSourceLabel: DataSourceLabelEnum.Sandbox,
  disputeAmount: {
    currencyCode: 'currency_code6',
    value: 'value0',
  },
  disputeId: 'dispute_id2',
  disputeLifeCycleStage: DisputeLifeCycleStageEnum.UNKNOWN,
  disputedTransactions: [
    {
      sellerTransactionId: 'seller_transaction_id2',
      grossAmount: {
        currencyCode: 'currency_code0',
        value: 'value6',
      },
      sellerProtectionEligible: true,
      transactionStatus: 'String7',
    }
  ],
  environment: 'sandbox',
  evidenceClass: EvidenceClassEnum.SYNTHETICTESTRESPONSE,
  evidences: [
    {
      evidenceType: 'evidence_type2',
      source: Source3Enum.SUBMITTEDBYPARTNER,
      action: 'String1',
      date: 'String9',
    }
  ],
  observedAt: 'observed_at4',
  providerSubmission: ProviderSubmissionEnum.NOTPERFORMED,
  readback: 'GET_DETAIL',
  reason: Reason2Enum.MERCHANDISEORSERVICENOTRECEIVED,
  source: SourceEnum.PaypalSandbox,
  status: Status3Enum.CLOSED,
  disputeChannel: 'String5',
  disputeState: 'String9',
  paypalDebugId: 'String1',
  sellerResponseDueDate: 'String9',
  updateTime: 'String9',
};
```

