
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `string` | Required | Item. |
| `reason` | [`Reason6Enum`](../../doc/models/reason-6-enum.md) | Required | Reason. |

## Example

```ts
import { GuideDropped, Reason6Enum } from 'tradeglot-local-consolelib';

const guideDropped: GuideDropped = {
  item: 'item6',
  reason: Reason6Enum.OtherParty,
};
```

