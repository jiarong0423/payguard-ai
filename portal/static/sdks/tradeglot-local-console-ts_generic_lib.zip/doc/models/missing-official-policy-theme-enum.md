
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```ts
import { MissingOfficialPolicyThemeEnum } from 'tradeglot-local-consolelib';

const missingOfficialPolicyTheme = MissingOfficialPolicyThemeEnum.SourceCompliance;
```

