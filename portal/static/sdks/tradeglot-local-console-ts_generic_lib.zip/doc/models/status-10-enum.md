
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```ts
import { Status10Enum } from 'tradeglot-local-consolelib';

const status10 = Status10Enum.CONNECTED;
```

