
# Paypal Status Response

PaypalStatusResponse.

## Structure

`PaypalStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `configured` | `boolean` | Required | Configured. |
| `environment` | `string` | Required, Constant | Environment.<br><br>**Value**: `'sandbox'` |
| `evidenceReceipt` | [`PaypalStatusResponseEvidenceReceipt`](../../doc/models/containers/paypal-status-response-evidence-receipt.md) | Required | This is a container for any-of cases. |
| `lastVerifiedAt` | [`PaypalStatusResponseLastVerifiedAt`](../../doc/models/containers/paypal-status-response-last-verified-at.md) | Required | This is a container for any-of cases. |
| `source` | `string` | Required, Constant | Source.<br><br>**Value**: `'paypal_sandbox'` |
| `status` | [`Status11Enum`](../../doc/models/status-11-enum.md) | Required | Status. |

## Example

```ts
import {
  ActionEnum,
  EvidenceClass3Enum,
  PaypalStatusResponse,
  Status10Enum,
  Status11Enum,
} from 'tradeglot-local-consolelib';

const paypalStatusResponse: PaypalStatusResponse = {
  configured: false,
  environment: 'sandbox',
  evidenceReceipt: {
    action: ActionEnum.OAUTHCONNECT,
    environment: 'sandbox',
    evidenceClass: EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE,
    externalSend: 'FROZEN',
    invoiceId: 'String5',
    observedAt: 'observed_at8',
    paypalDebugId: 'String5',
    proofKind: 'POST_RESPONSE_ONLY',
    schemaVersion: 1,
    separateGetReadback: 'False',
    status: Status10Enum.CONNECTED,
  },
  lastVerifiedAt: 'String3',
  source: 'paypal_sandbox',
  status: Status11Enum.Connected,
};
```

