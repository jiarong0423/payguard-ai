
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```ts
import { DirectionEnum } from 'tradeglot-local-consolelib';

const direction = DirectionEnum.INBOUND;
```

