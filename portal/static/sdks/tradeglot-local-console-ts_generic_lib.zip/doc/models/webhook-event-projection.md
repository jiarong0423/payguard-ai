
# Webhook Event Projection

All that is kept after a SUCCESS: identifiers and status only, no amounts, payer data, links or summary.

## Structure

`WebhookEventProjection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `eventType` | [`WebhookEventProjectionEventType`](../../doc/models/containers/webhook-event-projection-event-type.md) | Required | This is a container for any-of cases. |
| `id` | [`WebhookEventProjectionId`](../../doc/models/containers/webhook-event-projection-id.md) | Required | This is a container for any-of cases. |
| `resourceId` | [`WebhookEventProjectionResourceId`](../../doc/models/containers/webhook-event-projection-resource-id.md) | Required | This is a container for any-of cases. |
| `resourceStatus` | [`WebhookEventProjectionResourceStatus`](../../doc/models/containers/webhook-event-projection-resource-status.md) | Required | This is a container for any-of cases. |
| `resourceType` | [`WebhookEventProjectionResourceType`](../../doc/models/containers/webhook-event-projection-resource-type.md) | Required | This is a container for any-of cases. |

## Example

```ts
import { WebhookEventProjection } from 'tradeglot-local-consolelib';

const webhookEventProjection: WebhookEventProjection = {
  eventType: 'String9',
  id: 'String9',
  resourceId: 'String5',
  resourceStatus: 'String1',
  resourceType: 'String3',
};
```

