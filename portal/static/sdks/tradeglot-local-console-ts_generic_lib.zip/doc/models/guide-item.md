
# Guide Item

GuideItem.

## Structure

`GuideItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chunk` | [`GuideItemChunk`](../../doc/models/containers/guide-item-chunk.md) | Required | This is a container for any-of cases. |
| `form` | [`GuideItemForm`](../../doc/models/containers/guide-item-form.md) | Required | This is a container for any-of cases. |
| `id` | `string` | Required | Id. |
| `label` | `string` | Required | Label. |
| `source` | [`Source8Enum`](../../doc/models/source-8-enum.md) | Required | Source. |
| `status` | [`Status9Enum`](../../doc/models/status-9-enum.md) | Required | Status. |

## Example

```ts
import {
  GuideItem,
  Kind2Enum,
  Source8Enum,
  Status9Enum,
} from 'tradeglot-local-consolelib';

const guideItem: GuideItem = {
  chunk: 'String7',
  form: {
    kind: Kind2Enum.Choice,
    options: [
      {
        label: 'label2',
        value: 'value4',
      }
    ],
    placeholder: 'String9',
  },
  id: 'id0',
  label: 'label0',
  source: Source8Enum.OFFICIAL,
  status: Status9Enum.UNCLEAR,
};
```

