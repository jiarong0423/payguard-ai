
# Time Evidence 1

Time evidence.

## Structure

`TimeEvidence1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `advisoryOnly` | `boolean \| undefined` | Optional | Advisory only. |
| `events` | [`TimeEvidence1Events[] \| undefined`](../../doc/models/containers/time-evidence-1-events.md) | Optional | This is Array of a container for any-of cases.<br><br>**Constraints**: *Minimum Items*: `2`, *Maximum Items*: `30` |
| `flags` | [`FlagEnum[] \| undefined`](../../doc/models/flag-enum.md) | Optional | Flags.<br><br>**Constraints**: *Maximum Items*: `4` |
| `gapsSeconds` | [`TimeGaps \| undefined`](../../doc/models/time-gaps.md) | Optional | TimeGaps. |
| `judgement` | [`JudgementEnum \| undefined`](../../doc/models/judgement-enum.md) | Optional | Judgement. |
| `schemaVersion` | [`SchemaVersionEnum \| undefined`](../../doc/models/schema-version-enum.md) | Optional | Schema version. |

## Example

```ts
import {
  ChannelEnum,
  DirectionEnum,
  FlagEnum,
  JudgementEnum,
  TimeEvidence1,
  TopicEnum,
} from 'tradeglot-local-consolelib';

const timeEvidence1: TimeEvidence1 = {
  advisoryOnly: false,
  events: [
    {
      at: 'at4',
      channel: ChannelEnum.EMAIL,
      direction: DirectionEnum.INBOUND,
      kind: 'kind6',
      messageDigest: 'message_digest2',
      source: 'source4',
      topic: TopicEnum.ORDERDETAILSPROVIDED,
    },
    {
      at: 'at4',
      channel: ChannelEnum.EMAIL,
      direction: DirectionEnum.INBOUND,
      kind: 'kind6',
      messageDigest: 'message_digest2',
      source: 'source4',
      topic: TopicEnum.ORDERDETAILSPROVIDED,
    }
  ],
  flags: [
    FlagEnum.ORDERRECORDABSENT,
    FlagEnum.DELIVERYNOTRECORDED
  ],
  gapsSeconds: {
    deliveryToClaim: 210,
    paymentToClaim: 154,
    paymentToDelivery: 192,
    paymentToOrderRecord: 208,
  },
  judgement: JudgementEnum.NOTMADE,
};
```

