
# Reason 2 Enum

Reason.

## Enumeration

`Reason2Enum`

## Fields

| Name |
|  --- |
| `MERCHANDISEORSERVICENOTRECEIVED` |
| `MERCHANDISEORSERVICENOTASDESCRIBED` |
| `UNAUTHORISED` |
| `CREDITNOTPROCESSED` |
| `DUPLICATETRANSACTION` |
| `INCORRECTAMOUNT` |
| `PAYMENTBYOTHERMEANS` |
| `CANCELEDRECURRINGBILLING` |
| `OTHER` |

## Example

```ts
import { Reason2Enum } from 'tradeglot-local-consolelib';

const reason2 = Reason2Enum.CANCELEDRECURRINGBILLING;
```

