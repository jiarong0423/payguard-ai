
# Aup Acknowledge Request

AupAcknowledgeRequest.

## Structure

`AupAcknowledgeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `choice` | [`ChoiceEnum`](../../doc/models/choice-enum.md) | Required | Choice. |
| `descriptionDigest` | `string` | Required | Description digest.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |
| `evaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |

## Example

```ts
import {
  AupAcknowledgeRequest,
  ChoiceEnum,
} from 'tradeglot-local-consolelib';

const aupAcknowledgeRequest: AupAcknowledgeRequest = {
  choice: ChoiceEnum.ACKNOWLEDGEANDCONTINUE,
  descriptionDigest: 'description_digest0',
  evaluationId: 'evaluation_id6',
};
```

