
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURECOMPATIBLE` |
| `INCOMPLETEEVIDENCE` |
| `REJECTED` |

## Example

```ts
import { StatusEnum } from 'tradeglot-local-consolelib';

const status = StatusEnum.REJECTED;
```

