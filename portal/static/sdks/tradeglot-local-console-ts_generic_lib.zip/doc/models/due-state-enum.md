
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```ts
import { DueStateEnum } from 'tradeglot-local-consolelib';

const dueState = DueStateEnum.OPEN;
```

