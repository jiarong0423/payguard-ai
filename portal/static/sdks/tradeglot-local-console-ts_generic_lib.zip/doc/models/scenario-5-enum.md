
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `Burst` |
| `Dispute` |
| `Reset` |

## Example

```ts
import { Scenario5Enum } from 'tradeglot-local-consolelib';

const scenario5 = Scenario5Enum.Dispute;
```

