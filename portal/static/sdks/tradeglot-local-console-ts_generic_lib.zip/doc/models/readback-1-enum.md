
# Readback 1 Enum

Readback.

## Enumeration

`Readback1Enum`

## Fields

| Name |
|  --- |
| `PROVIDEEVIDENCEPREVIEW` |
| `PROVIDEEVIDENCESUBMITTED` |

## Example

```ts
import { Readback1Enum } from 'tradeglot-local-consolelib';

const readback1 = Readback1Enum.PROVIDEEVIDENCEPREVIEW;
```

