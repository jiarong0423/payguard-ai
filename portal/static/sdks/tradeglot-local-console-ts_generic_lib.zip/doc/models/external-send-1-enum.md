
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```ts
import { ExternalSend1Enum } from 'tradeglot-local-consolelib';

const externalSend1 = ExternalSend1Enum.FROZEN;
```

