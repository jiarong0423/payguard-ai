
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |

## Example

```ts
import { MaterialTypeEnum } from 'tradeglot-local-consolelib';

const materialType = MaterialTypeEnum.OfficialApiReference;
```

