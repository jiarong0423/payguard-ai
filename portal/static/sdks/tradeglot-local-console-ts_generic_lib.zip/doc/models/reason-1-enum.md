
# Reason 1 Enum

Reason.

## Enumeration

`Reason1Enum`

## Fields

| Name |
|  --- |
| `CatalogueMatch` |
| `LiveCatalogueMatch` |
| `DigitalWord` |
| `ServiceWord` |
| `FilteredConflict` |
| `NoCloseMatch` |
| `NothingToMatch` |

## Example

```ts
import { Reason1Enum } from 'tradeglot-local-consolelib';

const reason1 = Reason1Enum.DigitalWord;
```

