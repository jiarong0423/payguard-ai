
# Product Reference Response

Up to three Channel3 products for the seller to pick from; advisory, never changes the AUP decision.

## Structure

`ProductReferenceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `affectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `'False'` |
| `cards` | [`ProductCard[]`](../../doc/models/product-card.md) | Required | Cards.<br><br>**Constraints**: *Maximum Items*: `3` |
| `reason` | [`ProductReferenceResponseReason`](../../doc/models/containers/product-reference-response-reason.md) | Required | This is a container for any-of cases. |
| `recordedAt` | [`ProductReferenceResponseRecordedAt`](../../doc/models/containers/product-reference-response-recorded-at.md) | Required | This is a container for any-of cases. |
| `source` | [`ProductReferenceResponseSource`](../../doc/models/containers/product-reference-response-source.md) | Required | This is a container for any-of cases. |
| `status` | [`Status12Enum`](../../doc/models/status-12-enum.md) | Required | Status. |

## Example

```ts
import {
  ProductReferenceResponse,
  Reason7Enum,
  Source11Enum,
  Status12Enum,
} from 'tradeglot-local-consolelib';

const productReferenceResponse: ProductReferenceResponse = {
  affectsDecision: 'False',
  cards: [
    {
      brand: 'String3',
      category: 'String7',
      imageUrl: 'String5',
      keyFeatures: [
        'key_features4',
        'key_features5',
        'key_features6'
      ],
      materials: [
        'materials9',
        'materials0'
      ],
      productId: 'product_id4',
      title: 'title4',
    }
  ],
  reason: Reason7Enum.NothingToSend,
  recordedAt: 'String9',
  source: Source11Enum.Channel3Live,
  status: Status12Enum.NOTFOUND,
};
```

