
# Guide Reply

GuideReply.

## Structure

`GuideReply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chooser` | [`ChooserEnum`](../../doc/models/chooser-enum.md) | Required | Chooser. |
| `dropped` | [`GuideDropped[]`](../../doc/models/guide-dropped.md) | Required | Dropped. |
| `fallbackReason` | [`GuideReplyFallbackReason`](../../doc/models/containers/guide-reply-fallback-reason.md) | Required | This is a container for any-of cases. |
| `stateChanged` | `boolean` | Required | State changed. |
| `template` | [`TemplateEnum`](../../doc/models/template-enum.md) | Required | Template. |
| `text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```ts
import {
  ChooserEnum,
  FallbackReasonEnum,
  GuideReply,
  Reason6Enum,
  TemplateEnum,
} from 'tradeglot-local-consolelib';

const guideReply: GuideReply = {
  chooser: ChooserEnum.None,
  dropped: [
    {
      item: 'item2',
      reason: Reason6Enum.OtherParty,
    }
  ],
  fallbackReason: FallbackReasonEnum.Late,
  stateChanged: false,
  template: TemplateEnum.NOGUARANTEE,
  text: 'text6',
};
```

