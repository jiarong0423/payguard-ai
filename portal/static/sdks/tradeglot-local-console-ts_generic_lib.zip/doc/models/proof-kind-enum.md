
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POSTRESPONSEONLY` |

## Example

```ts
import { ProofKindEnum } from 'tradeglot-local-consolelib';

const proofKind = ProofKindEnum.POSTRESPONSEONLY;
```

