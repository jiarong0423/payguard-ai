
# Time Gaps

TimeGaps.

## Structure

`TimeGaps`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deliveryToClaim` | [`TimeGapsDeliveryToClaim`](../../doc/models/containers/time-gaps-delivery-to-claim.md) | Required | This is a container for any-of cases. |
| `paymentToClaim` | [`TimeGapsPaymentToClaim`](../../doc/models/containers/time-gaps-payment-to-claim.md) | Required | This is a container for any-of cases. |
| `paymentToDelivery` | [`TimeGapsPaymentToDelivery`](../../doc/models/containers/time-gaps-payment-to-delivery.md) | Required | This is a container for any-of cases. |
| `paymentToOrderRecord` | [`TimeGapsPaymentToOrderRecord`](../../doc/models/containers/time-gaps-payment-to-order-record.md) | Required | This is a container for any-of cases. |

## Example

```ts
import { TimeGaps } from 'tradeglot-local-consolelib';

const timeGaps: TimeGaps = {
  deliveryToClaim: 152,
  paymentToClaim: 212,
  paymentToDelivery: 222,
  paymentToOrderRecord: 10,
};
```

