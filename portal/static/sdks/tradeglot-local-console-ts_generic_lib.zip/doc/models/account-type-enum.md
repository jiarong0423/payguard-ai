
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `Personal` |
| `Business` |

## Example

```ts
import { AccountTypeEnum } from 'tradeglot-local-consolelib';

const accountType = AccountTypeEnum.Personal;
```

