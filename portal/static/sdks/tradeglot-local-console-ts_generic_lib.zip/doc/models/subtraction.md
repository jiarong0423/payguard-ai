
# Subtraction

Subtraction.

## Structure

`Subtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `left` | `number \| undefined` | Optional | Left. |
| `needed` | `number \| undefined` | Optional | Needed. |
| `taken` | `number \| undefined` | Optional | Taken. |
| `text` | `string \| undefined` | Optional | Text. |

## Example

```ts
import { Subtraction } from 'tradeglot-local-consolelib';

const subtraction: Subtraction = {
  left: 232,
  needed: 102,
  taken: 90,
  text: 'text6',
};
```

