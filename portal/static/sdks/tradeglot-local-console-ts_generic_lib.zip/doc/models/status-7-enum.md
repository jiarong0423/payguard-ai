
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NeedsReview` |
| `DraftReady` |
| `LocalDraftReviewed` |

## Example

```ts
import { Status7Enum } from 'tradeglot-local-consolelib';

const status7 = Status7Enum.NeedsReview;
```

