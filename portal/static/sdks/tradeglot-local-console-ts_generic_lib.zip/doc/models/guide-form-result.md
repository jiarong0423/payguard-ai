
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `string` | Required | Item. |
| `valid` | `boolean` | Required | Valid. |

## Example

```ts
import { GuideFormResult } from 'tradeglot-local-consolelib';

const guideFormResult: GuideFormResult = {
  item: 'item2',
  valid: false,
};
```

