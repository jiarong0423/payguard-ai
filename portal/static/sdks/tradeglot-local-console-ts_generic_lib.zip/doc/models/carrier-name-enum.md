
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```ts
import { CarrierNameEnum } from 'tradeglot-local-consolelib';

const carrierName = CarrierNameEnum.JPJAPANPOST;
```

