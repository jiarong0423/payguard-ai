
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTHCONNECT` |
| `CREATEINVOICEDRAFT` |

## Example

```ts
import { ActionEnum } from 'tradeglot-local-consolelib';

const action = ActionEnum.OAUTHCONNECT;
```

