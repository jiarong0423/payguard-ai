
# Source 8 Enum

Source.

## Enumeration

`Source8Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL` |
| `SUGGESTION` |

## Example

```ts
import { Source8Enum } from 'tradeglot-local-consolelib';

const source8 = Source8Enum.OFFICIAL;
```

