
# Activity

Activity.

## Structure

`Activity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `string` | Required | At. |
| `id` | `string` | Required | Id. |
| `kind` | `string` | Required | Kind. |
| `label` | `string` | Required | Label. |
| `source` | `string` | Required, Constant | Source.<br><br>**Value**: `'synthetic'` |

## Example

```ts
import { Activity } from 'tradeglot-local-consolelib';

const activity: Activity = {
  at: 'at4',
  id: 'id8',
  kind: 'kind6',
  label: 'label8',
  source: 'synthetic',
};
```

