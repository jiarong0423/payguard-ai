
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `Any` |
| `ProceduralOrder` |
| `NotApplicable` |

## Example

```ts
import { CaseStage2Enum } from 'tradeglot-local-consolelib';

const caseStage2 = CaseStage2Enum.Any;
```

