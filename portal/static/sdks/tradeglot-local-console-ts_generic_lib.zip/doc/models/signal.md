
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | [`SignalCategory \| undefined`](../../doc/models/containers/signal-category.md) | Optional | This is a container for any-of cases. |
| `confidence` | [`SignalConfidence \| undefined`](../../doc/models/containers/signal-confidence.md) | Optional | This is a container for any-of cases. |
| `source` | [`Source2Enum \| undefined`](../../doc/models/source-2-enum.md) | Optional | Source. |

## Example

```ts
import {
  ConfidenceEnum,
  Signal,
  Source2Enum,
} from 'tradeglot-local-consolelib';

const signal: Signal = {
  category: 'String1',
  confidence: ConfidenceEnum.HIGH,
  source: Source2Enum.Channel3,
};
```

