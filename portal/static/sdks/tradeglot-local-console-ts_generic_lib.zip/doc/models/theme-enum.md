
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```ts
import { ThemeEnum } from 'tradeglot-local-consolelib';

const theme = ThemeEnum.SourceCompliance;
```

