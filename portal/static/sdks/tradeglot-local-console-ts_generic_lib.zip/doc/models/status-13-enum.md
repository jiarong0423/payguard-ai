
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `ReferencesFound` |
| `EvidenceMissing` |

## Example

```ts
import { Status13Enum } from 'tradeglot-local-consolelib';

const status13 = Status13Enum.ReferencesFound;
```

