
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | [`CategorySignalCategory`](../../doc/models/containers/category-signal-category.md) | Required | This is a container for any-of cases. |
| `confidence` | [`CategorySignalConfidence`](../../doc/models/containers/category-signal-confidence.md) | Required | This is a container for any-of cases. |
| `source` | `string` | Required, Constant | Source.<br><br>**Value**: `'channel3'` |

## Example

```ts
import { CategorySignal, ConfidenceEnum } from 'tradeglot-local-consolelib';

const categorySignal: CategorySignal = {
  category: 'String1',
  confidence: ConfidenceEnum.HIGH,
  source: 'channel3',
};
```

