
# M Environment Enum

Environment.

## Enumeration

`MEnvironmentEnum`

## Fields

| Name |
|  --- |
| `Sandbox` |

## Example

```ts
import { EnvironmentEnum } from 'tradeglot-local-consolelib';

const environment = EnvironmentEnum.Sandbox;
```

