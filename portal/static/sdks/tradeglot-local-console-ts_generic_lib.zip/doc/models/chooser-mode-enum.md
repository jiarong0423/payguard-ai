
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `Keyword` |
| `Gemini` |

## Example

```ts
import { ChooserModeEnum } from 'tradeglot-local-consolelib';

const chooserMode = ChooserModeEnum.Keyword;
```

