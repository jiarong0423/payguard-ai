
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADDTRACKINGPREVIEW` |
| `ADDTRACKINGSUBMITTED` |

## Example

```ts
import { ReadbackEnum } from 'tradeglot-local-consolelib';

const readback = ReadbackEnum.ADDTRACKINGPREVIEW;
```

