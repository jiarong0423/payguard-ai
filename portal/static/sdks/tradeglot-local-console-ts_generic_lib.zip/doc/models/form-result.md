
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `string \| undefined` | Optional | Item. |
| `valid` | `boolean \| undefined` | Optional | Valid. |

## Example

```ts
import { FormResult } from 'tradeglot-local-consolelib';

const formResult: FormResult = {
  item: 'item8',
  valid: false,
};
```

