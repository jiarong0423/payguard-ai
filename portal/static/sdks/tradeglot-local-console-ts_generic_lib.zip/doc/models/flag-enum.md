
# Flag Enum

## Enumeration

`FlagEnum`

## Fields

| Name |
|  --- |
| `ORDERRECORDABSENT` |
| `DELIVERYNOTRECORDED` |
| `DELIVERYAFTERCLAIM` |
| `CLAIMTIMEEARLIERTHANPAYMENTTIME` |

## Example

```ts
import { FlagEnum } from 'tradeglot-local-consolelib';

const flag = FlagEnum.ORDERRECORDABSENT;
```

