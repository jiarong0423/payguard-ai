
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [`AnalysisReason \| undefined`](../../doc/models/containers/analysis-reason.md) | Optional | This is a container for any-of cases. |
| `status` | [`Status8Enum \| undefined`](../../doc/models/status-8-enum.md) | Optional | Status. |
| `turn` | `number \| undefined` | Optional | Turn. |

## Example

```ts
import {
  Analysis,
  Reason5Enum,
  Status8Enum,
} from 'tradeglot-local-consolelib';

const analysis: Analysis = {
  reason: Reason5Enum.InvalidReply,
  status: Status8Enum.Replaced,
  turn: 198,
};
```

