
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SessionMemory` |
| `HostedDemo` |

## Example

```ts
import { Source1Enum } from 'tradeglot-local-consolelib';

const source1 = Source1Enum.SessionMemory;
```

