
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `Analysing` |
| `Replaced` |
| `Kept` |

## Example

```ts
import { Status8Enum } from 'tradeglot-local-consolelib';

const status8 = Status8Enum.Replaced;
```

