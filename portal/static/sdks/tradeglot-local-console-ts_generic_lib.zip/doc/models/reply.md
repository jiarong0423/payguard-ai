
# Reply

Reply.

## Structure

`Reply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chooser` | [`ChooserEnum \| undefined`](../../doc/models/chooser-enum.md) | Optional | Chooser. |
| `dropped` | [`GuideDropped[] \| undefined`](../../doc/models/guide-dropped.md) | Optional | Dropped. |
| `fallbackReason` | [`ReplyFallbackReason \| undefined`](../../doc/models/containers/reply-fallback-reason.md) | Optional | This is a container for any-of cases. |
| `stateChanged` | `boolean \| undefined` | Optional | State changed. |
| `template` | [`TemplateEnum \| undefined`](../../doc/models/template-enum.md) | Optional | Template. |
| `text` | `string \| undefined` | Optional | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```ts
import {
  ChooserEnum,
  FallbackReasonEnum,
  Reason6Enum,
  Reply,
  TemplateEnum,
} from 'tradeglot-local-consolelib';

const reply: Reply = {
  chooser: ChooserEnum.Keyword,
  dropped: [
    {
      item: 'item2',
      reason: Reason6Enum.OtherParty,
    },
    {
      item: 'item2',
      reason: Reason6Enum.OtherParty,
    }
  ],
  fallbackReason: FallbackReasonEnum.ProviderError,
  stateChanged: false,
  template: TemplateEnum.SUBTRACTION,
};
```

