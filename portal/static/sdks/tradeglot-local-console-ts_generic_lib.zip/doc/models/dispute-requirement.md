
# Dispute Requirement

DisputeRequirement.

## Structure

`DisputeRequirement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acceptedAttachmentCount` | `number` | Required | Accepted attachment count.<br><br>**Constraints**: `>= 0`, `<= 20` |
| `action` | [`DisputeRequirementAction \| undefined`](../../doc/models/containers/dispute-requirement-action.md) | Optional | This is a container for any-of cases. |
| `evidenceType` | [`DisputeRequirementEvidenceType \| undefined`](../../doc/models/containers/dispute-requirement-evidence-type.md) | Optional | This is a container for any-of cases. |
| `mandatory` | `boolean` | Required | Mandatory. |
| `proofCount` | `number` | Required | Proof count.<br><br>**Constraints**: `>= 0`, `<= 128` |
| `providerEvidenceType` | `string` | Required | Provider evidence type.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `^[A-Z][A-Z0-9_]{0,127}$` |
| `requestId` | `string` | Required | Request id.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$` |
| `requirementState` | [`RequirementStateEnum`](../../doc/models/requirement-state-enum.md) | Required | Requirement state. |
| `source` | `string` | Required | Source.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `128`, *Pattern*: `^[A-Z][A-Z0-9_]{0,127}$` |

## Example

```ts
import {
  DisputeRequirement,
  RequirementStateEnum,
} from 'tradeglot-local-consolelib';

const disputeRequirement: DisputeRequirement = {
  acceptedAttachmentCount: 8,
  mandatory: false,
  proofCount: 128,
  providerEvidenceType: 'provider_evidence_type4',
  requestId: 'request_id6',
  requirementState: RequirementStateEnum.CONTEXTONLY,
  source: 'source2',
  action: 'String1',
  evidenceType: 'String3',
};
```

