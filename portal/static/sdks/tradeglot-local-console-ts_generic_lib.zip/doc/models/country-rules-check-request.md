
# Country Rules Check Request

Seller and buyer countries plus closed choices; no free text reaches the check.

## Structure

`CountryRulesCheckRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountOpened` | [`AccountOpenedEnum \| undefined`](../../doc/models/account-opened-enum.md) | Optional | Account opened.<br><br>**Default**: `AccountOpenedEnum.Unknown` |
| `accountType` | [`AccountTypeEnum \| undefined`](../../doc/models/account-type-enum.md) | Optional | Account type.<br><br>**Default**: `AccountTypeEnum.Business` |
| `amount` | [`CountryRulesCheckRequestAmount \| undefined`](../../doc/models/containers/country-rules-check-request-amount.md) | Optional | This is a container for any-of cases. |
| `buyerCountry` | [`BuyerCountryEnum`](../../doc/models/buyer-country-enum.md) | Required | Buyer country. |
| `checkout` | [`CheckoutEnum \| undefined`](../../doc/models/checkout-enum.md) | Optional | Checkout.<br><br>**Default**: `CheckoutEnum.PaypalAccount` |
| `currency` | [`CountryRulesCheckRequestCurrency \| undefined`](../../doc/models/containers/country-rules-check-request-currency.md) | Optional | This is a container for any-of cases. |
| `goodsTags` | `string[] \| undefined` | Optional | Goods tags.<br><br>**Constraints**: *Maximum Items*: `16` |
| `sellerCountry` | [`SellerCountryEnum`](../../doc/models/seller-country-enum.md) | Required | Seller country. |

## Example

```ts
import {
  AccountOpenedEnum,
  AccountTypeEnum,
  BuyerCountryEnum,
  CheckoutEnum,
  CountryRulesCheckRequest,
  SellerCountryEnum,
} from 'tradeglot-local-consolelib';

const countryRulesCheckRequest: CountryRulesCheckRequest = {
  buyerCountry: BuyerCountryEnum.JP,
  sellerCountry: SellerCountryEnum.US,
  accountOpened: AccountOpenedEnum.Unknown,
  accountType: AccountTypeEnum.Business,
  amount: 'String7',
  checkout: CheckoutEnum.PaypalAccount,
  currency: 'String5',
};
```

