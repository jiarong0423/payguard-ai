
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `Enum1` |

## Example

```ts
import { SchemaVersion1Enum } from 'tradeglot-local-consolelib';

const schemaVersion1 = SchemaVersion1Enum.Enum1;
```

