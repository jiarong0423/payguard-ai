
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```ts
import { CaseRouteRequest } from 'tradeglot-local-consolelib';

const caseRouteRequest: CaseRouteRequest = {
  text: 'text6',
};
```

