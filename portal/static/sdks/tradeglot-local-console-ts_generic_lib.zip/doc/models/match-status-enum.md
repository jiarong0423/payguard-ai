
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NOMATCH` |
| `REVIEWSIGNAL` |

## Example

```ts
import { MatchStatusEnum } from 'tradeglot-local-consolelib';

const matchStatus = MatchStatusEnum.NOMATCH;
```

