
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `Payguardfixedsyntheticbriefv1` |
| `Payguardsessionbriefv1` |

## Example

```ts
import { FixtureIdEnum } from 'tradeglot-local-consolelib';

const fixtureId = FixtureIdEnum.Payguardfixedsyntheticbriefv1;
```

