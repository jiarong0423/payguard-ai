
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |

## Example

```ts
import { EvidenceClass3Enum } from 'tradeglot-local-consolelib';

const evidenceClass3 = EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE;
```

