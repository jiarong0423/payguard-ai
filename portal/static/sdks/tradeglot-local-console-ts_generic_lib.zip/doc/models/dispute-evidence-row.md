
# Dispute Evidence Row

DisputeEvidenceRow.

## Structure

`DisputeEvidenceRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`DisputeEvidenceRowAction \| undefined`](../../doc/models/containers/dispute-evidence-row-action.md) | Optional | This is a container for any-of cases. |
| `date` | [`DisputeEvidenceRowDate \| undefined`](../../doc/models/containers/dispute-evidence-row-date.md) | Optional | This is a container for any-of cases. |
| `evidenceType` | `string` | Required | Evidence type.<br><br>**Constraints**: *Pattern*: `^[A-Z][A-Z0-9_]{0,63}$` |
| `source` | [`Source3Enum`](../../doc/models/source-3-enum.md) | Required | Source. |

## Example

```ts
import { DisputeEvidenceRow, Source3Enum } from 'tradeglot-local-consolelib';

const disputeEvidenceRow: DisputeEvidenceRow = {
  evidenceType: 'evidence_type8',
  source: Source3Enum.REQUESTEDFROMSELLER,
  action: 'String7',
  date: 'String3',
};
```

