
# Webhook Verify Response

WebhookVerifyResponse.

## Structure

`WebhookVerifyResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `event` | [`WebhookEventProjection`](../../doc/models/webhook-event-projection.md) | Required | All that is kept after a SUCCESS: identifiers and status only, no amounts, payer data, links or summary. |
| `importedIntoDemo` | `string` | Required, Constant | Imported into demo.<br><br>**Value**: `'False'` |
| `paypalDebugId` | [`WebhookVerifyResponsePaypalDebugId`](../../doc/models/containers/webhook-verify-response-paypal-debug-id.md) | Required | This is a container for any-of cases. |
| `source` | `string` | Required, Constant | Source.<br><br>**Value**: `'paypal_sandbox'` |
| `verificationStatus` | `string` | Required, Constant | Verification status.<br><br>**Value**: `'SUCCESS'` |

## Example

```ts
import { WebhookVerifyResponse } from 'tradeglot-local-consolelib';

const webhookVerifyResponse: WebhookVerifyResponse = {
  event: {
    eventType: 'String1',
    id: 'String1',
    resourceId: 'String7',
    resourceStatus: 'String9',
    resourceType: 'String5',
  },
  importedIntoDemo: 'False',
  paypalDebugId: 'String9',
  source: 'paypal_sandbox',
  verificationStatus: 'SUCCESS',
};
```

