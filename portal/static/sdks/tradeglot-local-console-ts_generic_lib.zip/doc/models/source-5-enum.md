
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```ts
import { Source5Enum } from 'tradeglot-local-consolelib';

const source5 = Source5Enum.PROVIDER;
```

