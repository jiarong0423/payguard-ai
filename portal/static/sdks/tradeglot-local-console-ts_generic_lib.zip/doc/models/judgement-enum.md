
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOTMADE` |

## Example

```ts
import { JudgementEnum } from 'tradeglot-local-consolelib';

const judgement = JudgementEnum.NOTMADE;
```

