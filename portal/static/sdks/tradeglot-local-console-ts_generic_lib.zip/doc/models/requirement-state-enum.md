
# Requirement State Enum

Requirement state.

## Enumeration

`RequirementStateEnum`

## Fields

| Name |
|  --- |
| `CONTEXTONLY` |
| `UNMAPPEDEVIDENCETYPE` |
| `PROVIDERREQUESTOUTSIDELOCALMATRIX` |
| `STRUCTURALLYPRESENT` |
| `MANDATORYEVIDENCEMISSING` |
| `OPTIONALEVIDENCEMISSING` |

## Example

```ts
import { RequirementStateEnum } from 'tradeglot-local-consolelib';

const requirementState = RequirementStateEnum.MANDATORYEVIDENCEMISSING;
```

