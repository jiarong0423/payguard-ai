
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `Date` |
| `Choice` |
| `Text` |

## Example

```ts
import { Kind2Enum } from 'tradeglot-local-consolelib';

const kind2 = Kind2Enum.Choice;
```

