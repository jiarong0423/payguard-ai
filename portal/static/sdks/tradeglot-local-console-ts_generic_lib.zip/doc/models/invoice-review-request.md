
# Invoice Review Request

InvoiceReviewRequest.

## Structure

`InvoiceReviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `acknowledgementToken` | [`InvoiceReviewRequestAcknowledgementToken \| undefined`](../../doc/models/containers/invoice-review-request-acknowledgement-token.md) | Optional | This is a container for any-of cases. |
| `amount` | `string` | Required | Amount.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,9}(?:\.[0-9]{1,2})?$` |
| `confirmSandboxDraft` | `boolean` | Required | Confirm sandbox draft. |
| `currency` | [`CurrencyEnum`](../../doc/models/currency-enum.md) | Required | Currency. |
| `description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |
| `descriptionDigest` | [`InvoiceReviewRequestDescriptionDigest \| undefined`](../../doc/models/containers/invoice-review-request-description-digest.md) | Optional | This is a container for any-of cases. |
| `evaluationId` | [`InvoiceReviewRequestEvaluationId \| undefined`](../../doc/models/containers/invoice-review-request-evaluation-id.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import {
  CurrencyEnum,
  InvoiceReviewRequest,
} from 'tradeglot-local-consolelib';

const invoiceReviewRequest: InvoiceReviewRequest = {
  amount: 'amount8',
  confirmSandboxDraft: false,
  currency: CurrencyEnum.USD,
  description: 'description6',
  acknowledgementToken: 'String7',
  descriptionDigest: 'String5',
  evaluationId: 'String1',
};
```

