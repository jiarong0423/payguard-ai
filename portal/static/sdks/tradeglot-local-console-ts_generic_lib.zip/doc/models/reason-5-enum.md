
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `Budget` |
| `ProviderError` |
| `InvalidReply` |
| `Late` |
| `NoItems` |
| `Superseded` |

## Example

```ts
import { Reason5Enum } from 'tradeglot-local-consolelib';

const reason5 = Reason5Enum.InvalidReply;
```

