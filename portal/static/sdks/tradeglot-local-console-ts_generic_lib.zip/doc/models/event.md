
# Event

## Structure

`Event`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `string \| undefined` | Optional | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `channel` | [`ChannelEnum \| undefined`](../../doc/models/channel-enum.md) | Optional | Channel. |
| `direction` | [`DirectionEnum \| undefined`](../../doc/models/direction-enum.md) | Optional | Direction. |
| `kind` | [`Kind1Enum \| undefined`](../../doc/models/kind-1-enum.md) | Optional | Kind. |
| `messageDigest` | `string \| undefined` | Optional | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `source` | [`Source6Enum \| undefined`](../../doc/models/source-6-enum.md) | Optional | Source. |
| `topic` | [`TopicEnum \| undefined`](../../doc/models/topic-enum.md) | Optional | Topic. |

## Example

```ts
import {
  ChannelEnum,
  DirectionEnum,
  Event,
  Kind1Enum,
} from 'tradeglot-local-consolelib';

const event: Event = {
  at: 'at6',
  channel: ChannelEnum.EMAIL,
  direction: DirectionEnum.INBOUND,
  kind: Kind1Enum.MESSAGE,
  messageDigest: 'message_digest6',
};
```

