
# Claim Type Enum

Claim type.

## Enumeration

`ClaimTypeEnum`

## Fields

| Name |
|  --- |
| `PolicyReference` |
| `CurrentPolicy` |
| `ProceduralReference` |
| `ApiReference` |
| `FinancialAction` |
| `Assurance` |

## Example

```ts
import { ClaimTypeEnum } from 'tradeglot-local-consolelib';

const claimType = ClaimTypeEnum.PolicyReference;
```

