
# Reference Request

ReferenceRequest.

## Structure

`ReferenceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asOf` | [`ReferenceRequestAsOf \| undefined`](../../doc/models/containers/reference-request-as-of.md) | Optional | This is a container for any-of cases. |
| `caseStage` | [`CaseStage2Enum \| undefined`](../../doc/models/case-stage-2-enum.md) | Optional | Case stage.<br><br>**Default**: `CaseStage2Enum.Any` |
| `jurisdiction` | `string` | Required, Constant | Jurisdiction.<br><br>**Value**: `'US'` |
| `limit` | `number \| undefined` | Optional | Limit.<br><br>**Default**: `3`<br><br>**Constraints**: `>= 1`, `<= 10` |
| `materialTypes` | [`ReferenceRequestMaterialTypes \| undefined`](../../doc/models/containers/reference-request-material-types.md) | Optional | This is a container for any-of cases. |
| `maxSourceAgeDays` | [`ReferenceRequestMaxSourceAgeDays \| undefined`](../../doc/models/containers/reference-request-max-source-age-days.md) | Optional | This is a container for any-of cases. |
| `query` | `string` | Required | Query.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `512` |
| `requireKnownSourceDate` | `boolean \| undefined` | Optional | Require known source date.<br><br>**Default**: `false` |
| `theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```ts
import {
  CaseStage2Enum,
  MaterialType4Enum,
  ReferenceRequest,
  ThemeEnum,
} from 'tradeglot-local-consolelib';

const referenceRequest: ReferenceRequest = {
  jurisdiction: 'US',
  query: 'query4',
  theme: ThemeEnum.DisputeMediation,
  asOf: 'String7',
  caseStage: CaseStage2Enum.Any,
  limit: 3,
  materialTypes: [
    MaterialType4Enum.PublicCourtOrderCopy
  ],
  maxSourceAgeDays: 110,
  requireKnownSourceDate: false,
};
```

