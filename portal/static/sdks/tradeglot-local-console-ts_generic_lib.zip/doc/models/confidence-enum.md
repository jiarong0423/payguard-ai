
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```ts
import { ConfidenceEnum } from 'tradeglot-local-consolelib';

const confidence = ConfidenceEnum.HIGH;
```

