
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `Exact` |
| `Close` |

## Example

```ts
import { MatchTypeEnum } from 'tradeglot-local-consolelib';

const matchType = MatchTypeEnum.Exact;
```

