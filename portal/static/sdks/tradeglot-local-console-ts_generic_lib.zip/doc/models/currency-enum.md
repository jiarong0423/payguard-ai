
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```ts
import { CurrencyEnum } from 'tradeglot-local-consolelib';

const currency = CurrencyEnum.USD;
```

