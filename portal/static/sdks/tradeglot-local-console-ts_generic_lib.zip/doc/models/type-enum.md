
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Email` |
| `UsPhone` |
| `IdLike` |
| `Name` |
| `Address` |
| `Manual` |
| `Mixed` |

## Example

```ts
import { TypeEnum } from 'tradeglot-local-consolelib';

const type = TypeEnum.Manual;
```

