
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `Budget` |
| `ProviderError` |
| `InvalidReply` |
| `Late` |
| `NoItems` |

## Example

```ts
import { FallbackReasonEnum } from 'tradeglot-local-consolelib';

const fallbackReason = FallbackReasonEnum.NoItems;
```

