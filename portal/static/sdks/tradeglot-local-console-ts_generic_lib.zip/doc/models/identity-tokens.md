
# Identity Tokens

IdentityTokens.

## Structure

`IdentityTokens`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `addressToken` | `string` | Required | Address token. |
| `emailToken` | `string` | Required | Email token. |
| `nameToken` | `string` | Required | Name token. |

## Example

```ts
import { IdentityTokens } from 'tradeglot-local-consolelib';

const identityTokens: IdentityTokens = {
  addressToken: 'address_token6',
  emailToken: 'email_token8',
  nameToken: 'name_token4',
};
```

