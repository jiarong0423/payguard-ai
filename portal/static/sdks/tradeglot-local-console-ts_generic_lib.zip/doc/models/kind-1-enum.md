
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```ts
import { Kind1Enum } from 'tradeglot-local-consolelib';

const kind1 = Kind1Enum.MESSAGE;
```

