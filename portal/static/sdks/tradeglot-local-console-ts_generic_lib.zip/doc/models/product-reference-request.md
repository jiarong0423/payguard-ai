
# Product Reference Request

ProductReferenceRequest.

## Structure

`ProductReferenceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |
| `evaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |

## Example

```ts
import { ProductReferenceRequest } from 'tradeglot-local-consolelib';

const productReferenceRequest: ProductReferenceRequest = {
  description: 'description8',
  evaluationId: 'evaluation_id2',
};
```

