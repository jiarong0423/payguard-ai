
# Reason Code Enum

## Enumeration

`ReasonCodeEnum`

## Fields

| Name |
|  --- |
| `ACTIONCLAIMFORBIDDEN` |
| `ASSURANCECLAIMFORBIDDEN` |
| `CITATIONUNKNOWN` |
| `CITATIONREGIONMISMATCH` |
| `CITATIONTHEMEMISMATCH` |
| `CLAIMREFERENCETYPEMISMATCH` |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `DOCUMENTUPDATEINFUTURE` |
| `CURRENTPOLICYNOTESTABLISHED` |

## Example

```ts
import { ReasonCodeEnum } from 'tradeglot-local-consolelib';

const reasonCode = ReasonCodeEnum.FUTUREOBSERVATION;
```

