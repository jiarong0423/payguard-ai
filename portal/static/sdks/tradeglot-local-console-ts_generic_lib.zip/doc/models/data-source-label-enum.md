
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `Sandbox` |
| `Fixture` |

## Example

```ts
import { DataSourceLabelEnum } from 'tradeglot-local-consolelib';

const dataSourceLabel = DataSourceLabelEnum.Sandbox;
```

