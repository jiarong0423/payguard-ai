
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `Channel3` |

## Example

```ts
import { Source2Enum } from 'tradeglot-local-consolelib';

const source2 = Source2Enum.Channel3;
```

