
# HTTP Validation Error

HTTPValidationError.

## Structure

`HTTPValidationError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `detail` | [`ValidationError[] \| undefined`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```ts
import { HTTPValidationError } from 'tradeglot-local-consolelib';

const hTTPValidationError: HTTPValidationError = {
  detail: [
    {
      loc: [
        'String7',
        'String8',
        'String9'
      ],
      msg: 'msg2',
      type: 'type4',
      ctx: { 'key1': 'val1', 'key2': 'val2' },
      input: { 'key1': 'val1', 'key2': 'val2' },
    },
    {
      loc: [
        'String7',
        'String8',
        'String9'
      ],
      msg: 'msg2',
      type: 'type4',
      ctx: { 'key1': 'val1', 'key2': 'val2' },
      input: { 'key1': 'val1', 'key2': 'val2' },
    }
  ],
};
```

