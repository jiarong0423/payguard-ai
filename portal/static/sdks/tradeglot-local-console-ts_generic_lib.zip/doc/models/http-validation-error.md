
# HTTP Validation Error

HTTPValidationError.

## Structure

`HTTPValidationError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `detail` | [`ValidationError[] \| undefined`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```ts
try {
  // make the API call
} catch (error) {
  if (error instanceof HTTPValidationError) {
    console.log(error.result);
  }
}
```

