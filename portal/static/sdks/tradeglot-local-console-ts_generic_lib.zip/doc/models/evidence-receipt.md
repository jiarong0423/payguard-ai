
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`ActionEnum \| undefined`](../../doc/models/action-enum.md) | Optional | Action. |
| `environment` | [`EnvironmentEnum \| undefined`](../../doc/models/m-environment-enum.md) | Optional | Environment. |
| `evidenceClass` | [`EvidenceClass3Enum \| undefined`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. |
| `externalSend` | [`ExternalSend1Enum \| undefined`](../../doc/models/external-send-1-enum.md) | Optional | External send. |
| `invoiceId` | [`EvidenceReceiptInvoiceId \| undefined`](../../doc/models/containers/evidence-receipt-invoice-id.md) | Optional | This is a container for any-of cases. |
| `observedAt` | `string \| undefined` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `paypalDebugId` | [`EvidenceReceiptPaypalDebugId \| undefined`](../../doc/models/containers/evidence-receipt-paypal-debug-id.md) | Optional | This is a container for any-of cases. |
| `proofKind` | [`ProofKindEnum \| undefined`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. |
| `schemaVersion` | [`SchemaVersion1Enum \| undefined`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. |
| `separateGetReadback` | `boolean \| undefined` | Optional | Separate get readback. |
| `status` | [`Status10Enum \| undefined`](../../doc/models/status-10-enum.md) | Optional | Status. |

## Example

```ts
import {
  ActionEnum,
  EnvironmentEnum,
  EvidenceClass3Enum,
  EvidenceReceipt,
  ExternalSend1Enum,
} from 'tradeglot-local-consolelib';

const evidenceReceipt: EvidenceReceipt = {
  action: ActionEnum.OAUTHCONNECT,
  environment: EnvironmentEnum.Sandbox,
  evidenceClass: EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE,
  externalSend: ExternalSend1Enum.FROZEN,
  invoiceId: 'String1',
};
```

