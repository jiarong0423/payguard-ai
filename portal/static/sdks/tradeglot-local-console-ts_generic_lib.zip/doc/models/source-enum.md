
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PaypalSandbox` |
| `SyntheticFixture` |

## Example

```ts
import { SourceEnum } from 'tradeglot-local-consolelib';

const source = SourceEnum.PaypalSandbox;
```

