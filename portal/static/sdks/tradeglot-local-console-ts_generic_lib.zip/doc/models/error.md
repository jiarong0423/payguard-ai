
# Error

What was refused and why.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `string` | Required | Stable machine-readable reason, for example session_required. |
| `message` | `string` | Required | A plain sentence for a person. |

## Example

```ts
import { Error } from 'tradeglot-local-consolelib';

const error: Error = {
  code: 'code2',
  message: 'message4',
};
```

