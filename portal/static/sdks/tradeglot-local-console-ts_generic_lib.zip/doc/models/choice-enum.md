
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURNTOEDIT` |
| `CANCEL` |
| `ACKNOWLEDGEANDCONTINUE` |

## Example

```ts
import { ChoiceEnum } from 'tradeglot-local-consolelib';

const choice = ChoiceEnum.RETURNTOEDIT;
```

