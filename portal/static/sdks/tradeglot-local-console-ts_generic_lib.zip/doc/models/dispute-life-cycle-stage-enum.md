
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PREARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```ts
import { DisputeLifeCycleStageEnum } from 'tradeglot-local-consolelib';

const disputeLifeCycleStage = DisputeLifeCycleStageEnum.INQUIRY;
```

