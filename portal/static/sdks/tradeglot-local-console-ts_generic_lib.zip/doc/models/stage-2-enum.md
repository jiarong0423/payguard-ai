
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |
| `Guide` |
| `StudioAgent` |

## Example

```ts
import { Stage2Enum } from 'tradeglot-local-consolelib';

const stage2 = Stage2Enum.StudioAgent;
```

