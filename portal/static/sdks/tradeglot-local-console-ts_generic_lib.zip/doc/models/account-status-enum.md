
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```ts
import { AccountStatusEnum } from 'tradeglot-local-consolelib';

const accountStatus = AccountStatusEnum.UNKNOWN;
```

