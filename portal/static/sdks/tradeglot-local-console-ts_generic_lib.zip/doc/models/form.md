
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum \| undefined`](../../doc/models/kind-2-enum.md) | Optional | Kind. |
| `options` | [`GuideOption[] \| undefined`](../../doc/models/guide-option.md) | Optional | Options. |
| `placeholder` | [`FormPlaceholder \| undefined`](../../doc/models/containers/form-placeholder.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import { Form, Kind2Enum } from 'tradeglot-local-consolelib';

const form: Form = {
  kind: Kind2Enum.Text,
  options: [
    {
      label: 'label2',
      value: 'value4',
    },
    {
      label: 'label2',
      value: 'value4',
    },
    {
      label: 'label2',
      value: 'value4',
    }
  ],
  placeholder: 'String9',
};
```

