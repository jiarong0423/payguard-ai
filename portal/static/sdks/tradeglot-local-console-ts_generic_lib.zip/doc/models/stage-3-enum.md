
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `Funnel` |
| `Echo` |
| `Fill` |
| `Review` |
| `Done` |

## Example

```ts
import { Stage3Enum } from 'tradeglot-local-consolelib';

const stage3 = Stage3Enum.Done;
```

