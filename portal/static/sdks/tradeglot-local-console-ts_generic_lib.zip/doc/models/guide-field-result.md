
# Guide Field Result

GuideFieldResult.

## Structure

`GuideFieldResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deferred` | `boolean` | Required | Deferred. |
| `item` | `string` | Required | Item. |
| `valid` | `boolean` | Required | Valid. |

## Example

```ts
import { GuideFieldResult } from 'tradeglot-local-consolelib';

const guideFieldResult: GuideFieldResult = {
  deferred: false,
  item: 'item8',
  valid: false,
};
```

