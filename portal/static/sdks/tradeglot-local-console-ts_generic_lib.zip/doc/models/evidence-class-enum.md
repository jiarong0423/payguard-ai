
# Evidence Class Enum

Evidence class.

## Enumeration

`EvidenceClassEnum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |
| `SYNTHETICFIXTURE` |

## Example

```ts
import { EvidenceClassEnum } from 'tradeglot-local-consolelib';

const evidenceClass = EvidenceClassEnum.SYNTHETICFIXTURE;
```

