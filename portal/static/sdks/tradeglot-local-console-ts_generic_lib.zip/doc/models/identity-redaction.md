
# Identity Redaction

IdentityRedaction.

## Structure

`IdentityRedaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | [`FieldEnum[]`](../../doc/models/field-enum.md) | Required | Fields. |
| `method` | `string` | Required, Constant | Method.<br><br>**Value**: `'HMAC-SHA256 pseudonymization'` |
| `synthetic` | `string` | Required, Constant | Synthetic.<br><br>**Value**: `'True'` |
| `tokens` | [`IdentityTokens`](../../doc/models/identity-tokens.md) | Required | IdentityTokens. |

## Example

```ts
import { FieldEnum, IdentityRedaction } from 'tradeglot-local-consolelib';

const identityRedaction: IdentityRedaction = {
  fields: [
    FieldEnum.Name,
    FieldEnum.Address
  ],
  method: 'HMAC-SHA256 pseudonymization',
  synthetic: 'True',
  tokens: {
    addressToken: 'address_token0',
    emailToken: 'email_token2',
    nameToken: 'name_token0',
  },
};
```

