
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `Local` |
| `HostedDemo` |

## Example

```ts
import { ModeEnum } from 'tradeglot-local-consolelib';

const mode = ModeEnum.Local;
```

