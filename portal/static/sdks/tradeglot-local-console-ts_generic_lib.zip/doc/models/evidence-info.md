
# Evidence Info

EvidenceInfo.

## Structure

`EvidenceInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trackingInfo` | [`TrackingInfo[]`](../../doc/models/tracking-info.md) | Required | Tracking info.<br><br>**Constraints**: *Maximum Items*: `10` |

## Example

```ts
import { CarrierNameEnum, EvidenceInfo } from 'tradeglot-local-consolelib';

const evidenceInfo: EvidenceInfo = {
  trackingInfo: [
    {
      carrierName: CarrierNameEnum.DHL,
      trackingNumber: 'tracking_number6',
      carrierNameOther: 'String1',
    }
  ],
};
```

