
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `Physical` |
| `Digital` |

## Example

```ts
import { GoodsTypeEnum } from 'tradeglot-local-consolelib';

const goodsType = GoodsTypeEnum.Physical;
```

