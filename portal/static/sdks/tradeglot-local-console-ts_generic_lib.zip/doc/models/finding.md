
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | [`CategoryEnum`](../../doc/models/category-enum.md) | Required | Category. |
| `code` | `string` | Required, Constant | Code.<br><br>**Value**: `'keyword_requires_policy_review'` |

## Example

```ts
import { CategoryEnum, Finding } from 'tradeglot-local-consolelib';

const finding: Finding = {
  category: CategoryEnum.UnsupportedFinancialPromise,
  code: 'keyword_requires_policy_review',
};
```

