
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONEMATCH` |

## Example

```ts
import { Choice2Enum } from 'tradeglot-local-consolelib';

const choice2 = Choice2Enum.CONFIRMED;
```

