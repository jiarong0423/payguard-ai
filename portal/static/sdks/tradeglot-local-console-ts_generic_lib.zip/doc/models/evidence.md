
# Evidence

Evidence.

## Structure

`Evidence`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `carrierStatus` | [`EvidenceCarrierStatus \| undefined`](../../doc/models/containers/evidence-carrier-status.md) | Optional | This is a container for any-of cases. |
| `deliveredAt` | [`EvidenceDeliveredAt \| undefined`](../../doc/models/containers/evidence-delivered-at.md) | Optional | This is a container for any-of cases. |
| `evidenceSource` | `string` | Required, Constant | Evidence source.<br><br>**Value**: `'synthetic'` |
| `openedAt` | [`EvidenceOpenedAt \| undefined`](../../doc/models/containers/evidence-opened-at.md) | Optional | This is a container for any-of cases. |
| `orderCreatedAt` | [`EvidenceOrderCreatedAt \| undefined`](../../doc/models/containers/evidence-order-created-at.md) | Optional | This is a container for any-of cases. |
| `reason` | [`EvidenceReason \| undefined`](../../doc/models/containers/evidence-reason.md) | Optional | This is a container for any-of cases. |

## Example

```ts
import { Evidence } from 'tradeglot-local-consolelib';

const evidence: Evidence = {
  evidenceSource: 'synthetic',
  carrierStatus: 'String5',
  deliveredAt: 'String1',
  openedAt: 'String1',
  orderCreatedAt: 'String3',
  reason: 'String3',
};
```

