
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICBASELINE` |
| `CALLERSUPPLIEDUNVERIFIED` |

## Example

```ts
import { BaselineProvenanceEnum } from 'tradeglot-local-consolelib';

const baselineProvenance = BaselineProvenanceEnum.SYNTHETICBASELINE;
```

