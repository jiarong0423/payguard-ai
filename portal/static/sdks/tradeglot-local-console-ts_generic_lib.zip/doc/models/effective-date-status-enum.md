
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTVERIFIED` |

## Example

```ts
import { EffectiveDateStatusEnum } from 'tradeglot-local-consolelib';

const effectiveDateStatus = EffectiveDateStatusEnum.DOCUMENTSTATED;
```

