
# Advisory Claim Gate

AdvisoryClaimGate.

## Structure

`AdvisoryClaimGate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `claimIndex` | `number` | Required | Claim index.<br><br>**Constraints**: `>= 0`, `<= 19` |
| `claimType` | [`ClaimTypeEnum`](../../doc/models/claim-type-enum.md) | Required | Claim type. |
| `reasonCodes` | [`ReasonCodeEnum[]`](../../doc/models/reason-code-enum.md) | Required | Reason codes.<br><br>**Constraints**: *Maximum Items*: `10` |
| `status` | [`StatusEnum`](../../doc/models/status-enum.md) | Required | Status. |
| `trustedCitationChunkIds` | `string[]` | Required | Trusted citation chunk ids.<br><br>**Constraints**: *Maximum Items*: `10`, *Pattern*: `^[A-Z0-9-]{1,128}$` |

## Example

```ts
import {
  AdvisoryClaimGate,
  ClaimTypeEnum,
  ReasonCodeEnum,
  StatusEnum,
} from 'tradeglot-local-consolelib';

const advisoryClaimGate: AdvisoryClaimGate = {
  claimIndex: 19,
  claimType: ClaimTypeEnum.FinancialAction,
  reasonCodes: [
    ReasonCodeEnum.CLAIMREFERENCETYPEMISMATCH,
    ReasonCodeEnum.CITATIONTHEMEMISMATCH,
    ReasonCodeEnum.CITATIONREGIONMISMATCH
  ],
  status: StatusEnum.STRUCTURECOMPATIBLE,
  trustedCitationChunkIds: [
    'trusted_citation_chunk_ids6',
    'trusted_citation_chunk_ids7',
    'trusted_citation_chunk_ids8'
  ],
};
```

