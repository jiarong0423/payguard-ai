
# Buyer Country Enum

Buyer country.

## Enumeration

`BuyerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```ts
import { BuyerCountryEnum } from 'tradeglot-local-consolelib';

const buyerCountry = BuyerCountryEnum.US;
```

