
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |
| `PublicCourtOrderCopy` |

## Example

```ts
import { MaterialType4Enum } from 'tradeglot-local-consolelib';

const materialType4 = MaterialType4Enum.OfficialApiReference;
```

