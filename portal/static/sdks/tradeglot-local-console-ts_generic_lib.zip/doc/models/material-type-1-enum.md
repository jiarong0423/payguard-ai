
# Material Type 1 Enum

Material type.

## Enumeration

`MaterialType1Enum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |
| `PublicCourtOrderCopy` |

## Example

```ts
import { MaterialType1Enum } from 'tradeglot-local-consolelib';

const materialType1 = MaterialType1Enum.OfficialPolicy;
```

