
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `MISSING` |

## Example

```ts
import { SourceUpdatedDateStatusEnum } from 'tradeglot-local-consolelib';

const sourceUpdatedDateStatus = SourceUpdatedDateStatusEnum.DOCUMENTSTATED;
```

