
# Guide Review Row

GuideReviewRow.

## Structure

`GuideReviewRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `string` | Required | Item. |
| `source` | [`Source9Enum`](../../doc/models/source-9-enum.md) | Required | Source. |
| `value` | `string` | Required | Value.<br><br>**Constraints**: *Maximum Length*: `120` |

## Example

```ts
import { GuideReviewRow, Source9Enum } from 'tradeglot-local-consolelib';

const guideReviewRow: GuideReviewRow = {
  item: 'item6',
  source: Source9Enum.Words,
  value: 'value6',
};
```

