# Guide

Evidence guide: gap filling over closed form items.

```ts
const guideController = new GuideController(client);
```

## Class Name

`GuideController`

## Methods

* [Post Guide Form](../../doc/controllers/guide.md#post-guide-form)
* [Post Guide Review](../../doc/controllers/guide.md#post-guide-review)
* [Post Guide Start](../../doc/controllers/guide.md#post-guide-start)
* [Get Guide State](../../doc/controllers/guide.md#get-guide-state)
* [Post Guide Turn](../../doc/controllers/guide.md#post-guide-turn)


# Post Guide Form

Guide Form. Local console route POST /api/v1/guide/form on synthetic data; advisory only.

```ts
async postGuideForm(
  body: GuideFormRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<GuideStateResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideFormRequest`](../../doc/models/guide-form-request.md) | Body, Required | JSON body for: Guide Form. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`GuideStateResponse`](../../doc/models/guide-state-response.md).

## Example Usage

```ts
const body: GuideFormRequest = {
};

try {
  const response = await guideController.postGuideForm(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Guide Review

Guide Review. Local console route POST /api/v1/guide/review on synthetic data; advisory only.

```ts
async postGuideReview(
  body: GuideReviewRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<GuideStateResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideReviewRequest`](../../doc/models/guide-review-request.md) | Body, Required | JSON body for: Guide Review. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`GuideStateResponse`](../../doc/models/guide-state-response.md).

## Example Usage

```ts
const body: GuideReviewRequest = {
};

try {
  const response = await guideController.postGuideReview(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Guide Start

Guide Start. Local console route POST /api/v1/guide/start on synthetic data; advisory only.

```ts
async postGuideStart(
  body: GuideStartRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<GuideStateResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideStartRequest`](../../doc/models/guide-start-request.md) | Body, Required | JSON body for: Guide Start. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`GuideStateResponse`](../../doc/models/guide-state-response.md).

## Example Usage

```ts
const body: GuideStartRequest = {
  scenario: Scenario2Enum.Preflight,
};

try {
  const response = await guideController.postGuideStart(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Get Guide State

Guide State. Local console route GET /api/v1/guide/state on synthetic data; advisory only.

```ts
async getGuideState(
  scenario?: GetGuideStateScenario,
  requestOptions?: RequestOptions
): Promise<ApiResponse<GuideStateResponse>>
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`GetGuideStateScenario \| undefined`](../../doc/models/containers/get-guide-state-scenario.md) | Query, Optional | This is a container for any-of cases. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`GuideStateResponse`](../../doc/models/guide-state-response.md).

## Example Usage

```ts
const scenario: GetGuideStateScenario = Scenario1Enum.Preflight;

try {
  const response = await guideController.getGuideState(scenario);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Guide Turn

Guide Turn. Local console route POST /api/v1/guide/turn on synthetic data; advisory only.

```ts
async postGuideTurn(
  body: GuideTurnRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<GuideStateResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideTurnRequest`](../../doc/models/guide-turn-request.md) | Body, Required | JSON body for: Guide Turn. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`GuideStateResponse`](../../doc/models/guide-state-response.md).

## Example Usage

```ts
const body: GuideTurnRequest = {
  text: 'example',
};

try {
  const response = await guideController.postGuideTurn(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |

