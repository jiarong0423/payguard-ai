# Other

Other console routes.

```ts
const otherController = new OtherController(client);
```

## Class Name

`OtherController`

## Methods

* [Post Advisory Evaluate](../../doc/controllers/other.md#post-advisory-evaluate)
* [Post Cases Route](../../doc/controllers/other.md#post-cases-route)
* [Get Connections](../../doc/controllers/other.md#get-connections)
* [Post Country Rules Check](../../doc/controllers/other.md#post-country-rules-check)
* [Get Country Rules Countries](../../doc/controllers/other.md#get-country-rules-countries)
* [Post Country Rules Search](../../doc/controllers/other.md#post-country-rules-search)
* [Post Disputes Case Ref Approve](../../doc/controllers/other.md#post-disputes-case-ref-approve)
* [Post Disputes Case Ref Draft](../../doc/controllers/other.md#post-disputes-case-ref-draft)
* [Post Policy Assess](../../doc/controllers/other.md#post-policy-assess)


# Post Advisory Evaluate

Advisory Evaluate. Local console route POST /api/v1/advisory/evaluate on synthetic data; advisory only.

```ts
async postAdvisoryEvaluate(
  body: AdvisoryRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AdvisoryEvaluationResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AdvisoryRequest`](../../doc/models/advisory-request.md) | Body, Required | JSON body for: Advisory Evaluate. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`AdvisoryEvaluationResponse`](../../doc/models/advisory-evaluation-response.md).

## Example Usage

```ts
const body: AdvisoryRequest = {
  asOf: 'examplexxxxxxxxxxxxx',
  candidateJson: 'example',
  jurisdiction: 'US',
  observationMaxAgeDays: 0,
  theme: ThemeEnum.SourceCompliance,
};

try {
  const response = await otherController.postAdvisoryEvaluate(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Cases Route

Case Route. Local console route POST /api/v1/cases/route on synthetic data; advisory only.

```ts
async postCasesRoute(
  body: CaseRouteRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<CaseRouteResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CaseRouteRequest`](../../doc/models/case-route-request.md) | Body, Required | JSON body for: Case Route. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`CaseRouteResponse`](../../doc/models/case-route-response.md).

## Example Usage

```ts
const body: CaseRouteRequest = {
  text: 'handmade ceramic coffee mug',
};

try {
  const response = await otherController.postCasesRoute(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Get Connections

Connections. Local console route GET /api/v1/connections on synthetic data; advisory only.

```ts
async getConnections(
  requestOptions?: RequestOptions
): Promise<ApiResponse<ConnectionsResponse>>
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ConnectionsResponse`](../../doc/models/connections-response.md).

## Example Usage

```ts
try {
  const response = await otherController.getConnections();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "mode": "hosted_demo",
  "sandbox_reads": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Country Rules Check

Country Rules Check. Local console route POST /api/v1/country-rules/check on synthetic data; advisory only.

```ts
async postCountryRulesCheck(
  body: CountryRulesCheckRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown | undefined>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesCheckRequest`](../../doc/models/country-rules-check-request.md) | Body, Required | JSON body for: Country Rules Check. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type `unknown`.

## Example Usage

```ts
const body: CountryRulesCheckRequest = {
  buyerCountry: BuyerCountryEnum.US,
  sellerCountry: SellerCountryEnum.TW,
  accountType: AccountTypeEnum.Business,
  amount: '120.00',
  checkout: CheckoutEnum.PaypalAccount,
  currency: 'USD',
  goodsTags: [],
};

try {
  const response = await otherController.postCountryRulesCheck(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Get Country Rules Countries

Country Rules Countries. Local console route GET /api/v1/country-rules/countries on synthetic data; advisory only.

```ts
async getCountryRulesCountries(
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown | undefined>>
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type `unknown`.

## Example Usage

```ts
try {
  const response = await otherController.getCountryRulesCountries();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Country Rules Search

Country Rules Search. Local console route POST /api/v1/country-rules/search on synthetic data; advisory only.

```ts
async postCountryRulesSearch(
  body: CountryRulesSearchRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<unknown | undefined>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesSearchRequest`](../../doc/models/country-rules-search-request.md) | Body, Required | JSON body for: Country Rules Search. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type `unknown`.

## Example Usage

```ts
const body: CountryRulesSearchRequest = {
  query: 'example',
};

try {
  const response = await otherController.postCountryRulesSearch(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Disputes Case Ref Approve

Approve. Local console route POST /api/v1/disputes/{case_ref}/approve on synthetic data; advisory only.

```ts
async postDisputesCaseRefApprove(
  caseRef: string,
  body: ApproveRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<DisputeApprovalResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `caseRef` | `string` | Template, Required | Case ref. |
| `body` | [`ApproveRequest`](../../doc/models/approve-request.md) | Body, Required | JSON body for: Approve. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`DisputeApprovalResponse`](../../doc/models/dispute-approval-response.md).

## Example Usage

```ts
const caseRef = 'case-ref-001';

const body: ApproveRequest = {
  draftDigest: 'draft_digest6',
};

try {
  const response = await otherController.postDisputesCaseRefApprove(
    caseRef,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Disputes Case Ref Draft

Draft. Local console route POST /api/v1/disputes/{case_ref}/draft on synthetic data; advisory only.

```ts
async postDisputesCaseRefDraft(
  caseRef: string,
  body: unknown,
  requestOptions?: RequestOptions
): Promise<ApiResponse<DisputeDraftResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `caseRef` | `string` | Template, Required | Case ref. |
| `body` | `unknown` | Body, Required | JSON body for: Draft. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`DisputeDraftResponse`](../../doc/models/dispute-draft-response.md).

## Example Usage

```ts
const caseRef = 'case-ref-001';

const body = {  };

try {
  const response = await otherController.postDisputesCaseRefDraft(
    caseRef,
    body
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Post Policy Assess

Policy Assess. Local console route POST /api/v1/policy/assess on synthetic data; advisory only.

```ts
async postPolicyAssess(
  body: PolicyRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PolicyAssessmentResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PolicyRequest`](../../doc/models/policy-request.md) | Body, Required | JSON body for: Policy Assess. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`PolicyAssessmentResponse`](../../doc/models/policy-assessment-response.md).

## Example Usage

```ts
const body: PolicyRequest = {
  asOf: '2026-10-07T00:00:00Z',
  jurisdiction: 'US',
  observationMaxAgeDays: 30,
  theme: ThemeEnum.SourceCompliance,
};

try {
  const response = await otherController.postPolicyAssess(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |

