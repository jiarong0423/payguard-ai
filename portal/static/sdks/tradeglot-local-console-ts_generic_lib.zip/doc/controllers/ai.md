# Ai

Evidence brief (local console with a model profile only).

```ts
const aiController = new AiController(client);
```

## Class Name

`AiController`

## Methods

* [Post Ai Evidence Brief](../../doc/controllers/ai.md#post-ai-evidence-brief)
* [Get Ai Usage](../../doc/controllers/ai.md#get-ai-usage)


# Post Ai Evidence Brief

Evidence Brief. Local console route POST /api/v1/ai/evidence-brief on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```ts
async postAiEvidenceBrief(
  body: AiBriefHttpRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<AiBriefResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AiBriefHttpRequest`](../../doc/models/ai-brief-http-request.md) | Body, Required | JSON body for: Evidence Brief. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`AiBriefResponse`](../../doc/models/ai-brief-response.md).

## Example Usage

```ts
const body: AiBriefHttpRequest = {
  stage: StageEnum.SourceCompliance,
};

try {
  const response = await aiController.postAiEvidenceBrief(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |


# Get Ai Usage

(optimise r24) This session's AI calls: stage, model, tokens, latency, estimated cost. No prompt or reply
text is ever stored; the hosted demo makes no model call and answers an empty list.

```ts
async getAiUsage(
  requestOptions?: RequestOptions
): Promise<ApiResponse<AiUsageResponse>>
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`AiUsageResponse`](../../doc/models/ai-usage-response.md).

## Example Usage

```ts
try {
  const response = await aiController.getAiUsage();

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Example Response *(as JSON)*

```json
{
  "cost_note": "example",
  "entries": [
    {
      "at": "example",
      "latency_ms": 0,
      "outcome": "ok",
      "stage": "source_compliance"
    }
  ],
  "price_table_source": "example",
  "source": "session_memory"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |

