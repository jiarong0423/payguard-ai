# References

Pinned official references and search over them.

```ts
const referencesController = new ReferencesController(client);
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```ts
async postReferencesSearch(
  body: ReferenceRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<ReferenceResponse>>
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | JSON body for: References. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`ReferenceResponse`](../../doc/models/reference-response.md).

## Example Usage

```ts
const body: ReferenceRequest = {
  jurisdiction: 'US',
  query: 'example',
  theme: ThemeEnum.SourceCompliance,
};

try {
  const response = await referencesController.postReferencesSearch(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof ErrorBodyError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyError`](../../doc/models/error-body-error.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyError`](../../doc/models/error-body-error.md) |

