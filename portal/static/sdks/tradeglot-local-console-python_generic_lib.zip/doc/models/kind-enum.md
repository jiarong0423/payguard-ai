
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDER_RECORD_CREATED` |
| `DELIVERY` |
| `CLAIM_OPENED` |

## Example

```python
from tradeglotlocalconsole.models.kind_enum import KindEnum

kind = KindEnum.DELIVERY
```

