
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. |
| `options` | [`List[GuideOption]`](../../doc/models/guide-option.md) | Required | Options. |
| `placeholder` | str | Required | This is a container for any-of cases. |

## Example

```python
from tradeglotlocalconsole.models.guide_form import GuideForm
from tradeglotlocalconsole.models.guide_option import GuideOption
from tradeglotlocalconsole.models.kind_2_enum import Kind2Enum

guide_form = GuideForm(
    kind=Kind2Enum.TEXT,
    options=[
        GuideOption(
            label='label2',
            value='value4'
        )
    ],
    placeholder='String7'
)
```

