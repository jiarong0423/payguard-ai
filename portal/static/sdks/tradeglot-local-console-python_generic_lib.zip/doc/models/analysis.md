
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [Reason5](../../doc/models/reason-5-enum.md) \| None | Optional | This is a container for any-of cases. |
| `status` | [`Status8Enum`](../../doc/models/status-8-enum.md) | Optional | Status. |
| `turn` | `int` | Optional | Turn. |

## Example

```python
from tradeglotlocalconsole.models.analysis import Analysis
from tradeglotlocalconsole.models.reason_5_enum import Reason5Enum
from tradeglotlocalconsole.models.status_8_enum import Status8Enum

analysis = Analysis(
    reason=Reason5Enum.INVALID_REPLY,
    status=Status8Enum.REPLACED,
    turn=198
)
```

