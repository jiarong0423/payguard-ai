
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```python
from tradeglotlocalconsole.models.due_state_enum import DueStateEnum

due_state = DueStateEnum.OPEN
```

