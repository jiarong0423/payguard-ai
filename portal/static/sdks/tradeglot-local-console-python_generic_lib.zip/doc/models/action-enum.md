
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTH_CONNECT` |
| `CREATE_INVOICE_DRAFT` |

## Example

```python
from tradeglotlocalconsole.models.action_enum import ActionEnum

action = ActionEnum.OAUTH_CONNECT
```

