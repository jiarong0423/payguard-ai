
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `str` | Optional | Item. |
| `valid` | `bool` | Optional | Valid. |

## Example

```python
from tradeglotlocalconsole.models.form_result import FormResult

form_result = FormResult(
    item='item6',
    valid=False
)
```

