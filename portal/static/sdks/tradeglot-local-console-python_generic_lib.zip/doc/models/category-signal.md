
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | str | Required | This is a container for any-of cases. |
| `confidence` | [Confidence](../../doc/models/confidence-enum.md) | Required | This is a container for any-of cases. |
| `source` | `str` | Required, Constant | Source.<br><br>**Value**: `"channel3"` |

## Example

```python
from tradeglotlocalconsole.models.category_signal import CategorySignal
from tradeglotlocalconsole.models.confidence_enum import ConfidenceEnum

category_signal = CategorySignal(
    category='String9',
    confidence=ConfidenceEnum.HIGH
)
```

