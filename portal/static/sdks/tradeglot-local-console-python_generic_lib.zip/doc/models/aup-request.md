
# Aup Request

AupRequest.

## Structure

`AupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `str` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |

## Example

```python
from tradeglotlocalconsole.models.aup_request import AupRequest

aup_request = AupRequest(
    description='description8'
)
```

