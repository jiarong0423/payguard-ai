
# Reference Request

ReferenceRequest.

## Structure

`ReferenceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `as_of` | str \| None | Optional | This is a container for any-of cases. |
| `case_stage` | [`CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Optional | Case stage.<br><br>**Default**: `"any"` |
| `jurisdiction` | `str` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` |
| `limit` | `int` | Optional | Limit.<br><br>**Default**: `3`<br><br>**Constraints**: `>= 1`, `<= 10` |
| `material_types` | List[[MaterialType4](../../doc/models/material-type-4-enum.md)] \| None | Optional | This is a container for any-of cases. |
| `max_source_age_days` | int \| None | Optional | This is a container for any-of cases. |
| `query` | `str` | Required | Query.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `512` |
| `require_known_source_date` | `bool` | Optional | Require known source date.<br><br>**Default**: `False` |
| `theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```python
from tradeglotlocalconsole.models.case_stage_2_enum import CaseStage2Enum
from tradeglotlocalconsole.models.material_type_4_enum import MaterialType4Enum
from tradeglotlocalconsole.models.reference_request import ReferenceRequest
from tradeglotlocalconsole.models.theme_enum import ThemeEnum

reference_request = ReferenceRequest(
    query='query0',
    theme=ThemeEnum.VELOCITY_GUARD,
    as_of='String9',
    case_stage=CaseStage2Enum.ANY,
    limit=3,
    material_types=[
        MaterialType4Enum.OFFICIAL_API_REFERENCE,
        MaterialType4Enum.OFFICIAL_POLICY
    ],
    max_source_age_days=100,
    require_known_source_date=False
)
```

