
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_BASELINE` |
| `CALLER_SUPPLIED_UNVERIFIED` |

## Example

```python
from tradeglotlocalconsole.models.baseline_provenance_enum import BaselineProvenanceEnum

baseline_provenance = BaselineProvenanceEnum.SYNTHETIC_BASELINE
```

