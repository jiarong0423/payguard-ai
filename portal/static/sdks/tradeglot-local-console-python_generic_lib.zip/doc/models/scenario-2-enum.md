
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```python
from tradeglotlocalconsole.models.scenario_2_enum import Scenario2Enum

scenario_2 = Scenario2Enum.VELOCITY
```

