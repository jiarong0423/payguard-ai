
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURN_TO_EDIT` |
| `CANCEL` |
| `ACKNOWLEDGE_AND_CONTINUE` |

## Example

```python
from tradeglotlocalconsole.models.choice_enum import ChoiceEnum

choice = ChoiceEnum.RETURN_TO_EDIT
```

