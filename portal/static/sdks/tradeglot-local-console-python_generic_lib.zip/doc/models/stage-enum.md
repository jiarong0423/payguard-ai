
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```python
from tradeglotlocalconsole.models.stage_enum import StageEnum

stage = StageEnum.DISPUTE_MEDIATION
```

