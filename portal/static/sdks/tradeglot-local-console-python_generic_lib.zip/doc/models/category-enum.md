
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UNSUPPORTED_FINANCIAL_PROMISE` |
| `WEAPONS` |
| `CONTROLLED_SUBSTANCES` |
| `COUNTERFEIT_GOODS` |
| `REGULATED_ACTIVITY` |

## Example

```python
from tradeglotlocalconsole.models.category_enum import CategoryEnum

category = CategoryEnum.CONTROLLED_SUBSTANCES
```

