
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

## Example

```python
from tradeglotlocalconsole.models.account_type_enum import AccountTypeEnum

account_type = AccountTypeEnum.PERSONAL
```

