
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOT_MADE` |

## Example

```python
from tradeglotlocalconsole.models.judgement_enum import JudgementEnum

judgement = JudgementEnum.NOT_MADE
```

