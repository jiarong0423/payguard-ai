
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `NOT_RECORDED` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```python
from tradeglotlocalconsole.models.reason_7_enum import Reason7Enum

reason_7 = Reason7Enum.UPSTREAM_ERROR
```

