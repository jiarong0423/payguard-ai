
# Health Response

HealthResponse.

## Structure

`HealthResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mode` | `str` | Required, Constant | Mode.<br><br>**Value**: `"demo"` |
| `source` | `str` | Required, Constant | Source.<br><br>**Value**: `"synthetic"` |
| `status` | `str` | Required, Constant | Status.<br><br>**Value**: `"ok"` |
| `version` | `str` | Required | Version. |

## Example

```python
from tradeglotlocalconsole.models.health_response import HealthResponse

health_response = HealthResponse(
    version='version2'
)
```

