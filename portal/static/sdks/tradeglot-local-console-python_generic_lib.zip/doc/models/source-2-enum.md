
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3` |

## Example

```python
from tradeglotlocalconsole.models.source_2_enum import Source2Enum

source_2 = Source2Enum.CHANNEL3
```

