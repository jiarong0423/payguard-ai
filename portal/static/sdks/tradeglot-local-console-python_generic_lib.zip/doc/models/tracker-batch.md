
# Tracker Batch

TrackerBatch.

## Structure

`TrackerBatch`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trackers` | [`List[TrackerItem]`](../../doc/models/tracker-item.md) | Required | Trackers.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `1` |

## Example

```python
from tradeglotlocalconsole.models.carrier_enum import CarrierEnum
from tradeglotlocalconsole.models.tracker_batch import TrackerBatch
from tradeglotlocalconsole.models.tracker_item import TrackerItem

tracker_batch = TrackerBatch(
    trackers=[
        TrackerItem(
            carrier=CarrierEnum.JP_JAPANPOST,
            tracking_number='tracking_number0',
            transaction_id='transaction_id0',
            carrier_name_other='String5'
        )
    ]
)
```

