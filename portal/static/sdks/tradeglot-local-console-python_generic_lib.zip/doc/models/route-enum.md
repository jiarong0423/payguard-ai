
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |
| `SERVICE` |
| `UNKNOWN` |

## Example

```python
from tradeglotlocalconsole.models.route_enum import RouteEnum

route = RouteEnum.PHYSICAL
```

