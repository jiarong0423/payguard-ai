
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```python
from tradeglotlocalconsole.models.external_send_enum import ExternalSendEnum

external_send = ExternalSendEnum.FROZEN
```

