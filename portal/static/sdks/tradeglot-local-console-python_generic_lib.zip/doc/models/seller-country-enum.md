
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```python
from tradeglotlocalconsole.models.seller_country_enum import SellerCountryEnum

seller_country = SellerCountryEnum.GB
```

