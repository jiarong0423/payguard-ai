
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONE_MATCH` |

## Example

```python
from tradeglotlocalconsole.models.choice_2_enum import Choice2Enum

choice_2 = Choice2Enum.CONFIRMED
```

