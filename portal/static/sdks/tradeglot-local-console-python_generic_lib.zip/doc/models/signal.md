
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | str \| None | Optional | This is a container for any-of cases. |
| `confidence` | [Confidence](../../doc/models/confidence-enum.md) \| None | Optional | This is a container for any-of cases. |
| `source` | [`Source2Enum`](../../doc/models/source-2-enum.md) | Optional | Source. |

## Example

```python
from tradeglotlocalconsole.models.confidence_enum import ConfidenceEnum
from tradeglotlocalconsole.models.signal import Signal
from tradeglotlocalconsole.models.source_2_enum import Source2Enum

signal = Signal(
    category='String1',
    confidence=ConfidenceEnum.HIGH,
    source=Source2Enum.CHANNEL3
)
```

