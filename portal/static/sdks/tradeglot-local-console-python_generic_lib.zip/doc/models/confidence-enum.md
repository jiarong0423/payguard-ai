
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```python
from tradeglotlocalconsole.models.confidence_enum import ConfidenceEnum

confidence = ConfidenceEnum.HIGH
```

