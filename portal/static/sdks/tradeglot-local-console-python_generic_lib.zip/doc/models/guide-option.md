
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `str` | Required | Label. |
| `value` | `str` | Required | Value. |

## Example

```python
from tradeglotlocalconsole.models.guide_option import GuideOption

guide_option = GuideOption(
    label='label2',
    value='value4'
)
```

