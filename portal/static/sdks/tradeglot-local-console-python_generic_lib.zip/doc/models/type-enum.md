
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `US_PHONE` |
| `ID_LIKE` |
| `NAME` |
| `ADDRESS` |
| `MANUAL` |
| `MIXED` |

## Example

```python
from tradeglotlocalconsole.models.type_enum import TypeEnum

mtype = TypeEnum.EMAIL
```

