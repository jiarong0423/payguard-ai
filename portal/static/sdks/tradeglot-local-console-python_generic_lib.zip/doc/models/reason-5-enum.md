
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |
| `SUPERSEDED` |

## Example

```python
from tradeglotlocalconsole.models.reason_5_enum import Reason5Enum

reason_5 = Reason5Enum.INVALID_REPLY
```

