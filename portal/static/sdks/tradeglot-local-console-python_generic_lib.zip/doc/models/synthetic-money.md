
# Synthetic Money

Same shape as the PayPal Disputes `dispute_amount` (ProviderMoney below); values are synthetic.

## Structure

`SyntheticMoney`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency_code` | `str` | Required | Currency code.<br><br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `value` | `str` | Required | Value.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,10}(?:\.[0-9]{1,2})?$` |

## Example

```python
from tradeglotlocalconsole.models.synthetic_money import SyntheticMoney

synthetic_money = SyntheticMoney(
    currency_code='currency_code8',
    value='value4'
)
```

