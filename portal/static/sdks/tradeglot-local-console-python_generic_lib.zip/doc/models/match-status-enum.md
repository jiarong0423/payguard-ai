
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NO_MATCH` |
| `REVIEW_SIGNAL` |

## Example

```python
from tradeglotlocalconsole.models.match_status_enum import MatchStatusEnum

match_status = MatchStatusEnum.NO_MATCH
```

