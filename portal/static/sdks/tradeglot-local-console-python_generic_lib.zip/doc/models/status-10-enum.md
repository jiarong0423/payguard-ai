
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```python
from tradeglotlocalconsole.models.status_10_enum import Status10Enum

status_10 = Status10Enum.CONNECTED
```

