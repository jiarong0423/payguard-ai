
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `str` | Required | Item. |
| `reason` | [`Reason6Enum`](../../doc/models/reason-6-enum.md) | Required | Reason. |

## Example

```python
from tradeglotlocalconsole.models.guide_dropped import GuideDropped
from tradeglotlocalconsole.models.reason_6_enum import Reason6Enum

guide_dropped = GuideDropped(
    item='item6',
    reason=Reason6Enum.OTHER_PARTY
)
```

