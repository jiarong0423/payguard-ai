
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```python
from tradeglotlocalconsole.models.currency_enum import CurrencyEnum

currency = CurrencyEnum.USD
```

