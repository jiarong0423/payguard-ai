
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `EXACT` |
| `CLOSE` |

## Example

```python
from tradeglotlocalconsole.models.match_type_enum import MatchTypeEnum

match_type = MatchTypeEnum.EXACT
```

