
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_IMAGEJPEG` |
| `ENUM_IMAGEGIF` |
| `ENUM_IMAGEPNG` |
| `ENUM_APPLICATIONPDF` |

## Example

```python
from tradeglotlocalconsole.models.content_type_enum import ContentTypeEnum

content_type = ContentTypeEnum.ENUM_IMAGEJPEG
```

