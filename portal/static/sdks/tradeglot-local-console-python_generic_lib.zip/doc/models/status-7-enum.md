
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NEEDS_REVIEW` |
| `DRAFT_READY` |
| `LOCAL_DRAFT_REVIEWED` |

## Example

```python
from tradeglotlocalconsole.models.status_7_enum import Status7Enum

status_7 = Status7Enum.LOCAL_DRAFT_REVIEWED
```

