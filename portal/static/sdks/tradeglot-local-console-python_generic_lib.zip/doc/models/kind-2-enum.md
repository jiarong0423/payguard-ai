
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `DATE` |
| `CHOICE` |
| `TEXT` |

## Example

```python
from tradeglotlocalconsole.models.kind_2_enum import Kind2Enum

kind_2 = Kind2Enum.TEXT
```

