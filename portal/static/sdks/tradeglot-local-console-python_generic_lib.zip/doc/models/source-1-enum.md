
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SESSION_MEMORY` |
| `HOSTED_DEMO` |

## Example

```python
from tradeglotlocalconsole.models.source_1_enum import Source1Enum

source_1 = Source1Enum.SESSION_MEMORY
```

