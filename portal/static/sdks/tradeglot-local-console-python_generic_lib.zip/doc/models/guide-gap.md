
# Guide Gap

GuideGap.

## Structure

`GuideGap`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `conflicting` | `List[str]` | Required | Conflicting. |
| `missing` | `List[str]` | Required | Missing. |
| `partial` | `List[str]` | Required | Partial. |
| `present` | `List[str]` | Required | Present. |

## Example

```python
from tradeglotlocalconsole.models.guide_gap import GuideGap

guide_gap = GuideGap(
    conflicting=[
        'conflicting9',
        'conflicting8',
        'conflicting7'
    ],
    missing=[
        'missing2',
        'missing3'
    ],
    partial=[
        'partial4'
    ],
    present=[
        'present7'
    ]
)
```

