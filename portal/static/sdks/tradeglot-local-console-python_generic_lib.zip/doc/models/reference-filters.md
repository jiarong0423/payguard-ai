
# Reference Filters

ReferenceFilters.

## Structure

`ReferenceFilters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `age_basis` | `str` | Required, Constant | Age basis.<br><br>**Value**: `"source_updated_date_utc_calendar"` |
| `as_of` | str | Required | This is a container for any-of cases. |
| `case_stage` | [`CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Required | Case stage. |
| `jurisdiction` | `str` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` |
| `limit` | `int` | Required | Limit.<br><br>**Constraints**: `>= 1`, `<= 10` |
| `material_types` | [`List[MaterialType4Enum]`](../../doc/models/material-type-4-enum.md) | Required | Material types.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `3` |
| `max_source_age_days` | int | Required | This is a container for any-of cases. |
| `require_known_source_date` | `bool` | Required | Require known source date. |
| `theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```python
from tradeglotlocalconsole.models.case_stage_2_enum import CaseStage2Enum
from tradeglotlocalconsole.models.material_type_4_enum import MaterialType4Enum
from tradeglotlocalconsole.models.reference_filters import ReferenceFilters
from tradeglotlocalconsole.models.theme_enum import ThemeEnum

reference_filters = ReferenceFilters(
    as_of='String1',
    case_stage=CaseStage2Enum.PROCEDURAL_ORDER,
    limit=10,
    material_types=[
        MaterialType4Enum.OFFICIAL_POLICY,
        MaterialType4Enum.PUBLIC_COURT_ORDER_COPY
    ],
    max_source_age_days=190,
    require_known_source_date=False,
    theme=ThemeEnum.DISPUTE_MEDIATION
)
```

