
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTURE_OBSERVATION` |
| `STALE_OBSERVATION` |
| `WITHIN_OBSERVATION_BUDGET` |

## Example

```python
from tradeglotlocalconsole.models.observation_status_enum import ObservationStatusEnum

observation_status = ObservationStatusEnum.STALE_OBSERVATION
```

