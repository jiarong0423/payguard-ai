
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | [`CategoryEnum`](../../doc/models/category-enum.md) | Required | Category. |
| `code` | `str` | Required, Constant | Code.<br><br>**Value**: `"keyword_requires_policy_review"` |

## Example

```python
from tradeglotlocalconsole.models.category_enum import CategoryEnum
from tradeglotlocalconsole.models.finding import Finding

finding = Finding(
    category=CategoryEnum.UNSUPPORTED_FINANCIAL_PROMISE
)
```

