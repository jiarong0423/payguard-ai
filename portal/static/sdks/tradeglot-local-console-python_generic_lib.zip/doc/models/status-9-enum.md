
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLY_PRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOT_APPLICABLE` |

## Example

```python
from tradeglotlocalconsole.models.status_9_enum import Status9Enum

status_9 = Status9Enum.MISSING
```

