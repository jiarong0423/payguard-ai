
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `ANY` |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```python
from tradeglotlocalconsole.models.case_stage_2_enum import CaseStage2Enum

case_stage_2 = CaseStage2Enum.ANY
```

