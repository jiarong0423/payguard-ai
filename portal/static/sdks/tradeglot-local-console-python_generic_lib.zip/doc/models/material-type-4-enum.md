
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |
| `PUBLIC_COURT_ORDER_COPY` |

## Example

```python
from tradeglotlocalconsole.models.material_type_4_enum import MaterialType4Enum

material_type_4 = MaterialType4Enum.OFFICIAL_POLICY
```

