
# Guide Subtraction

GuideSubtraction.

## Structure

`GuideSubtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `left` | `int` | Required | Left. |
| `needed` | `int` | Required | Needed. |
| `taken` | `int` | Required | Taken. |
| `text` | `str` | Required | Text. |

## Example

```python
from tradeglotlocalconsole.models.guide_subtraction import GuideSubtraction

guide_subtraction = GuideSubtraction(
    left=174,
    needed=44,
    taken=32,
    text='text2'
)
```

