
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `str` | Required | Item. |
| `valid` | `bool` | Required | Valid. |

## Example

```python
from tradeglotlocalconsole.models.guide_form_result import GuideFormResult

guide_form_result = GuideFormResult(
    item='item8',
    valid=False
)
```

