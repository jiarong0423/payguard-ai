
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |
| `sandbox_reads` | bool \| None | Optional | This is a container for any-of cases. |

## Example

```python
from tradeglotlocalconsole.models.connections_response import ConnectionsResponse
from tradeglotlocalconsole.models.mode_enum import ModeEnum

connections_response = ConnectionsResponse(
    mode=ModeEnum.LOCAL,
    sandbox_reads=True
)
```

