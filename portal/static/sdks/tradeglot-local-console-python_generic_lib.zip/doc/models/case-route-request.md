
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `text` | `str` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```python
from tradeglotlocalconsole.models.case_route_request import CaseRouteRequest

case_route_request = CaseRouteRequest(
    text='text8'
)
```

