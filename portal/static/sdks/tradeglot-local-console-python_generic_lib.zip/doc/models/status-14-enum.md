
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `NORMAL` |
| `REVIEW_VELOCITY` |
| `INSUFFICIENT_BASELINE` |

## Example

```python
from tradeglotlocalconsole.models.status_14_enum import Status14Enum

status_14 = Status14Enum.REVIEW_VELOCITY
```

