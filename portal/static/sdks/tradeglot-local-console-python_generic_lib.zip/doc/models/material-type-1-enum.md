
# Material Type 1 Enum

Material type.

## Enumeration

`MaterialType1Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |
| `PUBLIC_COURT_ORDER_COPY` |

## Example

```python
from tradeglotlocalconsole.models.material_type_1_enum import MaterialType1Enum

material_type_1 = MaterialType1Enum.OFFICIAL_API_REFERENCE
```

