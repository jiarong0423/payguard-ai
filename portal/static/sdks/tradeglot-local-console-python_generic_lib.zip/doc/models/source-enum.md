
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_SANDBOX` |
| `SYNTHETIC_FIXTURE` |

## Example

```python
from tradeglotlocalconsole.models.source_enum import SourceEnum

source = SourceEnum.PAYPAL_SANDBOX
```

