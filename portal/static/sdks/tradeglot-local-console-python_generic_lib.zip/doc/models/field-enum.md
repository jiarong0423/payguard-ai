
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `NAME` |
| `ADDRESS` |
| `EMAIL` |

## Example

```python
from tradeglotlocalconsole.models.field_enum import FieldEnum

field = FieldEnum.ADDRESS
```

