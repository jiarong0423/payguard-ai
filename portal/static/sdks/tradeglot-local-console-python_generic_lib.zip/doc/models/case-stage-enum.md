
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```python
from tradeglotlocalconsole.models.case_stage_enum import CaseStageEnum

case_stage = CaseStageEnum.PROCEDURAL_ORDER
```

