
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `READY_FOR_LOCAL_RULES` |
| `MANUAL_REVIEW` |

## Example

```python
from tradeglotlocalconsole.models.intake_status_enum import IntakeStatusEnum

intake_status = IntakeStatusEnum.READY_FOR_LOCAL_RULES
```

