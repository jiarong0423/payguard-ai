
# Event

## Structure

`Event`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `str` | Optional | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `channel` | [`ChannelEnum`](../../doc/models/channel-enum.md) | Optional | Channel. |
| `direction` | [`DirectionEnum`](../../doc/models/direction-enum.md) | Optional | Direction. |
| `kind` | [`Kind1Enum`](../../doc/models/kind-1-enum.md) | Optional | Kind. |
| `message_digest` | `str` | Optional | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `source` | [`Source6Enum`](../../doc/models/source-6-enum.md) | Optional | Source. |
| `topic` | [`TopicEnum`](../../doc/models/topic-enum.md) | Optional | Topic. |

## Example

```python
from tradeglotlocalconsole.models.channel_enum import ChannelEnum
from tradeglotlocalconsole.models.direction_enum import DirectionEnum
from tradeglotlocalconsole.models.event import Event
from tradeglotlocalconsole.models.kind_1_enum import Kind1Enum

event = Event(
    at='at6',
    channel=ChannelEnum.EMAIL,
    direction=DirectionEnum.INBOUND,
    kind=Kind1Enum.MESSAGE,
    message_digest='message_digest6'
)
```

