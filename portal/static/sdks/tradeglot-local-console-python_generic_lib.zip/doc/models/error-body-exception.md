
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. |

## Example

```python
try:
    # make the API call
except ErrorBodyException as e:
    print(e)
except APIException as e:
    print(e)
```

