
# Guide Field Result

GuideFieldResult.

## Structure

`GuideFieldResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deferred` | `bool` | Required | Deferred. |
| `item` | `str` | Required | Item. |
| `valid` | `bool` | Required | Valid. |

## Example

```python
from tradeglotlocalconsole.models.guide_field_result import GuideFieldResult

guide_field_result = GuideFieldResult(
    deferred=False,
    item='item8',
    valid=False
)
```

