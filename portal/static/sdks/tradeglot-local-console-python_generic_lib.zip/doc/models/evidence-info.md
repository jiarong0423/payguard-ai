
# Evidence Info

EvidenceInfo.

## Structure

`EvidenceInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tracking_info` | [`List[TrackingInfo]`](../../doc/models/tracking-info.md) | Required | Tracking info.<br><br>**Constraints**: *Maximum Items*: `10` |

## Example

```python
from tradeglotlocalconsole.models.carrier_name_enum import CarrierNameEnum
from tradeglotlocalconsole.models.evidence_info import EvidenceInfo
from tradeglotlocalconsole.models.tracking_info import TrackingInfo

evidence_info = EvidenceInfo(
    tracking_info=[
        TrackingInfo(
            carrier_name=CarrierNameEnum.DHL,
            tracking_number='tracking_number6',
            carrier_name_other='String1'
        )
    ]
)
```

