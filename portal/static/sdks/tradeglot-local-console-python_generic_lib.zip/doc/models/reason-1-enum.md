
# Reason 1 Enum

Reason.

## Enumeration

`Reason1Enum`

## Fields

| Name |
|  --- |
| `CATALOGUE_MATCH` |
| `LIVE_CATALOGUE_MATCH` |
| `DIGITAL_WORD` |
| `SERVICE_WORD` |
| `FILTERED_CONFLICT` |
| `NO_CLOSE_MATCH` |
| `NOTHING_TO_MATCH` |

## Example

```python
from tradeglotlocalconsole.models.reason_1_enum import Reason1Enum

reason_1 = Reason1Enum.NOTHING_TO_MATCH
```

