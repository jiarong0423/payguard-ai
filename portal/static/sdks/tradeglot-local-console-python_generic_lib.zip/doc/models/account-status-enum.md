
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```python
from tradeglotlocalconsole.models.account_status_enum import AccountStatusEnum

account_status = AccountStatusEnum.MATCH
```

