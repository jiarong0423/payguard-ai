
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_VERIFIED` |

## Example

```python
from tradeglotlocalconsole.models.effective_date_status_enum import EffectiveDateStatusEnum

effective_date_status = EffectiveDateStatusEnum.DOCUMENT_STATED
```

