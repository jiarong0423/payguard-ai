
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. |

## Example

```python
from tradeglotlocalconsole.models.inject_request import InjectRequest
from tradeglotlocalconsole.models.scenario_5_enum import Scenario5Enum

inject_request = InjectRequest(
    scenario=Scenario5Enum.BURST
)
```

