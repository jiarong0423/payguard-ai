
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `goods_type` | [GoodsType](../../doc/models/goods-type-enum.md) \| None | Optional | This is a container for any-of cases. |
| `scenario` | [`Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. |

## Example

```python
from tradeglotlocalconsole.models.goods_type_enum import GoodsTypeEnum
from tradeglotlocalconsole.models.guide_start_request import GuideStartRequest
from tradeglotlocalconsole.models.scenario_2_enum import Scenario2Enum

guide_start_request = GuideStartRequest(
    scenario=Scenario2Enum.DISPUTE,
    goods_type=GoodsTypeEnum.PHYSICAL
)
```

