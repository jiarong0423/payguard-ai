
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```python
from tradeglotlocalconsole.models.reason_enum import ReasonEnum

reason = ReasonEnum.CONTRACT_REJECTED
```

