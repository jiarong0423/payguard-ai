
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_STATED_IN_REVIEWED_DOCUMENT` |
| `NOT_APPLICABLE` |

## Example

```python
from tradeglotlocalconsole.models.decision_date_status_enum import DecisionDateStatusEnum

decision_date_status = DecisionDateStatusEnum.NOT_APPLICABLE
```

