
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_TEST_RESPONSE` |
| `OPERATOR_LIVE_RESPONSE` |
| `LOCAL_RUNTIME_RESPONSE` |

## Example

```python
from tradeglotlocalconsole.models.execution_evidence_enum import ExecutionEvidenceEnum

execution_evidence = ExecutionEvidenceEnum.OPERATOR_LIVE_RESPONSE
```

