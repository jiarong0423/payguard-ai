
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```python
from tradeglotlocalconsole.models.kind_1_enum import Kind1Enum

kind_1 = Kind1Enum.MESSAGE
```

