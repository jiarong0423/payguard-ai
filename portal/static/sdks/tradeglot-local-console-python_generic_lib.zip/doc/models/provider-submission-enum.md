
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOT_PERFORMED` |
| `PERFORMED` |

## Example

```python
from tradeglotlocalconsole.models.provider_submission_enum import ProviderSubmissionEnum

provider_submission = ProviderSubmissionEnum.NOT_PERFORMED
```

