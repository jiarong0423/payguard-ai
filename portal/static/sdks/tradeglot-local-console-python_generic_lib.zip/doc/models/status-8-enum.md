
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `ANALYSING` |
| `REPLACED` |
| `KEPT` |

## Example

```python
from tradeglotlocalconsole.models.status_8_enum import Status8Enum

status_8 = Status8Enum.ANALYSING
```

