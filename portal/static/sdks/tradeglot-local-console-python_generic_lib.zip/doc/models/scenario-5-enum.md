
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `BURST` |
| `DISPUTE` |
| `RESET` |

## Example

```python
from tradeglotlocalconsole.models.scenario_5_enum import Scenario5Enum

scenario_5 = Scenario5Enum.RESET
```

