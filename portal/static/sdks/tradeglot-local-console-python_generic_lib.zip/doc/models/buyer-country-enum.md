
# Buyer Country Enum

Buyer country.

## Enumeration

`BuyerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```python
from tradeglotlocalconsole.models.buyer_country_enum import BuyerCountryEnum

buyer_country = BuyerCountryEnum.CN
```

