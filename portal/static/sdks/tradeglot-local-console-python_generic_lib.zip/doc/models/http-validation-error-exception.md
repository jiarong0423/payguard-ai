
# HTTP Validation Error Exception

HTTPValidationError.

## Structure

`HTTPValidationErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `detail` | [`List[ValidationError]`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```python
try:
    # make the API call
except HTTPValidationErrorException as e:
    print(e)
except APIException as e:
    print(e)
```

