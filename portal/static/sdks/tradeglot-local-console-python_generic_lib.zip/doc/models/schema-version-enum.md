
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `ENUM_PAYGUARDTIME_EVIDENCEV1` |

## Example

```python
from tradeglotlocalconsole.models.schema_version_enum import SchemaVersionEnum

schema_version = SchemaVersionEnum.ENUM_PAYGUARDTIME_EVIDENCEV1
```

