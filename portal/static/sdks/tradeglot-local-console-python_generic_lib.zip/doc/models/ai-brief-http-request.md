
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | str \| None | Optional | This is a container for any-of cases. |
| `stage` | [`StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. |

## Example

```python
from tradeglotlocalconsole.models.ai_brief_http_request import AiBriefHttpRequest
from tradeglotlocalconsole.models.stage_enum import StageEnum

ai_brief_http_request = AiBriefHttpRequest(
    stage=StageEnum.DISPUTE_MEDIATION,
    case_ref='String7'
)
```

