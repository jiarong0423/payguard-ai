
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```python
from tradeglotlocalconsole.models.scenario_1_enum import Scenario1Enum

scenario_1 = Scenario1Enum.PREFLIGHT
```

