
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```python
from tradeglotlocalconsole.models.source_11_enum import Source11Enum

source_11 = Source11Enum.CHANNEL3_LIVE
```

