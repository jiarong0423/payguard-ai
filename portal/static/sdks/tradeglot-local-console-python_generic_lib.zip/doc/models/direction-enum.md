
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```python
from tradeglotlocalconsole.models.direction_enum import DirectionEnum

direction = DirectionEnum.INBOUND
```

