
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `burst` | `bool` | Required | Burst. |
| `dispute` | `bool` | Required | Dispute. |

## Example

```python
from tradeglotlocalconsole.models.scenario import Scenario

scenario = Scenario(
    burst=False,
    dispute=False
)
```

