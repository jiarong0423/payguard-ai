
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |

## Example

```python
from tradeglotlocalconsole.models.material_type_enum import MaterialTypeEnum

material_type = MaterialTypeEnum.OFFICIAL_API_REFERENCE
```

