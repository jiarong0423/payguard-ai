
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```python
from tradeglotlocalconsole.models.source_5_enum import Source5Enum

source_5 = Source5Enum.PROVIDER
```

