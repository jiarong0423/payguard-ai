
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NOT_CONFIGURED` |
| `DISCONNECTED` |
| `CONNECTED` |
| `ERROR` |

## Example

```python
from tradeglotlocalconsole.models.status_11_enum import Status11Enum

status_11 = Status11Enum.NOT_CONFIGURED
```

