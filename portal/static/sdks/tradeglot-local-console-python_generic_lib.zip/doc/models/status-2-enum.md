
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```python
from tradeglotlocalconsole.models.status_2_enum import Status2Enum

status_2 = Status2Enum.OFF
```

