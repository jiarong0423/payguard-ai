
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `PAYGUARDFIXEDSYNTHETICBRIEFV1` |
| `PAYGUARDSESSIONBRIEFV1` |

## Example

```python
from tradeglotlocalconsole.models.fixture_id_enum import FixtureIdEnum

fixture_id = FixtureIdEnum.PAYGUARDFIXEDSYNTHETICBRIEFV1
```

