
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `KEYWORD` |
| `MODEL` |
| `KEYWORD_FALLBACK` |
| `FORM` |

## Example

```python
from tradeglotlocalconsole.models.chooser_enum import ChooserEnum

chooser = ChooserEnum.FORM
```

