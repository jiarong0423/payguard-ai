
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `ENUM_1` |

## Example

```python
from tradeglotlocalconsole.models.schema_version_1_enum import SchemaVersion1Enum

schema_version_1 = SchemaVersion1Enum.ENUM_1
```

