
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POST_RESPONSE_ONLY` |

## Example

```python
from tradeglotlocalconsole.models.proof_kind_enum import ProofKindEnum

proof_kind = ProofKindEnum.POST_RESPONSE_ONLY
```

