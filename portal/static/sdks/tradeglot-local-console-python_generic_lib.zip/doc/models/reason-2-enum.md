
# Reason 2 Enum

Reason.

## Enumeration

`Reason2Enum`

## Fields

| Name |
|  --- |
| `MERCHANDISE_OR_SERVICE_NOT_RECEIVED` |
| `MERCHANDISE_OR_SERVICE_NOT_AS_DESCRIBED` |
| `UNAUTHORISED` |
| `CREDIT_NOT_PROCESSED` |
| `DUPLICATE_TRANSACTION` |
| `INCORRECT_AMOUNT` |
| `PAYMENT_BY_OTHER_MEANS` |
| `CANCELED_RECURRING_BILLING` |
| `OTHER` |

## Example

```python
from tradeglotlocalconsole.models.reason_2_enum import Reason2Enum

reason_2 = Reason2Enum.OTHER
```

