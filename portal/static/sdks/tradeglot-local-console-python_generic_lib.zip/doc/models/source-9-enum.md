
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `WORDS` |
| `WORDS_PENDING` |

## Example

```python
from tradeglotlocalconsole.models.source_9_enum import Source9Enum

source_9 = Source9Enum.WORDS
```

