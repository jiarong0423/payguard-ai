
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |

## Example

```python
from tradeglotlocalconsole.models.environment_enum import EnvironmentEnum

environment = EnvironmentEnum.SANDBOX
```

