
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |
| `FIXTURE` |

## Example

```python
from tradeglotlocalconsole.models.data_source_label_enum import DataSourceLabelEnum

data_source_label = DataSourceLabelEnum.SANDBOX
```

