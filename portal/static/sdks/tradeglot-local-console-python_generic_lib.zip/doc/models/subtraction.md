
# Subtraction

Subtraction.

## Structure

`Subtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `left` | `int` | Optional | Left. |
| `needed` | `int` | Optional | Needed. |
| `taken` | `int` | Optional | Taken. |
| `text` | `str` | Optional | Text. |

## Example

```python
from tradeglotlocalconsole.models.subtraction import Subtraction

subtraction = Subtraction(
    left=232,
    needed=102,
    taken=90,
    text='text6'
)
```

