
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `HOSTED_DEMO` |

## Example

```python
from tradeglotlocalconsole.models.mode_enum import ModeEnum

mode = ModeEnum.LOCAL
```

