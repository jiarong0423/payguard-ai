
# Reason Code Enum

## Enumeration

`ReasonCodeEnum`

## Fields

| Name |
|  --- |
| `ACTION_CLAIM_FORBIDDEN` |
| `ASSURANCE_CLAIM_FORBIDDEN` |
| `CITATION_UNKNOWN` |
| `CITATION_REGION_MISMATCH` |
| `CITATION_THEME_MISMATCH` |
| `CLAIM_REFERENCE_TYPE_MISMATCH` |
| `FUTURE_OBSERVATION` |
| `STALE_OBSERVATION` |
| `DOCUMENT_UPDATE_IN_FUTURE` |
| `CURRENT_POLICY_NOT_ESTABLISHED` |

## Example

```python
from tradeglotlocalconsole.models.reason_code_enum import ReasonCodeEnum

reason_code = ReasonCodeEnum.FUTURE_OBSERVATION
```

