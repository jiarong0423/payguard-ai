
# Carrier Enum

Carrier.

## Enumeration

`CarrierEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TW_CHUNGHWA_POST` |
| `JP_JAPANPOST` |
| `OTHER` |

## Example

```python
from tradeglotlocalconsole.models.carrier_enum import CarrierEnum

carrier = CarrierEnum.USPS
```

