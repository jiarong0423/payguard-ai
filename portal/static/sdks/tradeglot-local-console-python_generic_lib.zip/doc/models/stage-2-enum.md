
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |
| `GUIDE` |
| `STUDIO_AGENT` |

## Example

```python
from tradeglotlocalconsole.models.stage_2_enum import Stage2Enum

stage_2 = Stage2Enum.DISPUTE_MEDIATION
```

