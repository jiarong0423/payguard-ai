
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `REFERENCES_FOUND` |
| `EVIDENCE_MISSING` |

## Example

```python
from tradeglotlocalconsole.models.status_13_enum import Status13Enum

status_13 = Status13Enum.REFERENCES_FOUND
```

