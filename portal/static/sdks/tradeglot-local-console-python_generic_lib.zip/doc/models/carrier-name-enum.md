
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TW_CHUNGHWA_POST` |
| `JP_JAPANPOST` |
| `OTHER` |

## Example

```python
from tradeglotlocalconsole.models.carrier_name_enum import CarrierNameEnum

carrier_name = CarrierNameEnum.FEDEX
```

