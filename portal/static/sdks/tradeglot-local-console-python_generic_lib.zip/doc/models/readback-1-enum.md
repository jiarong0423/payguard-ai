
# Readback 1 Enum

Readback.

## Enumeration

`Readback1Enum`

## Fields

| Name |
|  --- |
| `PROVIDE_EVIDENCE_PREVIEW` |
| `PROVIDE_EVIDENCE_SUBMITTED` |

## Example

```python
from tradeglotlocalconsole.models.readback_1_enum import Readback1Enum

readback_1 = Readback1Enum.PROVIDE_EVIDENCE_PREVIEW
```

