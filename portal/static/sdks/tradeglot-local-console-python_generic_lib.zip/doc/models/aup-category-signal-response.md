
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `affects_decision` | `str` | Required, Constant | Affects decision.<br><br>**Value**: `"False"` |
| `reason` | [Reason](../../doc/models/reason-enum.md) | Required | This is a container for any-of cases. |
| `signal` | [CategorySignal](../../doc/models/category-signal.md) | Required | This is a container for any-of cases. |
| `status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Required | Status. |

## Example

```python
from tradeglotlocalconsole.models.aup_category_signal_response import AupCategorySignalResponse
from tradeglotlocalconsole.models.category_signal import CategorySignal
from tradeglotlocalconsole.models.confidence_enum import ConfidenceEnum
from tradeglotlocalconsole.models.reason_enum import ReasonEnum
from tradeglotlocalconsole.models.status_2_enum import Status2Enum

aup_category_signal_response = AupCategorySignalResponse(
    reason=ReasonEnum.TIMEOUT,
    signal=CategorySignal(
        category='String9',
        confidence=ConfidenceEnum.HIGH
    ),
    status=Status2Enum.OFF
)
```

