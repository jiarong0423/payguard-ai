
# Activity

Activity.

## Structure

`Activity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `str` | Required | At. |
| `id` | `str` | Required | Id. |
| `kind` | `str` | Required | Kind. |
| `label` | `str` | Required | Label. |
| `source` | `str` | Required, Constant | Source.<br><br>**Value**: `"synthetic"` |

## Example

```python
from tradeglotlocalconsole.models.activity import Activity

activity = Activity(
    at='at4',
    id='id8',
    kind='kind6',
    label='label8'
)
```

