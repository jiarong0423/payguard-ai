
# Source 8 Enum

Source.

## Enumeration

`Source8Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL` |
| `SUGGESTION` |

## Example

```python
from tradeglotlocalconsole.models.source_8_enum import Source8Enum

source_8 = Source8Enum.OFFICIAL
```

