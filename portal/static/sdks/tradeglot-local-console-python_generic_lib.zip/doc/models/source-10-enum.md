
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```python
from tradeglotlocalconsole.models.source_10_enum import Source10Enum

source_10 = Source10Enum.CHANNEL3_LIVE
```

