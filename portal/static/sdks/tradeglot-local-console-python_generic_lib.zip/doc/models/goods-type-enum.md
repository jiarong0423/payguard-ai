
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |

## Example

```python
from tradeglotlocalconsole.models.goods_type_enum import GoodsTypeEnum

goods_type = GoodsTypeEnum.PHYSICAL
```

