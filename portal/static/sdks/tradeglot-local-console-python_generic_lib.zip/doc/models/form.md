
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Optional | Kind. |
| `options` | [`List[GuideOption]`](../../doc/models/guide-option.md) | Optional | Options. |
| `placeholder` | str \| None | Optional | This is a container for any-of cases. |

## Example

```python
from tradeglotlocalconsole.models.form import Form
from tradeglotlocalconsole.models.guide_option import GuideOption
from tradeglotlocalconsole.models.kind_2_enum import Kind2Enum

form = Form(
    kind=Kind2Enum.TEXT,
    options=[
        GuideOption(
            label='label2',
            value='value4'
        ),
        GuideOption(
            label='label2',
            value='value4'
        ),
        GuideOption(
            label='label2',
            value='value4'
        )
    ],
    placeholder='String9'
)
```

