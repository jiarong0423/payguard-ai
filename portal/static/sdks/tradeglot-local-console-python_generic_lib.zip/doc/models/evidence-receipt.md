
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`ActionEnum`](../../doc/models/action-enum.md) | Optional | Action. |
| `environment` | [`EnvironmentEnum`](../../doc/models/environment-enum.md) | Optional | Environment. |
| `evidence_class` | [`EvidenceClass3Enum`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. |
| `external_send` | [`ExternalSend1Enum`](../../doc/models/external-send-1-enum.md) | Optional | External send. |
| `invoice_id` | str \| None | Optional | This is a container for any-of cases. |
| `observed_at` | `str` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `paypal_debug_id` | str \| None | Optional | This is a container for any-of cases. |
| `proof_kind` | [`ProofKindEnum`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. |
| `schema_version` | [`SchemaVersion1Enum`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. |
| `separate_get_readback` | `bool` | Optional | Separate get readback. |
| `status` | [`Status10Enum`](../../doc/models/status-10-enum.md) | Optional | Status. |

## Example

```python
from tradeglotlocalconsole.models.action_enum import ActionEnum
from tradeglotlocalconsole.models.environment_enum import EnvironmentEnum
from tradeglotlocalconsole.models.evidence_class_3_enum import EvidenceClass3Enum
from tradeglotlocalconsole.models.evidence_receipt import EvidenceReceipt
from tradeglotlocalconsole.models.external_send_1_enum import ExternalSend1Enum

evidence_receipt = EvidenceReceipt(
    action=ActionEnum.OAUTH_CONNECT,
    environment=EnvironmentEnum.SANDBOX,
    evidence_class=EvidenceClass3Enum.AUTHENTIC_SANDBOX_RESPONSE,
    external_send=ExternalSend1Enum.FROZEN,
    invoice_id='String3'
)
```

