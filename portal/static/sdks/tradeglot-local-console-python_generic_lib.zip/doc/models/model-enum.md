
# Model Enum

Model.

## Enumeration

`ModelEnum`

## Fields

| Name |
|  --- |
| `ENUM_GEMINI38FLASH` |
| `NVIDIANEMOTRON3NANO4B` |

## Example

```python
from tradeglotlocalconsole.models.model_enum import ModelEnum

model = ModelEnum.ENUM_GEMINI38FLASH
```

