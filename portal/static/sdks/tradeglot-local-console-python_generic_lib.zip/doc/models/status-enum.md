
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURE_COMPATIBLE` |
| `INCOMPLETE_EVIDENCE` |
| `REJECTED` |

## Example

```python
from tradeglotlocalconsole.models.status_enum import StatusEnum

status = StatusEnum.REJECTED
```

