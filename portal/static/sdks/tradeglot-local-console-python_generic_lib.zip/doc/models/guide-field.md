
# Guide Field

GuideField.

## Structure

`GuideField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `str` | Required | Item.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-z_]+$` |
| `value` | `str` | Required | Value.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `120` |

## Example

```python
from tradeglotlocalconsole.models.guide_field import GuideField

guide_field = GuideField(
    item='item4',
    value='value4'
)
```

