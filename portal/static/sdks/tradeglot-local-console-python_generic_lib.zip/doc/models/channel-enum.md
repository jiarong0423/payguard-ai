
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATE_MESSAGE` |

## Example

```python
from tradeglotlocalconsole.models.channel_enum import ChannelEnum

channel = ChannelEnum.EMAIL
```

