
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OTHER_PARTY` |
| `INFERRED` |

## Example

```python
from tradeglotlocalconsole.models.reason_6_enum import Reason6Enum

reason_6 = Reason6Enum.OTHER_PARTY
```

