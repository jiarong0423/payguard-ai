
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```python
from tradeglotlocalconsole.models.external_send_1_enum import ExternalSend1Enum

external_send_1 = ExternalSend1Enum.FROZEN
```

