
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `BEFORE_CUTOFF` |
| `AFTER_CUTOFF` |

## Example

```python
from tradeglotlocalconsole.models.account_opened_enum import AccountOpenedEnum

account_opened = AccountOpenedEnum.AFTER_CUTOFF
```

