
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```python
from tradeglotlocalconsole.models.missing_official_policy_theme_enum import MissingOfficialPolicyThemeEnum

missing_official_policy_theme = MissingOfficialPolicyThemeEnum.VELOCITY_GUARD
```

