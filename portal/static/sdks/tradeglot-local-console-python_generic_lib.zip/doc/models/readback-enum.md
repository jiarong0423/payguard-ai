
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADD_TRACKING_PREVIEW` |
| `ADD_TRACKING_SUBMITTED` |

## Example

```python
from tradeglotlocalconsole.models.readback_enum import ReadbackEnum

readback = ReadbackEnum.ADD_TRACKING_PREVIEW
```

