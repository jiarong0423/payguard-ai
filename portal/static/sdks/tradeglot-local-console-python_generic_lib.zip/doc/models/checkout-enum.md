
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_ACCOUNT` |
| `GUEST_CARD` |

## Example

```python
from tradeglotlocalconsole.models.checkout_enum import CheckoutEnum

checkout = CheckoutEnum.PAYPAL_ACCOUNT
```

