
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `MANUAL_REVIEW` |
| `REVIEW_EVIDENCE` |

## Example

```python
from tradeglotlocalconsole.models.status_5_enum import Status5Enum

status_5 = Status5Enum.MANUAL_REVIEW
```

