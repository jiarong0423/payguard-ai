
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `MISSING` |

## Example

```python
from tradeglotlocalconsole.models.source_updated_date_status_enum import SourceUpdatedDateStatusEnum

source_updated_date_status = SourceUpdatedDateStatusEnum.DOCUMENT_STATED
```

