
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```python
from tradeglotlocalconsole.models.theme_enum import ThemeEnum

theme = ThemeEnum.SOURCE_COMPLIANCE
```

