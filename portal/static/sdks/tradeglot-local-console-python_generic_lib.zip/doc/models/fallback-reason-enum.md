
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |

## Example

```python
from tradeglotlocalconsole.models.fallback_reason_enum import FallbackReasonEnum

fallback_reason = FallbackReasonEnum.LATE
```

