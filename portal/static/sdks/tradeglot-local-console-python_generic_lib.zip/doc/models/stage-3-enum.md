
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `FUNNEL` |
| `ECHO` |
| `FILL` |
| `REVIEW` |
| `DONE` |

## Example

```python
from tradeglotlocalconsole.models.stage_3_enum import Stage3Enum

stage_3 = Stage3Enum.REVIEW
```

