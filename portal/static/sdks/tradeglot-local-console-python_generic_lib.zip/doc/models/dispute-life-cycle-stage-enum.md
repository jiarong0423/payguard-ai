
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PRE_ARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```python
from tradeglotlocalconsole.models.dispute_life_cycle_stage_enum import DisputeLifeCycleStageEnum

dispute_life_cycle_stage = DisputeLifeCycleStageEnum.UNKNOWN
```

