
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `KEYWORD` |
| `GEMINI` |

## Example

```python
from tradeglotlocalconsole.models.chooser_mode_enum import ChooserModeEnum

chooser_mode = ChooserModeEnum.KEYWORD
```

