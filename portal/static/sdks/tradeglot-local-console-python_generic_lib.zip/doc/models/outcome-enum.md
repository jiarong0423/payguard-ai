
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ERROR` |

## Example

```python
from tradeglotlocalconsole.models.outcome_enum import OutcomeEnum

outcome = OutcomeEnum.OK
```

