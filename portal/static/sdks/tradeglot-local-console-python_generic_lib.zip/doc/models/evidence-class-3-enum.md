
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |

## Example

```python
from tradeglotlocalconsole.models.evidence_class_3_enum import EvidenceClass3Enum

evidence_class_3 = EvidenceClass3Enum.AUTHENTIC_SANDBOX_RESPONSE
```

