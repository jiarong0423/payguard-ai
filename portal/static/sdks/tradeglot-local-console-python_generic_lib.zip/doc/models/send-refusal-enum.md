
# Send Refusal Enum

## Enumeration

`SendRefusalEnum`

## Fields

| Name |
|  --- |
| `ACCOUNT_IDENTITY_UNKNOWN` |
| `DISPUTE_NOT_THIS_ACCOUNT` |
| `DISPUTE_DETAIL_REQUIRED` |
| `SELLER_EVIDENCE_ALREADY_SUBMITTED` |
| `DISPUTE_NOT_AWAITING_SELLER` |
| `DISPUTE_EVIDENCE_NOT_OFFERED` |

## Example

```python
from tradeglotlocalconsole.models.send_refusal_enum import SendRefusalEnum

send_refusal = SendRefusalEnum.DISPUTE_NOT_AWAITING_SELLER
```

