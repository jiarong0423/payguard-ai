
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOT_FOUND` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```python
from tradeglotlocalconsole.models.status_12_enum import Status12Enum

status_12 = Status12Enum.NOT_FOUND
```

