
# Source 6 Enum

Source.

## Enumeration

`Source6Enum`

## Fields

| Name |
|  --- |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```python
from tradeglotlocalconsole.models.source_6_enum import Source6Enum

source_6 = Source6Enum.SELLER_PROVIDED_UNVERIFIED
```

