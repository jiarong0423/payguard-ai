
# Dispute Routing

DisputeRouting.

## Structure

`DisputeRouting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `available_actions` | `List[str]` | Required | Available actions.<br><br>**Constraints**: *Maximum Items*: `20` |
| `dispute_life_cycle_stage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `due_state` | [`DueStateEnum`](../../doc/models/due-state-enum.md) | Required | Due state. |
| `human_review_required` | `str` | Required, Constant | Human review required.<br><br>**Value**: `"True"` |
| `overall_state` | [`OverallStateEnum`](../../doc/models/overall-state-enum.md) | Required | Overall state. |
| `provider_submission` | `str` | Required, Constant | Provider submission.<br><br>**Value**: `"NOT_PERFORMED"` |
| `reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `requirements` | [`List[DisputeRequirement]`](../../doc/models/dispute-requirement.md) | Required | Requirements.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `20` |
| `schema_version` | `int` | Required, Constant | Schema version.<br><br>**Value**: `1` |
| `seller_response_due_date` | `str` | Required | Seller response due date.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `64` |
| `snapshot_class` | `str` | Required, Constant | Snapshot class.<br><br>**Value**: `"SYNTHETIC_PROVIDER_FIXTURE"` |
| `status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |

## Example

```python
from tradeglotlocalconsole.models.dispute_life_cycle_stage_enum import DisputeLifeCycleStageEnum
from tradeglotlocalconsole.models.dispute_requirement import DisputeRequirement
from tradeglotlocalconsole.models.dispute_routing import DisputeRouting
from tradeglotlocalconsole.models.due_state_enum import DueStateEnum
from tradeglotlocalconsole.models.overall_state_enum import OverallStateEnum
from tradeglotlocalconsole.models.reason_2_enum import Reason2Enum
from tradeglotlocalconsole.models.requirement_state_enum import RequirementStateEnum
from tradeglotlocalconsole.models.status_3_enum import Status3Enum

dispute_routing = DisputeRouting(
    available_actions=[
        'available_actions2',
        'available_actions3'
    ],
    dispute_life_cycle_stage=DisputeLifeCycleStageEnum.CHARGEBACK,
    due_state=DueStateEnum.OPEN,
    overall_state=OverallStateEnum.DUE_DATE_EXPIRED,
    reason=Reason2Enum.DUPLICATE_TRANSACTION,
    requirements=[
        DisputeRequirement(
            accepted_attachment_count=20,
            mandatory=False,
            proof_count=60,
            provider_evidence_type='provider_evidence_type0',
            request_id='request_id8',
            requirement_state=RequirementStateEnum.CONTEXT_ONLY,
            source='source2',
            action='String5',
            evidence_type='String3'
        )
    ],
    seller_response_due_date='seller_response_due_date0',
    status=Status3Enum.OPEN
)
```

