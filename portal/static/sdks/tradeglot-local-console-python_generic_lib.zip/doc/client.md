
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT", "GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| demo_csrf_credentials | [`DemoCsrfCredentials`](auth/custom-header-signature.md) | The credential object for Custom Header Signature |
| demo_session_credentials | [`DemoSessionCredentials`](auth/custom-header-signature-1.md) | The credential object for Custom Header Signature |

The API client can be initialized as follows:

## Code-Based Client Initialization

```python
from tradeglotlocalconsole.configuration import Environment
from tradeglotlocalconsole.http.auth.demo_csrf import DemoCsrfCredentials
from tradeglotlocalconsole.http.auth.demo_session import DemoSessionCredentials
from tradeglotlocalconsole.tradeglotlocalconsole_client import TradeglotlocalconsoleClient

client = TradeglotlocalconsoleClient(
    demo_csrf_credentials=DemoCsrfCredentials(
        x_csrf_token='X-CSRF-Token'
    ),
    demo_session_credentials=DemoSessionCredentials(
        x_demo_session='X-Demo-Session'
    ),
    environment=Environment.PRODUCTION
)
```

## Environment-Based Client Initialization

```python
from tradeglotlocalconsole.tradeglotlocalconsole_client import TradeglotlocalconsoleClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = TradeglotlocalconsoleClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](../doc/environment-based-client-initialization.md) section for details.

## TradeGlot Local Console Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| ai | Gets AiController |
| aup | Gets AupController |
| demo | Gets DemoController |
| guide | Gets GuideController |
| health | Gets HealthController |
| other | Gets OtherController |
| paypal | Gets PaypalController |
| references | Gets ReferencesController |
| studio | Gets StudioController |

