# References

Pinned official references and search over them.

```python
references_controller = client.references
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```python
def post_references_search(self,
                          body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ReferenceResponse`](../../doc/models/reference-response.md)

## Example Usage

```python
body = ReferenceRequest(
    query='query6',
    theme=ThemeEnum.DISPUTE_MEDIATION,
    case_stage=CaseStage2Enum.ANY,
    limit=3,
    require_known_source_date=False
)

result = references_controller.post_references_search(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

