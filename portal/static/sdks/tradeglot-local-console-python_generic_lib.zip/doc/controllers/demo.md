# Demo

Demo session, scenarios and local state.

```python
demo_controller = client.demo
```

## Class Name

`DemoController`

## Methods

* [Post Demo Inject](../../doc/controllers/demo.md#post-demo-inject)
* [Post Demo Sessions](../../doc/controllers/demo.md#post-demo-sessions)
* [Get Demo State](../../doc/controllers/demo.md#get-demo-state)


# Post Demo Inject

Inject. Local console route POST /api/v1/demo/inject on synthetic data; advisory only.

```python
def post_demo_inject(self,
                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InjectRequest`](../../doc/models/inject-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```python
body = InjectRequest(
    scenario=Scenario5Enum.DISPUTE
)

result = demo_controller.post_demo_inject(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Demo Sessions

New Session. Local console route POST /api/v1/demo/sessions on synthetic data; advisory only.

```python
def post_demo_sessions(self,
                      body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `Any` | Body, Required | - |

## Response Type

**201**: Successful Response

[`SessionResponse`](../../doc/models/session-response.md)

## Example Usage

```python
body = jsonpickle.decode('{"key1":"val1","key2":"val2"}')

result = demo_controller.post_demo_sessions(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Demo State

State. Local console route GET /api/v1/demo/state on synthetic data; advisory only.

```python
def get_demo_state(self)
```

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```python
result = demo_controller.get_demo_state()
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

