# Other

Other console routes.

```python
other_controller = client.other
```

## Class Name

`OtherController`

## Methods

* [Post Advisory Evaluate](../../doc/controllers/other.md#post-advisory-evaluate)
* [Post Cases Route](../../doc/controllers/other.md#post-cases-route)
* [Get Connections](../../doc/controllers/other.md#get-connections)
* [Post Country Rules Check](../../doc/controllers/other.md#post-country-rules-check)
* [Get Country Rules Countries](../../doc/controllers/other.md#get-country-rules-countries)
* [Post Country Rules Search](../../doc/controllers/other.md#post-country-rules-search)
* [Post Disputes Case Ref Approve](../../doc/controllers/other.md#post-disputes-case-ref-approve)
* [Post Disputes Case Ref Draft](../../doc/controllers/other.md#post-disputes-case-ref-draft)
* [Post Policy Assess](../../doc/controllers/other.md#post-policy-assess)


# Post Advisory Evaluate

Advisory Evaluate. Local console route POST /api/v1/advisory/evaluate on synthetic data; advisory only.

```python
def post_advisory_evaluate(self,
                          body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AdvisoryRequest`](../../doc/models/advisory-request.md) | Body, Required | JSON body for: Advisory Evaluate. |

## Response Type

**200**: Successful Response

[`AdvisoryEvaluationResponse`](../../doc/models/advisory-evaluation-response.md)

## Example Usage

```python
body = AdvisoryRequest(
    as_of='examplexxxxxxxxxxxxx',
    candidate_json='example',
    observation_max_age_days=0,
    theme=ThemeEnum.SOURCE_COMPLIANCE
)

result = other_controller.post_advisory_evaluate(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Cases Route

Case Route. Local console route POST /api/v1/cases/route on synthetic data; advisory only.

```python
def post_cases_route(self,
                    body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CaseRouteRequest`](../../doc/models/case-route-request.md) | Body, Required | JSON body for: Case Route. |

## Response Type

**200**: Successful Response

[`CaseRouteResponse`](../../doc/models/case-route-response.md)

## Example Usage

```python
body = CaseRouteRequest(
    text='handmade ceramic coffee mug'
)

result = other_controller.post_cases_route(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Connections

Connections. Local console route GET /api/v1/connections on synthetic data; advisory only.

```python
def get_connections(self)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`ConnectionsResponse`](../../doc/models/connections-response.md)

## Example Usage

```python
result = other_controller.get_connections()
print(result)
```

## Example Response *(as JSON)*

```json
{
  "mode": "hosted_demo",
  "sandbox_reads": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Check

Country Rules Check. Local console route POST /api/v1/country-rules/check on synthetic data; advisory only.

```python
def post_country_rules_check(self,
                            body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesCheckRequest`](../../doc/models/country-rules-check-request.md) | Body, Required | JSON body for: Country Rules Check. |

## Response Type

**200**: Successful Response

`Any`

## Example Usage

```python
body = CountryRulesCheckRequest(
    buyer_country=BuyerCountryEnum.US,
    seller_country=SellerCountryEnum.TW,
    account_type=AccountTypeEnum.BUSINESS,
    amount='120.00',
    checkout=CheckoutEnum.PAYPAL_ACCOUNT,
    currency='USD',
    goods_tags=[]
)

result = other_controller.post_country_rules_check(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Country Rules Countries

Country Rules Countries. Local console route GET /api/v1/country-rules/countries on synthetic data; advisory only.

```python
def get_country_rules_countries(self)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

`Any`

## Example Usage

```python
result = other_controller.get_country_rules_countries()
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Search

Country Rules Search. Local console route POST /api/v1/country-rules/search on synthetic data; advisory only.

```python
def post_country_rules_search(self,
                             body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesSearchRequest`](../../doc/models/country-rules-search-request.md) | Body, Required | JSON body for: Country Rules Search. |

## Response Type

**200**: Successful Response

`Any`

## Example Usage

```python
body = CountryRulesSearchRequest(
    query='example'
)

result = other_controller.post_country_rules_search(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Approve

Approve. Local console route POST /api/v1/disputes/{case_ref}/approve on synthetic data; advisory only.

```python
def post_disputes_case_ref_approve(self,
                                  case_ref,
                                  body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | `str` | Template, Required | Case ref. |
| `body` | [`ApproveRequest`](../../doc/models/approve-request.md) | Body, Required | JSON body for: Approve. |

## Response Type

**200**: Successful Response

[`DisputeApprovalResponse`](../../doc/models/dispute-approval-response.md)

## Example Usage

```python
case_ref = 'case-ref-001'

body = ApproveRequest(
    draft_digest='draft_digest6'
)

result = other_controller.post_disputes_case_ref_approve(
    case_ref,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Draft

Draft. Local console route POST /api/v1/disputes/{case_ref}/draft on synthetic data; advisory only.

```python
def post_disputes_case_ref_draft(self,
                                case_ref,
                                body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | `str` | Template, Required | Case ref. |
| `body` | `Any` | Body, Required | JSON body for: Draft. |

## Response Type

**200**: Successful Response

[`DisputeDraftResponse`](../../doc/models/dispute-draft-response.md)

## Example Usage

```python
case_ref = 'case-ref-001'

body = jsonpickle.decode('{}')

result = other_controller.post_disputes_case_ref_draft(
    case_ref,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Policy Assess

Policy Assess. Local console route POST /api/v1/policy/assess on synthetic data; advisory only.

```python
def post_policy_assess(self,
                      body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PolicyRequest`](../../doc/models/policy-request.md) | Body, Required | JSON body for: Policy Assess. |

## Response Type

**200**: Successful Response

[`PolicyAssessmentResponse`](../../doc/models/policy-assessment-response.md)

## Example Usage

```python
body = PolicyRequest(
    as_of='2026-10-07T00:00:00Z',
    observation_max_age_days=30,
    theme=ThemeEnum.SOURCE_COMPLIANCE
)

result = other_controller.post_policy_assess(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

