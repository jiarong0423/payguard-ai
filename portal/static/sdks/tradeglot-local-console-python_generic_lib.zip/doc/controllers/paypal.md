# Paypal

PayPal Sandbox connection, disputes and the gated evidence request (local console only).

```python
paypal_controller = client.paypal
```

## Class Name

`PaypalController`

## Methods

* [Post Paypal Connect](../../doc/controllers/paypal.md#post-paypal-connect)
* [Get Paypal Disputes](../../doc/controllers/paypal.md#get-paypal-disputes)
* [Post Paypal Disputes Add Tracking](../../doc/controllers/paypal.md#post-paypal-disputes-add-tracking)
* [Post Paypal Disputes Provide Evidence](../../doc/controllers/paypal.md#post-paypal-disputes-provide-evidence)
* [Get Paypal Disputes Dispute Id](../../doc/controllers/paypal.md#get-paypal-disputes-dispute-id)
* [Post Paypal Invoices Draft](../../doc/controllers/paypal.md#post-paypal-invoices-draft)
* [Post Paypal Invoices Review](../../doc/controllers/paypal.md#post-paypal-invoices-review)
* [Get Paypal Status](../../doc/controllers/paypal.md#get-paypal-status)
* [Post Paypal Webhooks Verify](../../doc/controllers/paypal.md#post-paypal-webhooks-verify)


# Post Paypal Connect

Connect. Local console route POST /api/v1/paypal/connect on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```python
def post_paypal_connect(self,
                       body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `Any` | Body, Required | - |

## Response Type

**200**: Successful Response

[`PaypalStatusResponse`](../../doc/models/paypal-status-response.md)

## Example Usage

```python
body = jsonpickle.decode('{"key1":"val1","key2":"val2"}')

result = paypal_controller.post_paypal_connect(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes

List Disputes. Local console route GET /api/v1/paypal/disputes on synthetic data; advisory only.

```python
def get_paypal_disputes(self)
```

## Response Type

**200**: Successful Response

[`DisputeListResponse`](../../doc/models/dispute-list-response.md)

## Example Usage

```python
result = paypal_controller.get_paypal_disputes()
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Add Tracking

Add Tracking. Local console route POST /api/v1/paypal/disputes/add-tracking on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```python
def post_paypal_disputes_add_tracking(self,
                                     body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddTrackingRequest`](../../doc/models/add-tracking-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AddTrackingResponse`](../../doc/models/add-tracking-response.md)

## Example Usage

```python
body = AddTrackingRequest(
    case_ref='case_ref0',
    dispute_id='dispute_id8',
    submit=False
)

result = paypal_controller.post_paypal_disputes_add_tracking(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Provide Evidence

Provide Evidence. Local console route POST /api/v1/paypal/disputes/provide-evidence on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```python
def post_paypal_disputes_provide_evidence(self,
                                         body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProvideEvidenceRequest`](../../doc/models/provide-evidence-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ProvideEvidenceResponse`](../../doc/models/provide-evidence-response.md)

## Example Usage

```python
body = ProvideEvidenceRequest(
    case_ref='case_ref0',
    dispute_id='dispute_id8',
    submit=False
)

result = paypal_controller.post_paypal_disputes_provide_evidence(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes Dispute Id

Get Dispute. Local console route GET /api/v1/paypal/disputes/{dispute_id} on synthetic data; advisory only.

```python
def get_paypal_disputes_dispute_id(self,
                                  dispute_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `dispute_id` | `str` | Template, Required | Dispute id. |

## Response Type

**200**: Successful Response

[`DisputeDetailResponse`](../../doc/models/dispute-detail-response.md)

## Example Usage

```python
dispute_id = 'dispute_id2'

result = paypal_controller.get_paypal_disputes_dispute_id(dispute_id)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Draft

Invoice Draft. Local console route POST /api/v1/paypal/invoices/draft on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```python
def post_paypal_invoices_draft(self,
                              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InvoiceDraftRequest`](../../doc/models/invoice-draft-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`InvoiceDraftResponse`](../../doc/models/invoice-draft-response.md)

## Example Usage

```python
body = InvoiceDraftRequest(
    amount='amount8',
    currency=CurrencyEnum.USD,
    description='description4',
    payload_digest='payload_digest4',
    review_token='review_token4'
)

result = paypal_controller.post_paypal_invoices_draft(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Review

Invoice Review. Local console route POST /api/v1/paypal/invoices/review on synthetic data; advisory only.

```python
def post_paypal_invoices_review(self,
                               body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InvoiceReviewRequest`](../../doc/models/invoice-review-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`InvoiceReviewResponse`](../../doc/models/invoice-review-response.md)

## Example Usage

```python
body = InvoiceReviewRequest(
    amount='amount8',
    confirm_sandbox_draft=False,
    currency=CurrencyEnum.USD,
    description='description4'
)

result = paypal_controller.post_paypal_invoices_review(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Status

Paypal Status. Local console route GET /api/v1/paypal/status on synthetic data; advisory only.

```python
def get_paypal_status(self)
```

## Response Type

**200**: Successful Response

[`PaypalStatusResponse`](../../doc/models/paypal-status-response.md)

## Example Usage

```python
result = paypal_controller.get_paypal_status()
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Webhooks Verify

Verify Webhook. Local console route POST /api/v1/paypal/webhooks/verify on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```python
def post_paypal_webhooks_verify(self)
```

## Response Type

**200**: Successful Response

[`WebhookVerifyResponse`](../../doc/models/webhook-verify-response.md)

## Example Usage

```python
result = paypal_controller.post_paypal_webhooks_verify()
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

