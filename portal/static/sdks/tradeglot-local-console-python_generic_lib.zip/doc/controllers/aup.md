# Aup

Acceptable-use keyword check and the invoice review that follows it.

```python
aup_controller = client.aup
```

## Class Name

`AupController`

## Methods

* [Post Aup Acknowledge](../../doc/controllers/aup.md#post-aup-acknowledge)
* [Post Aup Category Signal](../../doc/controllers/aup.md#post-aup-category-signal)
* [Post Aup Product Reference](../../doc/controllers/aup.md#post-aup-product-reference)
* [Post Aup Product Reference Confirm](../../doc/controllers/aup.md#post-aup-product-reference-confirm)
* [Post Aup Review](../../doc/controllers/aup.md#post-aup-review)


# Post Aup Acknowledge

Acknowledge Aup. Local console route POST /api/v1/aup/acknowledge on synthetic data; advisory only.

```python
def post_aup_acknowledge(self,
                        body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupAcknowledgeRequest`](../../doc/models/aup-acknowledge-request.md) | Body, Required | JSON body for: Acknowledge Aup. |

## Response Type

**200**: Successful Response

[`AupAcknowledgeResponse`](../../doc/models/aup-acknowledge-response.md)

## Example Usage

```python
body = AupAcknowledgeRequest(
    choice=ChoiceEnum.CANCEL,
    description_digest='description_digest4',
    evaluation_id='evaluation_id0'
)

result = aup_controller.post_aup_acknowledge(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Category Signal

Aup Category Signal. Local console route POST /api/v1/aup/category-signal on synthetic data; advisory only.

```python
def post_aup_category_signal(self,
                            body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupCategorySignalRequest`](../../doc/models/aup-category-signal-request.md) | Body, Required | JSON body for: Aup Category Signal. |

## Response Type

**200**: Successful Response

[`AupCategorySignalResponse`](../../doc/models/aup-category-signal-response.md)

## Example Usage

```python
body = AupCategorySignalRequest(
    description='example',
    evaluation_id='examplexxxxxxxxxxxxxxxxxxxxxxxxx'
)

result = aup_controller.post_aup_category_signal(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference

Aup Product Reference. Local console route POST /api/v1/aup/product-reference on synthetic data; advisory only.

```python
def post_aup_product_reference(self,
                              body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductReferenceRequest`](../../doc/models/product-reference-request.md) | Body, Required | JSON body for: Aup Product Reference. |

## Response Type

**200**: Successful Response

[`ProductReferenceResponse`](../../doc/models/product-reference-response.md)

## Example Usage

```python
body = ProductReferenceRequest(
    description='example',
    evaluation_id='examplexxxxxxxxxxxxxxxxxxxxxxxxx'
)

result = aup_controller.post_aup_product_reference(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference Confirm

Aup Product Confirm. Local console route POST /api/v1/aup/product-reference/confirm on synthetic data; advisory only.

```python
def post_aup_product_reference_confirm(self,
                                      body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductConfirmRequest`](../../doc/models/product-confirm-request.md) | Body, Required | JSON body for: Aup Product Confirm. |

## Response Type

**200**: Successful Response

[`ProductConfirmResponse`](../../doc/models/product-confirm-response.md)

## Example Usage

```python
body = ProductConfirmRequest(
    description='example',
    evaluation_id='examplexxxxxxxxxxxxxxxxxxxxxxxxx',
    product_id='example'
)

result = aup_controller.post_aup_product_reference_confirm(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Review

Aup. Local console route POST /api/v1/aup/review on synthetic data; advisory only.

```python
def post_aup_review(self,
                   body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupRequest`](../../doc/models/aup-request.md) | Body, Required | JSON body for: Aup. |

## Response Type

**200**: Successful Response

[`AupResponse`](../../doc/models/aup-response.md)

## Example Usage

```python
body = AupRequest(
    description='Handmade ceramic coffee mug, shipped in a padded box'
)

result = aup_controller.post_aup_review(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

