# Guide

Evidence guide: gap filling over closed form items.

```python
guide_controller = client.guide
```

## Class Name

`GuideController`

## Methods

* [Post Guide Form](../../doc/controllers/guide.md#post-guide-form)
* [Post Guide Review](../../doc/controllers/guide.md#post-guide-review)
* [Post Guide Start](../../doc/controllers/guide.md#post-guide-start)
* [Get Guide State](../../doc/controllers/guide.md#get-guide-state)
* [Post Guide Turn](../../doc/controllers/guide.md#post-guide-turn)


# Post Guide Form

Guide Form. Local console route POST /api/v1/guide/form on synthetic data; advisory only.

```python
def post_guide_form(self,
                   body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideFormRequest`](../../doc/models/guide-form-request.md) | Body, Required | JSON body for: Guide Form. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```python
body = GuideFormRequest()

result = guide_controller.post_guide_form(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Review

Guide Review. Local console route POST /api/v1/guide/review on synthetic data; advisory only.

```python
def post_guide_review(self,
                     body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideReviewRequest`](../../doc/models/guide-review-request.md) | Body, Required | JSON body for: Guide Review. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```python
body = GuideReviewRequest()

result = guide_controller.post_guide_review(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Start

Guide Start. Local console route POST /api/v1/guide/start on synthetic data; advisory only.

```python
def post_guide_start(self,
                    body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideStartRequest`](../../doc/models/guide-start-request.md) | Body, Required | JSON body for: Guide Start. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```python
body = GuideStartRequest(
    scenario=Scenario2Enum.PREFLIGHT
)

result = guide_controller.post_guide_start(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Guide State

Guide State. Local console route GET /api/v1/guide/state on synthetic data; advisory only.

```python
def get_guide_state(self,
                   scenario=None)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [Scenario1](../../doc/models/scenario-1-enum.md) \| None | Query, Optional | This is a container for any-of cases. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```python
scenario = Scenario1Enum.PREFLIGHT

result = guide_controller.get_guide_state(
    scenario=scenario
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Turn

Guide Turn. Local console route POST /api/v1/guide/turn on synthetic data; advisory only.

```python
def post_guide_turn(self,
                   body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideTurnRequest`](../../doc/models/guide-turn-request.md) | Body, Required | JSON body for: Guide Turn. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```python
body = GuideTurnRequest(
    text='example'
)

result = guide_controller.post_guide_turn(body)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

