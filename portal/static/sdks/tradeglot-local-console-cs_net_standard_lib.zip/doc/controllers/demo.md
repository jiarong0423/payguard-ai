# Demo

Demo session, scenarios and local state.

```csharp
DemoController demoController = client.DemoController;
```

## Class Name

`DemoController`

## Methods

* [Post Demo Inject](../../doc/controllers/demo.md#post-demo-inject)
* [Post Demo Sessions](../../doc/controllers/demo.md#post-demo-sessions)
* [Get Demo State](../../doc/controllers/demo.md#get-demo-state)


# Post Demo Inject

Inject. Local console route POST /api/v1/demo/inject on synthetic data; advisory only.

```csharp
PostDemoInjectAsync(
    Models.InjectRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InjectRequest`](../../doc/models/inject-request.md) | Body, Required | JSON body for: Inject. |

## Response Type

**200**: Successful Response

[`Task<Models.StateResponse>`](../../doc/models/state-response.md)

## Example Usage

```csharp
InjectRequest body = new InjectRequest
{
    Scenario = Scenario5Enum.Burst,
};

try
{
    StateResponse result = await demoController.PostDemoInjectAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Demo Sessions

New Session. Local console route POST /api/v1/demo/sessions on synthetic data; advisory only.

:information_source: **Note** This endpoint does not require authentication.

```csharp
PostDemoSessionsAsync(
    object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `object` | Body, Required | JSON body for: New Session. |

## Response Type

**201**: Successful Response

[`Task<Models.SessionResponse>`](../../doc/models/session-response.md)

## Example Usage

```csharp
object body = ApiHelper.JsonDeserialize<object>("{}");
try
{
    SessionResponse result = await demoController.PostDemoSessionsAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Example Response *(as JSON)*

```json
{
  "csrf_token": "csrf-example-0001",
  "expires_at": "2026-10-07T10:30:00Z",
  "session_id": "sess-example-0001",
  "source": "synthetic"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Demo State

State. Local console route GET /api/v1/demo/state on synthetic data; advisory only.

```csharp
GetDemoStateAsync()
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`Task<Models.StateResponse>`](../../doc/models/state-response.md)

## Example Usage

```csharp
try
{
    StateResponse result = await demoController.GetDemoStateAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

