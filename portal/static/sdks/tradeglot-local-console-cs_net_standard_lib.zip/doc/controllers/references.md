# References

Pinned official references and search over them.

```csharp
ReferencesController referencesController = client.ReferencesController;
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```csharp
PostReferencesSearchAsync(
    Models.ReferenceRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`Task<Models.ReferenceResponse>`](../../doc/models/reference-response.md)

## Example Usage

```csharp
ReferenceRequest body = new ReferenceRequest
{
    Jurisdiction = "US",
    Query = "query6",
    Theme = ThemeEnum.DisputeMediation,
    CaseStage = CaseStage2Enum.Any,
    Limit = 3,
    RequireKnownSourceDate = false,
};

try
{
    ReferenceResponse result = await referencesController.PostReferencesSearchAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
    if (e is HTTPValidationErrorException)
    {
       // TODO: Handle HTTPValidationErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

