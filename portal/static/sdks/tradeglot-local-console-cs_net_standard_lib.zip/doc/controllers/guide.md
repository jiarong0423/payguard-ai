# Guide

Evidence guide: gap filling over closed form items.

```csharp
GuideController guideController = client.GuideController;
```

## Class Name

`GuideController`

## Methods

* [Post Guide Form](../../doc/controllers/guide.md#post-guide-form)
* [Post Guide Review](../../doc/controllers/guide.md#post-guide-review)
* [Post Guide Start](../../doc/controllers/guide.md#post-guide-start)
* [Get Guide State](../../doc/controllers/guide.md#get-guide-state)
* [Post Guide Turn](../../doc/controllers/guide.md#post-guide-turn)


# Post Guide Form

Guide Form. Local console route POST /api/v1/guide/form on synthetic data; advisory only.

```csharp
PostGuideFormAsync(
    Models.GuideFormRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideFormRequest`](../../doc/models/guide-form-request.md) | Body, Required | JSON body for: Guide Form. |

## Response Type

**200**: Successful Response

[`Task<Models.GuideStateResponse>`](../../doc/models/guide-state-response.md)

## Example Usage

```csharp
GuideFormRequest body = new GuideFormRequest
{
};

try
{
    GuideStateResponse result = await guideController.PostGuideFormAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Review

Guide Review. Local console route POST /api/v1/guide/review on synthetic data; advisory only.

```csharp
PostGuideReviewAsync(
    Models.GuideReviewRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideReviewRequest`](../../doc/models/guide-review-request.md) | Body, Required | JSON body for: Guide Review. |

## Response Type

**200**: Successful Response

[`Task<Models.GuideStateResponse>`](../../doc/models/guide-state-response.md)

## Example Usage

```csharp
GuideReviewRequest body = new GuideReviewRequest
{
};

try
{
    GuideStateResponse result = await guideController.PostGuideReviewAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Start

Guide Start. Local console route POST /api/v1/guide/start on synthetic data; advisory only.

```csharp
PostGuideStartAsync(
    Models.GuideStartRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideStartRequest`](../../doc/models/guide-start-request.md) | Body, Required | JSON body for: Guide Start. |

## Response Type

**200**: Successful Response

[`Task<Models.GuideStateResponse>`](../../doc/models/guide-state-response.md)

## Example Usage

```csharp
GuideStartRequest body = new GuideStartRequest
{
    Scenario = Scenario2Enum.Preflight,
};

try
{
    GuideStateResponse result = await guideController.PostGuideStartAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Guide State

Guide State. Local console route GET /api/v1/guide/state on synthetic data; advisory only.

```csharp
GetGuideStateAsync(
    GetGuideStateScenario scenario = null)
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`GetGuideStateScenario`](../../doc/models/containers/get-guide-state-scenario.md) | Query, Optional | This is a container for any-of cases. |

## Response Type

**200**: Successful Response

[`Task<Models.GuideStateResponse>`](../../doc/models/guide-state-response.md)

## Example Usage

```csharp
GetGuideStateScenario scenario = GetGuideStateScenario.FromScenario1(Scenario1Enum.Preflight);

try
{
    GuideStateResponse result = await guideController.GetGuideStateAsync(scenario);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Turn

Guide Turn. Local console route POST /api/v1/guide/turn on synthetic data; advisory only.

```csharp
PostGuideTurnAsync(
    Models.GuideTurnRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideTurnRequest`](../../doc/models/guide-turn-request.md) | Body, Required | JSON body for: Guide Turn. |

## Response Type

**200**: Successful Response

[`Task<Models.GuideStateResponse>`](../../doc/models/guide-state-response.md)

## Example Usage

```csharp
GuideTurnRequest body = new GuideTurnRequest
{
    Text = "example",
};

try
{
    GuideStateResponse result = await guideController.PostGuideTurnAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

