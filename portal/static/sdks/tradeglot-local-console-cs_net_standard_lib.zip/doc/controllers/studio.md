# Studio

AG Studio agent route (local live mode only).

```csharp
StudioController studioController = client.StudioController;
```

## Class Name

`StudioController`

## Methods

* [Get Studio Agent Status](../../doc/controllers/studio.md#get-studio-agent-status)
* [Post Studio Agent Turn](../../doc/controllers/studio.md#post-studio-agent-turn)


# Get Studio Agent Status

Studio Agent Status. Local console route GET /api/v1/studio/agent-status on synthetic data; advisory only.

```csharp
GetStudioAgentStatusAsync()
```

## Response Type

**200**: Successful Response

`Task<object>`

## Example Usage

```csharp
try
{
    object result = await studioController.GetStudioAgentStatusAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Studio Agent Turn

Studio Agent Turn. Local console route POST /api/v1/studio/agent-turn on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```csharp
PostStudioAgentTurnAsync(
    object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `object` | Body, Required | - |

## Response Type

**200**: Successful Response

`Task<object>`

## Example Usage

```csharp
object body = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}");
try
{
    object result = await studioController.PostStudioAgentTurnAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
    if (e is HTTPValidationErrorException)
    {
       // TODO: Handle HTTPValidationErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

