# Ai

Evidence brief (local console with a model profile only).

```csharp
AiController aiController = client.AiController;
```

## Class Name

`AiController`

## Methods

* [Post Ai Evidence Brief](../../doc/controllers/ai.md#post-ai-evidence-brief)
* [Get Ai Usage](../../doc/controllers/ai.md#get-ai-usage)


# Post Ai Evidence Brief

Evidence Brief. Local console route POST /api/v1/ai/evidence-brief on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```csharp
PostAiEvidenceBriefAsync(
    Models.AiBriefHttpRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AiBriefHttpRequest`](../../doc/models/ai-brief-http-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`Task<Models.AiBriefResponse>`](../../doc/models/ai-brief-response.md)

## Example Usage

```csharp
AiBriefHttpRequest body = new AiBriefHttpRequest
{
    Stage = StageEnum.VelocityGuard,
};

try
{
    AiBriefResponse result = await aiController.PostAiEvidenceBriefAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
    if (e is HTTPValidationErrorException)
    {
       // TODO: Handle HTTPValidationErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Ai Usage

(optimise r24) This session's AI calls: stage, model, tokens, latency, estimated cost. No prompt or reply
text is ever stored; the hosted demo makes no model call and answers an empty list.

```csharp
GetAiUsageAsync()
```

## Response Type

**200**: Successful Response

[`Task<Models.AiUsageResponse>`](../../doc/models/ai-usage-response.md)

## Example Usage

```csharp
try
{
    AiUsageResponse result = await aiController.GetAiUsageAsync();
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is ErrorBodyException)
    {
       // TODO: Handle ErrorBodyException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

