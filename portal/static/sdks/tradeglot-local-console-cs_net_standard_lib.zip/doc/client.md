
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| DemoCsrfCredentials | [`DemoCsrfCredentials`](auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |
| DemoSessionCredentials | [`DemoSessionCredentials`](auth/custom-header-signature-1.md) | The Credentials Setter for Custom Header Signature |

The API client can be initialized as follows:

## Code-Based Initialization

```csharp
using TradeGlotLocalConsole.Standard;
using TradeGlotLocalConsole.Standard.Authentication;

namespace ConsoleApp;

TradeGlotLocalConsoleClient client = new TradeGlotLocalConsoleClient.Builder()
    .DemoCsrfCredentials(
        new DemoCsrfModel.Builder(
            "X-CSRF-Token"
        )
        .Build())
    .DemoSessionCredentials(
        new DemoSessionModel.Builder(
            "X-Demo-Session"
        )
        .Build())
    .HttpClientConfig(httpClientConfig =>
        httpClientConfig.Timeout(TimeSpan.FromSeconds(100)))
    .Build();
```

## Configuration-Based Initialization

```csharp
using TradeGlotLocalConsole.Standard;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp;

// Build the IConfiguration using .NET conventions (JSON, environment, etc.)
var configuration = new ConfigurationBuilder()
    .AddJsonFile("config.json")
    .AddEnvironmentVariables() // [optional] read environment variables
    .Build();

// Instantiate your SDK and configure it from IConfiguration
var client = TradeGlotLocalConsoleClient
    .FromConfiguration(configuration.GetSection("TradeGlotLocalConsole"));
```

See the [Configuration-Based Initialization](../doc/configuration-based-initialization.md) section for details.

## TradeGlot Local ConsoleClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| AiController | Gets AiController controller. |
| AupController | Gets AupController controller. |
| DemoController | Gets DemoController controller. |
| GuideController | Gets GuideController controller. |
| HealthController | Gets HealthController controller. |
| OtherController | Gets OtherController controller. |
| PaypalController | Gets PaypalController controller. |
| ReferencesController | Gets ReferencesController controller. |
| StudioController | Gets StudioController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| DemoCsrfCredentials | Gets the credentials to use with DemoCsrf. | [`IDemoCsrfCredentials`](auth/custom-header-signature.md) |
| DemoSessionCredentials | Gets the credentials to use with DemoSession. | [`IDemoSessionCredentials`](auth/custom-header-signature-1.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the TradeGlot Local ConsoleClient using the values provided for the builder. | `Builder` |

## TradeGlot Local ConsoleClient Builder Class

Class to build instances of TradeGlot Local ConsoleClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `DemoCsrfCredentials(Action<DemoCsrfModel.Builder> action)` | Sets credentials for DemoCsrf. | `Builder` |
| `DemoSessionCredentials(Action<DemoSessionModel.Builder> action)` | Sets credentials for DemoSession. | `Builder` |

