
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `Normal` |
| `ReviewVelocity` |
| `InsufficientBaseline` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status14Enum status14 = Status14Enum.ReviewVelocity;
```

