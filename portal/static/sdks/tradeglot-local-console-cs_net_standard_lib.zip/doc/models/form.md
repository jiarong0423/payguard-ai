
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Kind` | [`Kind2Enum?`](../../doc/models/kind-2-enum.md) | Optional | Kind. |
| `Options` | [`List<GuideOption>`](../../doc/models/guide-option.md) | Optional | Options. |
| `Placeholder` | [`FormPlaceholder`](../../doc/models/containers/form-placeholder.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

Form form = new Form
{
    Kind = Kind2Enum.Text,
    Options = new List<GuideOption>
    {
        new GuideOption
        {
            Label = "label2",
            MValue = "value4",
        },
        new GuideOption
        {
            Label = "label2",
            MValue = "value4",
        },
        new GuideOption
        {
            Label = "label2",
            MValue = "value4",
        },
    },
    Placeholder = FormPlaceholder.FromString("String9"),
};
```

