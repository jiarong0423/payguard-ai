
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ThemeEnum theme = ThemeEnum.SourceCompliance;
```

