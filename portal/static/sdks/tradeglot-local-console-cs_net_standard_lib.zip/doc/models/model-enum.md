
# Model Enum

Model.

## Enumeration

`ModelEnum`

## Fields

| Name |
|  --- |
| `EnumGemini38flash` |
| `Nvidianemotron3nano4b` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ModelEnum model = ModelEnum.EnumGemini38flash;
```

