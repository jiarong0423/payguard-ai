
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `Sandbox` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

EnvironmentEnum environment = EnvironmentEnum.Sandbox;
```

