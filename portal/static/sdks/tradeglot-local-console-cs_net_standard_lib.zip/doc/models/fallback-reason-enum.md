
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `Budget` |
| `ProviderError` |
| `InvalidReply` |
| `Late` |
| `NoItems` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

FallbackReasonEnum fallbackReason = FallbackReasonEnum.NoItems;
```

