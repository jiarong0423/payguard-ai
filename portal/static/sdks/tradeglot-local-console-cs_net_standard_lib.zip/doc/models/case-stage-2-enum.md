
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `Any` |
| `ProceduralOrder` |
| `NotApplicable` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CaseStage2Enum caseStage2 = CaseStage2Enum.Any;
```

