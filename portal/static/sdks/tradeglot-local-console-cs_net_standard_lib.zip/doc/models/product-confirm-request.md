
# Product Confirm Request

ProductConfirmRequest.

## Structure

`ProductConfirmRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |
| `EvaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |
| `ProductId` | [`ProductConfirmRequestProductId`](../../doc/models/containers/product-confirm-request-product-id.md) | Required | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

ProductConfirmRequest productConfirmRequest = new ProductConfirmRequest
{
    Description = "description6",
    EvaluationId = "evaluation_id8",
    ProductId = ProductConfirmRequestProductId.FromString("String1"),
};
```

