
# Guide Form Request

One field ({item, value}) or one round of up to three fields ({fields: [...]}), never both.

## Structure

`GuideFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConfirmReview` | `bool?` | Optional | Confirm review.<br><br>**Default**: `false` |
| `Fields` | [`GuideFormRequestFields`](../../doc/models/containers/guide-form-request-fields.md) | Optional | This is a container for any-of cases. |
| `Item` | [`GuideFormRequestItem`](../../doc/models/containers/guide-form-request-item.md) | Optional | This is a container for any-of cases. |
| `Scenario` | [`GuideFormRequestScenario`](../../doc/models/containers/guide-form-request-scenario.md) | Optional | This is a container for any-of cases. |
| `MValue` | [`GuideFormRequestValue`](../../doc/models/containers/guide-form-request-value.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

GuideFormRequest guideFormRequest = new GuideFormRequest
{
    ConfirmReview = false,
    Fields = GuideFormRequestFields.FromListOfGuideField(
        new List<GuideField>
        {
            new GuideField
            {
                Item = "item8",
                MValue = "value8",
            },
        }
    ),
    Item = GuideFormRequestItem.FromString("String1"),
    Scenario = GuideFormRequestScenario.FromScenario1(Scenario1Enum.Preflight),
    MValue = GuideFormRequestValue.FromString("String1"),
};
```

