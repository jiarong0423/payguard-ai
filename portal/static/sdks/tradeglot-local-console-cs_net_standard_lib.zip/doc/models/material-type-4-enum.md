
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |
| `PublicCourtOrderCopy` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MaterialType4Enum materialType4 = MaterialType4Enum.OfficialApiReference;
```

