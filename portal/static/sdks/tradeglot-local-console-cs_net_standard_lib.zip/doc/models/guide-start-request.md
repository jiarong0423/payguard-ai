
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GoodsType` | [`GuideStartRequestGoodsType`](../../doc/models/containers/guide-start-request-goods-type.md) | Optional | This is a container for any-of cases. |
| `Scenario` | [`Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

GuideStartRequest guideStartRequest = new GuideStartRequest
{
    Scenario = Scenario2Enum.Velocity,
    GoodsType = GuideStartRequestGoodsType.FromGoodsType(GoodsTypeEnum.Physical),
};
```

