
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURNTOEDIT` |
| `CANCEL` |
| `ACKNOWLEDGEANDCONTINUE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ChoiceEnum choice = ChoiceEnum.RETURNTOEDIT;
```

