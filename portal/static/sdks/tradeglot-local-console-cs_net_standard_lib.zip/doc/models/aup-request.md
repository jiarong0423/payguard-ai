
# Aup Request

AupRequest.

## Structure

`AupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

AupRequest aupRequest = new AupRequest
{
    Description = "description8",
};
```

