
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `Preflight` |
| `Velocity` |
| `Dispute` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Scenario1Enum scenario1 = Scenario1Enum.Velocity;
```

