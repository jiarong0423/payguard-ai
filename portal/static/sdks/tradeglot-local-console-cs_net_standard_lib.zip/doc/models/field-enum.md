
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `Name` |
| `Address` |
| `Email` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

FieldEnum field = FieldEnum.Address;
```

