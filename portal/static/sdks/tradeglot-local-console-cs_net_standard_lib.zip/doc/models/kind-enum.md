
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDERRECORDCREATED` |
| `DELIVERY` |
| `CLAIMOPENED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

KindEnum kind = KindEnum.DELIVERY;
```

