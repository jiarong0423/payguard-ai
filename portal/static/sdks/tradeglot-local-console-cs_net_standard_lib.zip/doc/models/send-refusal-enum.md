
# Send Refusal Enum

## Enumeration

`SendRefusalEnum`

## Fields

| Name |
|  --- |
| `AccountIdentityUnknown` |
| `DisputeNotThisAccount` |
| `DisputeDetailRequired` |
| `SellerEvidenceAlreadySubmitted` |
| `DisputeNotAwaitingSeller` |
| `DisputeEvidenceNotOffered` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SendRefusalEnum sendRefusal = SendRefusalEnum.AccountIdentityUnknown;
```

