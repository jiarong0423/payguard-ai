
# Paypal Status Response

PaypalStatusResponse.

## Structure

`PaypalStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Configured` | `bool` | Required | Configured. |
| `Environment` | `string` | Required, Constant | Environment.<br><br>**Value**: `"sandbox"` |
| `EvidenceReceipt` | [`PaypalStatusResponseEvidenceReceipt`](../../doc/models/containers/paypal-status-response-evidence-receipt.md) | Required | This is a container for any-of cases. |
| `LastVerifiedAt` | [`PaypalStatusResponseLastVerifiedAt`](../../doc/models/containers/paypal-status-response-last-verified-at.md) | Required | This is a container for any-of cases. |
| `Source` | `string` | Required, Constant | Source.<br><br>**Value**: `"paypal_sandbox"` |
| `Status` | [`Status11Enum`](../../doc/models/status-11-enum.md) | Required | Status. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

PaypalStatusResponse paypalStatusResponse = new PaypalStatusResponse
{
    Configured = false,
    Environment = "sandbox",
    EvidenceReceipt = PaypalStatusResponseEvidenceReceipt.FromSandboxEvidenceReceipt(
        new SandboxEvidenceReceipt
        {
            Action = ActionEnum.OAUTHCONNECT,
            Environment = "sandbox",
            EvidenceClass = EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE,
            ExternalSend = "FROZEN",
            InvoiceId = SandboxEvidenceReceiptInvoiceId.FromString("String5"),
            ObservedAt = "observed_at8",
            PaypalDebugId = SandboxEvidenceReceiptPaypalDebugId.FromString("String5"),
            ProofKind = "POST_RESPONSE_ONLY",
            SchemaVersion = 1,
            SeparateGetReadback = "False",
            Status = Status10Enum.CONNECTED,
        }
    ),
    LastVerifiedAt = PaypalStatusResponseLastVerifiedAt.FromString("String3"),
    Source = "paypal_sandbox",
    Status = Status11Enum.Connected,
};
```

