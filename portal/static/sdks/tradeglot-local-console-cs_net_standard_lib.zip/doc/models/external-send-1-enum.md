
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ExternalSend1Enum externalSend1 = ExternalSend1Enum.FROZEN;
```

