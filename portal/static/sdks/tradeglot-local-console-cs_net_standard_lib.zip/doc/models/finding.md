
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`CategoryEnum`](../../doc/models/category-enum.md) | Required | Category. |
| `Code` | `string` | Required, Constant | Code.<br><br>**Value**: `"keyword_requires_policy_review"` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Finding finding = new Finding
{
    Category = CategoryEnum.UnsupportedFinancialPromise,
    Code = "keyword_requires_policy_review",
};
```

