
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONEMATCH` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Choice2Enum choice2 = Choice2Enum.CONFIRMED;
```

