
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `EnumImagejpeg` |
| `EnumImagegif` |
| `EnumImagepng` |
| `EnumApplicationpdf` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ContentTypeEnum contentType = ContentTypeEnum.EnumImagepng;
```

