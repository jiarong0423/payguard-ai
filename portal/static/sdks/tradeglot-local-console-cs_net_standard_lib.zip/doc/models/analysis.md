
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reason` | [`AnalysisReason`](../../doc/models/containers/analysis-reason.md) | Optional | This is a container for any-of cases. |
| `Status` | [`Status8Enum?`](../../doc/models/status-8-enum.md) | Optional | Status. |
| `Turn` | `int?` | Optional | Turn. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

Analysis analysis = new Analysis
{
    Reason = AnalysisReason.FromReason5(Reason5Enum.InvalidReply),
    Status = Status8Enum.Replaced,
    Turn = 198,
};
```

