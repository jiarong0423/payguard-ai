
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `Sandbox` |
| `Fixture` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DataSourceLabelEnum dataSourceLabel = DataSourceLabelEnum.Sandbox;
```

