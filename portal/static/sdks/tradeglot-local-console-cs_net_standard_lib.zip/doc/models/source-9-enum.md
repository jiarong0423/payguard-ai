
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `Words` |
| `WordsPending` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source9Enum source9 = Source9Enum.Words;
```

