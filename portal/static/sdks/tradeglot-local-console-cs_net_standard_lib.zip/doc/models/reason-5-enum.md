
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `Budget` |
| `ProviderError` |
| `InvalidReply` |
| `Late` |
| `NoItems` |
| `Superseded` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Reason5Enum reason5 = Reason5Enum.InvalidReply;
```

