
# Source 3 Enum

Source.

## Enumeration

`Source3Enum`

## Fields

| Name |
|  --- |
| `REQUESTEDFROMSELLER` |
| `REQUESTEDFROMBUYER` |
| `SUBMITTEDBYSELLER` |
| `SUBMITTEDBYBUYER` |
| `SUBMITTEDBYPARTNER` |
| `UNKNOWN` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source3Enum source3 = Source3Enum.REQUESTEDFROMSELLER;
```

