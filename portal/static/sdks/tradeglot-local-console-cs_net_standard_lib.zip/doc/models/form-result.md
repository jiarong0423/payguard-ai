
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Optional | Item. |
| `Valid` | `bool?` | Optional | Valid. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

FormResult formResult = new FormResult
{
    Item = "item8",
    Valid = false,
};
```

