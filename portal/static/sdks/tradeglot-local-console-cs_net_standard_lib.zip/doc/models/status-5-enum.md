
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `ManualReview` |
| `ReviewEvidence` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status5Enum status5 = Status5Enum.ManualReview;
```

