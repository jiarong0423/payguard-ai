
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |
| `Guide` |
| `StudioAgent` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Stage2Enum stage2 = Stage2Enum.StudioAgent;
```

