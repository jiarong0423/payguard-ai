
# Guide Item

GuideItem.

## Structure

`GuideItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Chunk` | [`GuideItemChunk`](../../doc/models/containers/guide-item-chunk.md) | Required | This is a container for any-of cases. |
| `Form` | [`GuideItemForm`](../../doc/models/containers/guide-item-form.md) | Required | This is a container for any-of cases. |
| `Id` | `string` | Required | Id. |
| `Label` | `string` | Required | Label. |
| `Source` | [`Source8Enum`](../../doc/models/source-8-enum.md) | Required | Source. |
| `Status` | [`Status9Enum`](../../doc/models/status-9-enum.md) | Required | Status. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

GuideItem guideItem = new GuideItem
{
    Chunk = GuideItemChunk.FromString("String7"),
    Form = GuideItemForm.FromGuideForm(
        new GuideForm
        {
            Kind = Kind2Enum.Choice,
            Options = new List<GuideOption>
            {
                new GuideOption
                {
                    Label = "label2",
                    MValue = "value4",
                },
            },
            Placeholder = GuideFormPlaceholder.FromString("String9"),
        }
    ),
    Id = "id0",
    Label = "label0",
    Source = Source8Enum.OFFICIAL,
    Status = Status9Enum.UNCLEAR,
};
```

