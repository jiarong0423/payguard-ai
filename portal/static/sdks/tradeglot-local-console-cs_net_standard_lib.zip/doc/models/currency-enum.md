
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CurrencyEnum currency = CurrencyEnum.USD;
```

