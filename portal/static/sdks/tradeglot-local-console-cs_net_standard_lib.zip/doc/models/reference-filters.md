
# Reference Filters

ReferenceFilters.

## Structure

`ReferenceFilters`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgeBasis` | `string` | Required, Constant | Age basis.<br><br>**Value**: `"source_updated_date_utc_calendar"` |
| `AsOf` | [`ReferenceFiltersAsOf`](../../doc/models/containers/reference-filters-as-of.md) | Required | This is a container for any-of cases. |
| `CaseStage` | [`CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Required | Case stage. |
| `Jurisdiction` | `string` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` |
| `Limit` | `int` | Required | Limit.<br><br>**Constraints**: `>= 1`, `<= 10` |
| `MaterialTypes` | [`List<MaterialType4Enum>`](../../doc/models/material-type-4-enum.md) | Required | Material types.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `3` |
| `MaxSourceAgeDays` | [`ReferenceFiltersMaxSourceAgeDays`](../../doc/models/containers/reference-filters-max-source-age-days.md) | Required | This is a container for any-of cases. |
| `RequireKnownSourceDate` | `bool` | Required | Require known source date. |
| `Theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

ReferenceFilters referenceFilters = new ReferenceFilters
{
    AgeBasis = "source_updated_date_utc_calendar",
    AsOf = ReferenceFiltersAsOf.FromString("String9"),
    CaseStage = CaseStage2Enum.ProceduralOrder,
    Jurisdiction = "US",
    Limit = 10,
    MaterialTypes = new List<MaterialType4Enum>
    {
        MaterialType4Enum.OfficialPolicy,
        MaterialType4Enum.PublicCourtOrderCopy,
    },
    MaxSourceAgeDays = ReferenceFiltersMaxSourceAgeDays.FromNumber(238),
    RequireKnownSourceDate = false,
    Theme = ThemeEnum.DisputeMediation,
};
```

