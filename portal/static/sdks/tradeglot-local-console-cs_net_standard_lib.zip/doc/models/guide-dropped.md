
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Reason` | [`Reason6Enum`](../../doc/models/reason-6-enum.md) | Required | Reason. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideDropped guideDropped = new GuideDropped
{
    Item = "item6",
    Reason = Reason6Enum.OtherParty,
};
```

