
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `Ok` |
| `Error` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

OutcomeEnum outcome = OutcomeEnum.Ok;
```

