
# Claim Type Enum

Claim type.

## Enumeration

`ClaimTypeEnum`

## Fields

| Name |
|  --- |
| `PolicyReference` |
| `CurrentPolicy` |
| `ProceduralReference` |
| `ApiReference` |
| `FinancialAction` |
| `Assurance` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ClaimTypeEnum claimType = ClaimTypeEnum.PolicyReference;
```

