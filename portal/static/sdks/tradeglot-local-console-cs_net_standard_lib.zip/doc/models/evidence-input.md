
# Evidence Input

EvidenceInput.

## Structure

`EvidenceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Evidences` | [`List<EvidenceInputItem>`](../../doc/models/evidence-input-item.md) | Required | Evidences.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `20` |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

EvidenceInput evidenceInput = new EvidenceInput
{
    Evidences = new List<EvidenceInputItem>
    {
        new EvidenceInputItem
        {
            EvidenceInfo = new EvidenceInfo
            {
                TrackingInfo = new List<TrackingInfo>
                {
                    new TrackingInfo
                    {
                        CarrierName = CarrierNameEnum.DHL,
                        TrackingNumber = "tracking_number6",
                        CarrierNameOther = TrackingInfoCarrierNameOther.FromString("String1"),
                    },
                },
            },
            EvidenceType = "evidence_type2",
            Notes = "notes2",
        },
    },
};
```

