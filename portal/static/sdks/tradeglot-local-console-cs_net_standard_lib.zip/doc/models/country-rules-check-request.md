
# Country Rules Check Request

Seller and buyer countries plus closed choices; no free text reaches the check.

## Structure

`CountryRulesCheckRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountOpened` | [`AccountOpenedEnum?`](../../doc/models/account-opened-enum.md) | Optional | Account opened.<br><br>**Default**: `AccountOpenedEnum.unknown` |
| `AccountType` | [`AccountTypeEnum?`](../../doc/models/account-type-enum.md) | Optional | Account type.<br><br>**Default**: `AccountTypeEnum.business` |
| `Amount` | [`CountryRulesCheckRequestAmount`](../../doc/models/containers/country-rules-check-request-amount.md) | Optional | This is a container for any-of cases. |
| `BuyerCountry` | [`BuyerCountryEnum`](../../doc/models/buyer-country-enum.md) | Required | Buyer country. |
| `Checkout` | [`CheckoutEnum?`](../../doc/models/checkout-enum.md) | Optional | Checkout.<br><br>**Default**: `CheckoutEnum.paypal_account` |
| `Currency` | [`CountryRulesCheckRequestCurrency`](../../doc/models/containers/country-rules-check-request-currency.md) | Optional | This is a container for any-of cases. |
| `GoodsTags` | `List<string>` | Optional | Goods tags.<br><br>**Constraints**: *Maximum Items*: `16` |
| `SellerCountry` | [`SellerCountryEnum`](../../doc/models/seller-country-enum.md) | Required | Seller country. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

CountryRulesCheckRequest countryRulesCheckRequest = new CountryRulesCheckRequest
{
    BuyerCountry = BuyerCountryEnum.JP,
    SellerCountry = SellerCountryEnum.US,
    AccountOpened = AccountOpenedEnum.Unknown,
    AccountType = AccountTypeEnum.Business,
    Amount = CountryRulesCheckRequestAmount.FromString("String7"),
    Checkout = CheckoutEnum.PaypalAccount,
    Currency = CountryRulesCheckRequestCurrency.FromString("String5"),
};
```

