
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Valid` | `bool` | Required | Valid. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideFormResult guideFormResult = new GuideFormResult
{
    Item = "item2",
    Valid = false,
};
```

