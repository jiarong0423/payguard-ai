
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATEMESSAGE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ChannelEnum channel = ChannelEnum.EMAIL;
```

