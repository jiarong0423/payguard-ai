
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NothingToSend` |
| `BudgetExhausted` |
| `Timeout` |
| `UpstreamError` |
| `ContractRejected` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ReasonEnum reason = ReasonEnum.ContractRejected;
```

