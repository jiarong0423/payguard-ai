
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `Analysing` |
| `Replaced` |
| `Kept` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status8Enum status8 = Status8Enum.Replaced;
```

