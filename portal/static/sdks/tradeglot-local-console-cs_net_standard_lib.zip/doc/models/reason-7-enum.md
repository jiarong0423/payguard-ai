
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NothingToSend` |
| `NotRecorded` |
| `BudgetExhausted` |
| `Timeout` |
| `UpstreamError` |
| `ContractRejected` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Reason7Enum reason7 = Reason7Enum.NothingToSend;
```

