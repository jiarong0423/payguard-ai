
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NotConfigured` |
| `Disconnected` |
| `Connected` |
| `Error` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status11Enum status11 = Status11Enum.Connected;
```

