
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PREARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DisputeLifeCycleStageEnum disputeLifeCycleStage = DisputeLifeCycleStageEnum.INQUIRY;
```

