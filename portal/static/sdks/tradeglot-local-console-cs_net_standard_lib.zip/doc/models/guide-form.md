
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. |
| `Options` | [`List<GuideOption>`](../../doc/models/guide-option.md) | Required | Options. |
| `Placeholder` | [`GuideFormPlaceholder`](../../doc/models/containers/guide-form-placeholder.md) | Required | This is a container for any-of cases. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

GuideForm guideForm = new GuideForm
{
    Kind = Kind2Enum.Choice,
    Options = new List<GuideOption>
    {
        new GuideOption
        {
            Label = "label2",
            MValue = "value4",
        },
    },
    Placeholder = GuideFormPlaceholder.FromString("String3"),
};
```

