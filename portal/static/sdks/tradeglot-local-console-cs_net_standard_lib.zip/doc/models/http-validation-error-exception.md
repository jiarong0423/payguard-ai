
# HTTP Validation Error Exception

HTTPValidationError.

## Structure

`HTTPValidationErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Detail` | [`List<ValidationError>`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is HTTPValidationErrorException)
    {
        // TODO: Handle HTTPValidationErrorException
        Console.WriteLine(e.Message);
    }
}
```

