
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTSTATEDINREVIEWEDDOCUMENT` |
| `NOTAPPLICABLE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DecisionDateStatusEnum decisionDateStatus = DecisionDateStatusEnum.DOCUMENTSTATED;
```

