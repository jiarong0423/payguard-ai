
# Dispute Routing

DisputeRouting.

## Structure

`DisputeRouting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AvailableActions` | `List<string>` | Required | Available actions.<br><br>**Constraints**: *Maximum Items*: `20` |
| `DisputeLifeCycleStage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `DueState` | [`DueStateEnum`](../../doc/models/due-state-enum.md) | Required | Due state. |
| `HumanReviewRequired` | `string` | Required, Constant | Human review required.<br><br>**Value**: `"True"` |
| `OverallState` | [`OverallStateEnum`](../../doc/models/overall-state-enum.md) | Required | Overall state. |
| `ProviderSubmission` | `string` | Required, Constant | Provider submission.<br><br>**Value**: `"NOT_PERFORMED"` |
| `Reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `Requirements` | [`List<DisputeRequirement>`](../../doc/models/dispute-requirement.md) | Required | Requirements.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `20` |
| `SchemaVersion` | `int` | Required, Constant | Schema version.<br><br>**Value**: `1` |
| `SellerResponseDueDate` | `string` | Required | Seller response due date.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `64` |
| `SnapshotClass` | `string` | Required, Constant | Snapshot class.<br><br>**Value**: `"SYNTHETIC_PROVIDER_FIXTURE"` |
| `Status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

DisputeRouting disputeRouting = new DisputeRouting
{
    AvailableActions = new List<string>
    {
        "available_actions4",
        "available_actions5",
    },
    DisputeLifeCycleStage = DisputeLifeCycleStageEnum.ARBITRATION,
    DueState = DueStateEnum.OPEN,
    HumanReviewRequired = "True",
    OverallState = OverallStateEnum.DUEDATEEXPIRED,
    ProviderSubmission = "NOT_PERFORMED",
    Reason = Reason2Enum.UNAUTHORISED,
    Requirements = new List<DisputeRequirement>
    {
        new DisputeRequirement
        {
            AcceptedAttachmentCount = 20,
            Mandatory = false,
            ProofCount = 60,
            ProviderEvidenceType = "provider_evidence_type0",
            RequestId = "request_id8",
            RequirementState = RequirementStateEnum.CONTEXTONLY,
            Source = "source2",
            Action = DisputeRequirementAction.FromString("String5"),
            EvidenceType = DisputeRequirementEvidenceType.FromString("String3"),
        },
    },
    SchemaVersion = 1,
    SellerResponseDueDate = "seller_response_due_date2",
    SnapshotClass = "SYNTHETIC_PROVIDER_FIXTURE",
    Status = Status3Enum.WAITINGFORSELLERRESPONSE,
};
```

