
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `ReadyForLocalRules` |
| `ManualReview` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

IntakeStatusEnum intakeStatus = IntakeStatusEnum.ReadyForLocalRules;
```

