
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURECOMPATIBLE` |
| `INCOMPLETEEVIDENCE` |
| `REJECTED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

StatusEnum status = StatusEnum.REJECTED;
```

