
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ExternalSendEnum externalSend = ExternalSendEnum.FROZEN;
```

