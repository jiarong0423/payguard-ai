
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `Channel3Live` |
| `Channel3Recorded` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source10Enum source10 = Source10Enum.Channel3Live;
```

