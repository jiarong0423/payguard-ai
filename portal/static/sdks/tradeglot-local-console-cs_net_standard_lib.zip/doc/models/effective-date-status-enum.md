
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `NOTVERIFIED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

EffectiveDateStatusEnum effectiveDateStatus = EffectiveDateStatusEnum.DOCUMENTSTATED;
```

