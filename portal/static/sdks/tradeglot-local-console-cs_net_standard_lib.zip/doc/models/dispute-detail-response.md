
# Dispute Detail Response

DisputeDetailResponse.

## Structure

`DisputeDetailResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreateTime` | `string` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` |
| `DataSourceLabel` | [`DataSourceLabelEnum`](../../doc/models/data-source-label-enum.md) | Required | Data source label. |
| `DisputeAmount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. |
| `DisputeChannel` | [`DisputeDetailResponseDisputeChannel`](../../doc/models/containers/dispute-detail-response-dispute-channel.md) | Optional | This is a container for any-of cases. |
| `DisputeId` | `string` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` |
| `DisputeLifeCycleStage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `DisputeState` | [`DisputeDetailResponseDisputeState`](../../doc/models/containers/dispute-detail-response-dispute-state.md) | Optional | This is a container for any-of cases. |
| `DisputedTransactions` | [`List<DisputedTransaction>`](../../doc/models/disputed-transaction.md) | Required | Disputed transactions.<br><br>**Constraints**: *Maximum Items*: `10` |
| `Environment` | `string` | Required, Constant | Environment.<br><br>**Value**: `"sandbox"` |
| `EvidenceClass` | [`EvidenceClassEnum`](../../doc/models/evidence-class-enum.md) | Required | Evidence class. |
| `Evidences` | [`List<DisputeEvidenceRow>`](../../doc/models/dispute-evidence-row.md) | Required | Evidences.<br><br>**Constraints**: *Maximum Items*: `20` |
| `ObservedAt` | `string` | Required | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `PaypalDebugId` | [`DisputeDetailResponsePaypalDebugId`](../../doc/models/containers/dispute-detail-response-paypal-debug-id.md) | Optional | This is a container for any-of cases. |
| `ProviderSubmission` | [`ProviderSubmissionEnum`](../../doc/models/provider-submission-enum.md) | Required | Provider submission. |
| `Readback` | `string` | Required, Constant | Readback.<br><br>**Value**: `"GET_DETAIL"` |
| `Reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `SellerResponseDueDate` | [`DisputeDetailResponseSellerResponseDueDate`](../../doc/models/containers/dispute-detail-response-seller-response-due-date.md) | Optional | This is a container for any-of cases. |
| `Source` | [`SourceEnum`](../../doc/models/source-enum.md) | Required | Source. |
| `Status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |
| `UpdateTime` | [`DisputeDetailResponseUpdateTime`](../../doc/models/containers/dispute-detail-response-update-time.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

DisputeDetailResponse disputeDetailResponse = new DisputeDetailResponse
{
    CreateTime = "create_time6",
    DataSourceLabel = DataSourceLabelEnum.Sandbox,
    DisputeAmount = new ProviderMoney
    {
        CurrencyCode = "currency_code6",
        MValue = "value0",
    },
    DisputeId = "dispute_id2",
    DisputeLifeCycleStage = DisputeLifeCycleStageEnum.UNKNOWN,
    DisputedTransactions = new List<DisputedTransaction>
    {
        new DisputedTransaction
        {
            SellerTransactionId = "seller_transaction_id2",
            GrossAmount = DisputedTransactionGrossAmount.FromProviderMoney(
                new ProviderMoney
                {
                    CurrencyCode = "currency_code0",
                    MValue = "value6",
                }
            ),
            SellerProtectionEligible = DisputedTransactionSellerProtectionEligible.FromBoolean(true),
            TransactionStatus = DisputedTransactionTransactionStatus.FromString("String7"),
        },
    },
    Environment = "sandbox",
    EvidenceClass = EvidenceClassEnum.SYNTHETICTESTRESPONSE,
    Evidences = new List<DisputeEvidenceRow>
    {
        new DisputeEvidenceRow
        {
            EvidenceType = "evidence_type2",
            Source = Source3Enum.SUBMITTEDBYPARTNER,
            Action = DisputeEvidenceRowAction.FromString("String1"),
            Date = DisputeEvidenceRowDate.FromString("String9"),
        },
    },
    ObservedAt = "observed_at4",
    ProviderSubmission = ProviderSubmissionEnum.NOTPERFORMED,
    Readback = "GET_DETAIL",
    Reason = Reason2Enum.MERCHANDISEORSERVICENOTRECEIVED,
    Source = SourceEnum.PaypalSandbox,
    Status = Status3Enum.CLOSED,
    DisputeChannel = DisputeDetailResponseDisputeChannel.FromString("String5"),
    DisputeState = DisputeDetailResponseDisputeState.FromString("String9"),
    PaypalDebugId = DisputeDetailResponsePaypalDebugId.FromString("String1"),
    SellerResponseDueDate = DisputeDetailResponseSellerResponseDueDate.FromString("String9"),
    UpdateTime = DisputeDetailResponseUpdateTime.FromString("String9"),
};
```

