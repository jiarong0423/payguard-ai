
# Guide Review Row

GuideReviewRow.

## Structure

`GuideReviewRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `string` | Required | Item. |
| `Source` | [`Source9Enum`](../../doc/models/source-9-enum.md) | Required | Source. |
| `MValue` | `string` | Required | Value.<br><br>**Constraints**: *Maximum Length*: `120` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideReviewRow guideReviewRow = new GuideReviewRow
{
    Item = "item6",
    Source = Source9Enum.Words,
    MValue = "value6",
};
```

