
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `Preflight` |
| `Velocity` |
| `Dispute` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Scenario2Enum scenario2 = Scenario2Enum.Velocity;
```

