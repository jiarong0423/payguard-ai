
# Dispute Summary

DisputeSummary.

## Structure

`DisputeSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CaseRef` | `string` | Required | Case ref. |
| `DisputeAmount` | [`SyntheticMoney`](../../doc/models/synthetic-money.md) | Required | Same shape as the PayPal Disputes `dispute_amount` (ProviderMoney below); values are synthetic. |
| `OpenedAt` | `string` | Required | Opened at. |
| `OrderRef` | `string` | Required | Order ref. |
| `Reason` | `string` | Required | Reason. |
| `SellerResponseDueDate` | `string` | Required | Seller response due date. |
| `Status` | [`Status7Enum`](../../doc/models/status-7-enum.md) | Required | Status. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DisputeSummary disputeSummary = new DisputeSummary
{
    CaseRef = "case_ref6",
    DisputeAmount = new SyntheticMoney
    {
        CurrencyCode = "currency_code6",
        MValue = "value0",
    },
    OpenedAt = "opened_at0",
    OrderRef = "order_ref8",
    Reason = "reason8",
    SellerResponseDueDate = "seller_response_due_date0",
    Status = Status7Enum.NeedsReview,
};
```

