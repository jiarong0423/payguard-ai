
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AffectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `"False"` |
| `Reason` | [`AupCategorySignalResponseReason`](../../doc/models/containers/aup-category-signal-response-reason.md) | Required | This is a container for any-of cases. |
| `Signal` | [`AupCategorySignalResponseSignal`](../../doc/models/containers/aup-category-signal-response-signal.md) | Required | This is a container for any-of cases. |
| `Status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Required | Status. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

AupCategorySignalResponse aupCategorySignalResponse = new AupCategorySignalResponse
{
    AffectsDecision = "False",
    Reason = AupCategorySignalResponseReason.FromReason(ReasonEnum.BudgetExhausted),
    Signal = AupCategorySignalResponseSignal.FromCategorySignal(
        new CategorySignal
        {
            Category = CategorySignalCategory.FromString("String9"),
            Confidence = CategorySignalConfidence.FromConfidence(ConfidenceEnum.HIGH),
            Source = "channel3",
        }
    ),
    Status = Status2Enum.NOTSENT,
};
```

