
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DirectionEnum direction = DirectionEnum.INBOUND;
```

