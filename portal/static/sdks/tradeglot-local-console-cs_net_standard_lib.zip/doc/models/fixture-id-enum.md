
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `Payguardfixedsyntheticbriefv1` |
| `Payguardsessionbriefv1` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

FixtureIdEnum fixtureId = FixtureIdEnum.Payguardfixedsyntheticbriefv1;
```

