
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MaterialTypeEnum materialType = MaterialTypeEnum.OfficialApiReference;
```

