
# Guide Subtraction

GuideSubtraction.

## Structure

`GuideSubtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Left` | `int` | Required | Left. |
| `Needed` | `int` | Required | Needed. |
| `Taken` | `int` | Required | Taken. |
| `Text` | `string` | Required | Text. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideSubtraction guideSubtraction = new GuideSubtraction
{
    Left = 18,
    Needed = 112,
    Taken = 124,
    Text = "text8",
};
```

