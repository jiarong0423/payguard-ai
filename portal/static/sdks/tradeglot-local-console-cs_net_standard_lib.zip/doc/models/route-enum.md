
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `Physical` |
| `Digital` |
| `Service` |
| `Unknown` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

RouteEnum route = RouteEnum.Physical;
```

