
# Guide Field Result

GuideFieldResult.

## Structure

`GuideFieldResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Deferred` | `bool` | Required | Deferred. |
| `Item` | `string` | Required | Item. |
| `Valid` | `bool` | Required | Valid. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideFieldResult guideFieldResult = new GuideFieldResult
{
    Deferred = false,
    Item = "item8",
    Valid = false,
};
```

