
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CaseRef` | [`AiBriefHttpRequestCaseRef`](../../doc/models/containers/ai-brief-http-request-case-ref.md) | Optional | This is a container for any-of cases. |
| `Stage` | [`StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

AiBriefHttpRequest aiBriefHttpRequest = new AiBriefHttpRequest
{
    Stage = StageEnum.VelocityGuard,
    CaseRef = AiBriefHttpRequestCaseRef.FromString("String9"),
};
```

