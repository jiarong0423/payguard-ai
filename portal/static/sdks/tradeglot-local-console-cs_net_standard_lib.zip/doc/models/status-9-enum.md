
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLYPRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOTAPPLICABLE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status9Enum status9 = Status9Enum.STRUCTURALLYPRESENT;
```

