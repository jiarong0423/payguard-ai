
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OtherParty` |
| `Inferred` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Reason6Enum reason6 = Reason6Enum.OtherParty;
```

