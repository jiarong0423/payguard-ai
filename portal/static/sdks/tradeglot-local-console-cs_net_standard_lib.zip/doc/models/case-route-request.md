
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CaseRouteRequest caseRouteRequest = new CaseRouteRequest
{
    Text = "text6",
};
```

