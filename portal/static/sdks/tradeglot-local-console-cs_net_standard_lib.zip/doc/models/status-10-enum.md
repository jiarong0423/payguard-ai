
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status10Enum status10 = Status10Enum.CONNECTED;
```

