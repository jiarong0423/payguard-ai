
# Dispute Evidence Row

DisputeEvidenceRow.

## Structure

`DisputeEvidenceRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`DisputeEvidenceRowAction`](../../doc/models/containers/dispute-evidence-row-action.md) | Optional | This is a container for any-of cases. |
| `Date` | [`DisputeEvidenceRowDate`](../../doc/models/containers/dispute-evidence-row-date.md) | Optional | This is a container for any-of cases. |
| `EvidenceType` | `string` | Required | Evidence type.<br><br>**Constraints**: *Pattern*: `^[A-Z][A-Z0-9_]{0,63}$` |
| `Source` | [`Source3Enum`](../../doc/models/source-3-enum.md) | Required | Source. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

DisputeEvidenceRow disputeEvidenceRow = new DisputeEvidenceRow
{
    EvidenceType = "evidence_type8",
    Source = Source3Enum.REQUESTEDFROMSELLER,
    Action = DisputeEvidenceRowAction.FromString("String7"),
    Date = DisputeEvidenceRowDate.FromString("String3"),
};
```

