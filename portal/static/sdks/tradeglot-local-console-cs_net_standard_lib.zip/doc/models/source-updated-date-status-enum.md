
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENTSTATED` |
| `MISSING` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SourceUpdatedDateStatusEnum sourceUpdatedDateStatus = SourceUpdatedDateStatusEnum.DOCUMENTSTATED;
```

