
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Label` | `string` | Required | Label. |
| `MValue` | `string` | Required | Value. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GuideOption guideOption = new GuideOption
{
    Label = "label2",
    MValue = "value4",
};
```

