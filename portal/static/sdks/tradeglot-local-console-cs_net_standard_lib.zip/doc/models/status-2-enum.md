
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status2Enum status2 = Status2Enum.NOTSENT;
```

