
# Multipart File Part

MultipartFilePart.

## Structure

`MultipartFilePart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ByteLength` | `int` | Required | Byte length.<br><br>**Constraints**: `>= 0`, `<= 9999999` |
| `ContentType` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Required | Content type. |
| `Filename` | `string` | Required | Filename.<br><br>**Constraints**: *Maximum Length*: `255` |
| `Name` | `string` | Required | Name.<br><br>**Constraints**: *Pattern*: `^file[0-9]{1,3}$` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MultipartFilePart multipartFilePart = new MultipartFilePart
{
    ByteLength = 138,
    ContentType = ContentTypeEnum.EnumImagejpeg,
    Filename = "filename0",
    Name = "name8",
};
```

