
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICBASELINE` |
| `CALLERSUPPLIEDUNVERIFIED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

BaselineProvenanceEnum baselineProvenance = BaselineProvenanceEnum.SYNTHETICBASELINE;
```

