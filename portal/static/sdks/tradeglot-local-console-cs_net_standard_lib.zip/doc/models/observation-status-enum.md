
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `WITHINOBSERVATIONBUDGET` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ObservationStatusEnum observationStatus = ObservationStatusEnum.FUTUREOBSERVATION;
```

