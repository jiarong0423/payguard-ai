
# Evidence

Evidence.

## Structure

`Evidence`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CarrierStatus` | [`EvidenceCarrierStatus`](../../doc/models/containers/evidence-carrier-status.md) | Optional | This is a container for any-of cases. |
| `DeliveredAt` | [`EvidenceDeliveredAt`](../../doc/models/containers/evidence-delivered-at.md) | Optional | This is a container for any-of cases. |
| `EvidenceSource` | `string` | Required, Constant | Evidence source.<br><br>**Value**: `"synthetic"` |
| `OpenedAt` | [`EvidenceOpenedAt`](../../doc/models/containers/evidence-opened-at.md) | Optional | This is a container for any-of cases. |
| `OrderCreatedAt` | [`EvidenceOrderCreatedAt`](../../doc/models/containers/evidence-order-created-at.md) | Optional | This is a container for any-of cases. |
| `Reason` | [`EvidenceReason`](../../doc/models/containers/evidence-reason.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

Evidence evidence = new Evidence
{
    EvidenceSource = "synthetic",
    CarrierStatus = EvidenceCarrierStatus.FromString("String5"),
    DeliveredAt = EvidenceDeliveredAt.FromString("String1"),
    OpenedAt = EvidenceOpenedAt.FromString("String1"),
    OrderCreatedAt = EvidenceOrderCreatedAt.FromString("String3"),
    Reason = EvidenceReason.FromString("String3"),
};
```

