
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOTFOUND` |
| `NOTSENT` |
| `UNAVAILABLE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status12Enum status12 = Status12Enum.NOTSENT;
```

