
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CarrierNameEnum carrierName = CarrierNameEnum.JPJAPANPOST;
```

