
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ConfidenceEnum confidence = ConfidenceEnum.HIGH;
```

