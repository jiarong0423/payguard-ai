
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`CategorySignalCategory`](../../doc/models/containers/category-signal-category.md) | Required | This is a container for any-of cases. |
| `Confidence` | [`CategorySignalConfidence`](../../doc/models/containers/category-signal-confidence.md) | Required | This is a container for any-of cases. |
| `Source` | `string` | Required, Constant | Source.<br><br>**Value**: `"channel3"` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

CategorySignal categorySignal = new CategorySignal
{
    Category = CategorySignalCategory.FromString("String1"),
    Confidence = CategorySignalConfidence.FromConfidence(ConfidenceEnum.HIGH),
    Source = "channel3",
};
```

