
# Reason 1 Enum

Reason.

## Enumeration

`Reason1Enum`

## Fields

| Name |
|  --- |
| `CatalogueMatch` |
| `LiveCatalogueMatch` |
| `DigitalWord` |
| `ServiceWord` |
| `FilteredConflict` |
| `NoCloseMatch` |
| `NothingToMatch` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Reason1Enum reason1 = Reason1Enum.DigitalWord;
```

