
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POSTRESPONSEONLY` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ProofKindEnum proofKind = ProofKindEnum.POSTRESPONSEONLY;
```

