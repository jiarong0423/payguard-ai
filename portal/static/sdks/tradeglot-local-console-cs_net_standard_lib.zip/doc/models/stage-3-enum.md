
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `Funnel` |
| `Echo` |
| `Fill` |
| `Review` |
| `Done` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Stage3Enum stage3 = Stage3Enum.Done;
```

