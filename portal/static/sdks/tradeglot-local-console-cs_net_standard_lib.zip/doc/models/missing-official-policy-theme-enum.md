
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MissingOfficialPolicyThemeEnum missingOfficialPolicyTheme = MissingOfficialPolicyThemeEnum.SourceCompliance;
```

