
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `ProceduralOrder` |
| `NotApplicable` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CaseStageEnum caseStage = CaseStageEnum.ProceduralOrder;
```

