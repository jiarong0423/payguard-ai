
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

EvidenceClass3Enum evidenceClass3 = EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE;
```

