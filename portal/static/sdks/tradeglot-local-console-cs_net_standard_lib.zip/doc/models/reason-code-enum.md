
# Reason Code Enum

## Enumeration

`ReasonCodeEnum`

## Fields

| Name |
|  --- |
| `ACTIONCLAIMFORBIDDEN` |
| `ASSURANCECLAIMFORBIDDEN` |
| `CITATIONUNKNOWN` |
| `CITATIONREGIONMISMATCH` |
| `CITATIONTHEMEMISMATCH` |
| `CLAIMREFERENCETYPEMISMATCH` |
| `FUTUREOBSERVATION` |
| `STALEOBSERVATION` |
| `DOCUMENTUPDATEINFUTURE` |
| `CURRENTPOLICYNOTESTABLISHED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ReasonCodeEnum reasonCode = ReasonCodeEnum.FUTUREOBSERVATION;
```

