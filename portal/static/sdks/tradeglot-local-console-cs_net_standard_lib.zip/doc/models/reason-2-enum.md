
# Reason 2 Enum

Reason.

## Enumeration

`Reason2Enum`

## Fields

| Name |
|  --- |
| `MERCHANDISEORSERVICENOTRECEIVED` |
| `MERCHANDISEORSERVICENOTASDESCRIBED` |
| `UNAUTHORISED` |
| `CREDITNOTPROCESSED` |
| `DUPLICATETRANSACTION` |
| `INCORRECTAMOUNT` |
| `PAYMENTBYOTHERMEANS` |
| `CANCELEDRECURRINGBILLING` |
| `OTHER` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Reason2Enum reason2 = Reason2Enum.CANCELEDRECURRINGBILLING;
```

