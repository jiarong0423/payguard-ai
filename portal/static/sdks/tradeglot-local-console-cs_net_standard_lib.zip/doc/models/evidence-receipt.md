
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Action` | [`ActionEnum?`](../../doc/models/action-enum.md) | Optional | Action. |
| `Environment` | [`EnvironmentEnum?`](../../doc/models/environment-enum.md) | Optional | Environment. |
| `EvidenceClass` | [`EvidenceClass3Enum?`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. |
| `ExternalSend` | [`ExternalSend1Enum?`](../../doc/models/external-send-1-enum.md) | Optional | External send. |
| `InvoiceId` | [`EvidenceReceiptInvoiceId`](../../doc/models/containers/evidence-receipt-invoice-id.md) | Optional | This is a container for any-of cases. |
| `ObservedAt` | `string` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `PaypalDebugId` | [`EvidenceReceiptPaypalDebugId`](../../doc/models/containers/evidence-receipt-paypal-debug-id.md) | Optional | This is a container for any-of cases. |
| `ProofKind` | [`ProofKindEnum?`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. |
| `SchemaVersion` | [`SchemaVersion1Enum?`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. |
| `SeparateGetReadback` | `bool?` | Optional | Separate get readback. |
| `Status` | [`Status10Enum?`](../../doc/models/status-10-enum.md) | Optional | Status. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

EvidenceReceipt evidenceReceipt = new EvidenceReceipt
{
    Action = ActionEnum.OAUTHCONNECT,
    Environment = EnvironmentEnum.Sandbox,
    EvidenceClass = EvidenceClass3Enum.AUTHENTICSANDBOXRESPONSE,
    ExternalSend = ExternalSend1Enum.FROZEN,
    InvoiceId = EvidenceReceiptInvoiceId.FromString("String1"),
};
```

