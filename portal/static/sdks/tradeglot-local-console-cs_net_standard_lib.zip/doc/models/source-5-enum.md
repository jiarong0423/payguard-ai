
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source5Enum source5 = Source5Enum.PROVIDER;
```

