
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `Channel3Live` |
| `Channel3Recorded` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source11Enum source11 = Source11Enum.Channel3Live;
```

