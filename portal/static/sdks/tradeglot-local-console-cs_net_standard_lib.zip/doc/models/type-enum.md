
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Email` |
| `UsPhone` |
| `IdLike` |
| `Name` |
| `Address` |
| `Manual` |
| `Mixed` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

TypeEnum type = TypeEnum.Manual;
```

