
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `Burst` |
| `Dispute` |
| `Reset` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Scenario5Enum scenario5 = Scenario5Enum.Dispute;
```

