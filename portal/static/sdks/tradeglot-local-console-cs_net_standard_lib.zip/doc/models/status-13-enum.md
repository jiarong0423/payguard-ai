
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `ReferencesFound` |
| `EvidenceMissing` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status13Enum status13 = Status13Enum.ReferencesFound;
```

