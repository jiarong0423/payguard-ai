
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SellerCountryEnum sellerCountry = SellerCountryEnum.AU;
```

