
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOTMADE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

JudgementEnum judgement = JudgementEnum.NOTMADE;
```

