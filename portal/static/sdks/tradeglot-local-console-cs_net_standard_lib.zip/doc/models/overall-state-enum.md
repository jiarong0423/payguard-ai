
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASENOTACTIONABLE` |
| `MANUALREVIEW` |
| `DUEDATEEXPIRED` |
| `ACTIONNOTAVAILABLE` |
| `NEEDSINPUT` |
| `READYFORLOCALREVIEW` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

OverallStateEnum overallState = OverallStateEnum.DUEDATEEXPIRED;
```

