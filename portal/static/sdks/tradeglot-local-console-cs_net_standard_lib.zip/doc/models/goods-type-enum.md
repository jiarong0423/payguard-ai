
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `Physical` |
| `Digital` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

GoodsTypeEnum goodsType = GoodsTypeEnum.Physical;
```

