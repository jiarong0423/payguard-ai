
# Webhook Event Projection

All that is kept after a SUCCESS: identifiers and status only, no amounts, payer data, links or summary.

## Structure

`WebhookEventProjection`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EventType` | [`WebhookEventProjectionEventType`](../../doc/models/containers/webhook-event-projection-event-type.md) | Required | This is a container for any-of cases. |
| `Id` | [`WebhookEventProjectionId`](../../doc/models/containers/webhook-event-projection-id.md) | Required | This is a container for any-of cases. |
| `ResourceId` | [`WebhookEventProjectionResourceId`](../../doc/models/containers/webhook-event-projection-resource-id.md) | Required | This is a container for any-of cases. |
| `ResourceStatus` | [`WebhookEventProjectionResourceStatus`](../../doc/models/containers/webhook-event-projection-resource-status.md) | Required | This is a container for any-of cases. |
| `ResourceType` | [`WebhookEventProjectionResourceType`](../../doc/models/containers/webhook-event-projection-resource-type.md) | Required | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

WebhookEventProjection webhookEventProjection = new WebhookEventProjection
{
    EventType = WebhookEventProjectionEventType.FromString("String9"),
    Id = WebhookEventProjectionId.FromString("String9"),
    ResourceId = WebhookEventProjectionResourceId.FromString("String5"),
    ResourceStatus = WebhookEventProjectionResourceStatus.FromString("String1"),
    ResourceType = WebhookEventProjectionResourceType.FromString("String3"),
};
```

