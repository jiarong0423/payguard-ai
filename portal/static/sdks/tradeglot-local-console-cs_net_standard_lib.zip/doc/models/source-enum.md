
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PaypalSandbox` |
| `SyntheticFixture` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SourceEnum source = SourceEnum.PaypalSandbox;
```

