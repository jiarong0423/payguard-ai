
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Keyword` |
| `Model` |
| `KeywordFallback` |
| `Form` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ChooserEnum chooser = ChooserEnum.Form;
```

