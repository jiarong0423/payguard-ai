
# Material Type 1 Enum

Material type.

## Enumeration

`MaterialType1Enum`

## Fields

| Name |
|  --- |
| `OfficialApiReference` |
| `OfficialPolicy` |
| `PublicCourtOrderCopy` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MaterialType1Enum materialType1 = MaterialType1Enum.OfficialPolicy;
```

