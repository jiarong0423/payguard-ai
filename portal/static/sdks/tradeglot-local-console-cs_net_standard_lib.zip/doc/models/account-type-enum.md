
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `Personal` |
| `Business` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

AccountTypeEnum accountType = AccountTypeEnum.Personal;
```

