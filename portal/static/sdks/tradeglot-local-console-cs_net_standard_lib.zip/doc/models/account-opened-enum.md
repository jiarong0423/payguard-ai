
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `Unknown` |
| `BeforeCutoff` |
| `AfterCutoff` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

AccountOpenedEnum accountOpened = AccountOpenedEnum.AfterCutoff;
```

