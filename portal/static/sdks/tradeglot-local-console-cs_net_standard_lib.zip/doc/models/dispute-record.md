
# Dispute Record

DisputeRecord.

## Structure

`DisputeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreateTime` | `string` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` |
| `DisputeAmount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. |
| `DisputeId` | `string` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` |
| `DisputeLifeCycleStage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `DisputeState` | [`DisputeRecordDisputeState`](../../doc/models/containers/dispute-record-dispute-state.md) | Optional | This is a container for any-of cases. |
| `Reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `SellerResponseDueDate` | [`DisputeRecordSellerResponseDueDate`](../../doc/models/containers/dispute-record-seller-response-due-date.md) | Optional | This is a container for any-of cases. |
| `Status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |
| `UpdateTime` | [`DisputeRecordUpdateTime`](../../doc/models/containers/dispute-record-update-time.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

DisputeRecord disputeRecord = new DisputeRecord
{
    CreateTime = "create_time0",
    DisputeAmount = new ProviderMoney
    {
        CurrencyCode = "currency_code6",
        MValue = "value0",
    },
    DisputeId = "dispute_id6",
    DisputeLifeCycleStage = DisputeLifeCycleStageEnum.ARBITRATION,
    Reason = Reason2Enum.MERCHANDISEORSERVICENOTRECEIVED,
    Status = Status3Enum.OPEN,
    DisputeState = DisputeRecordDisputeState.FromString("String7"),
    SellerResponseDueDate = DisputeRecordSellerResponseDueDate.FromString("String3"),
    UpdateTime = DisputeRecordUpdateTime.FromString("String7"),
};
```

