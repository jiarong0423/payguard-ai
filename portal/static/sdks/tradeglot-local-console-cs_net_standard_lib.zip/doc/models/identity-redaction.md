
# Identity Redaction

IdentityRedaction.

## Structure

`IdentityRedaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Fields` | [`List<FieldEnum>`](../../doc/models/field-enum.md) | Required | Fields. |
| `Method` | `string` | Required, Constant | Method.<br><br>**Value**: `"HMAC-SHA256 pseudonymization"` |
| `Synthetic` | `string` | Required, Constant | Synthetic.<br><br>**Value**: `"True"` |
| `Tokens` | [`IdentityTokens`](../../doc/models/identity-tokens.md) | Required | IdentityTokens. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;

IdentityRedaction identityRedaction = new IdentityRedaction
{
    Fields = new List<FieldEnum>
    {
        FieldEnum.Name,
        FieldEnum.Address,
    },
    Method = "HMAC-SHA256 pseudonymization",
    Synthetic = "True",
    Tokens = new IdentityTokens
    {
        AddressToken = "address_token0",
        EmailToken = "email_token2",
        NameToken = "name_token0",
    },
};
```

