
# Time Event

TimeEvent.

## Structure

`TimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `string` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `Kind` | [`KindEnum`](../../doc/models/kind-enum.md) | Required | Kind. |
| `Source` | [`Source5Enum`](../../doc/models/source-5-enum.md) | Required | Source. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

TimeEvent timeEvent = new TimeEvent
{
    At = "at6",
    Kind = KindEnum.DELIVERY,
    Source = Source5Enum.PROVIDER,
};
```

