
# Guide Reply

GuideReply.

## Structure

`GuideReply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Chooser` | [`ChooserEnum`](../../doc/models/chooser-enum.md) | Required | Chooser. |
| `Dropped` | [`List<GuideDropped>`](../../doc/models/guide-dropped.md) | Required | Dropped. |
| `FallbackReason` | [`GuideReplyFallbackReason`](../../doc/models/containers/guide-reply-fallback-reason.md) | Required | This is a container for any-of cases. |
| `StateChanged` | `bool` | Required | State changed. |
| `Template` | [`TemplateEnum`](../../doc/models/template-enum.md) | Required | Template. |
| `Text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

GuideReply guideReply = new GuideReply
{
    Chooser = ChooserEnum.None,
    Dropped = new List<GuideDropped>
    {
        new GuideDropped
        {
            Item = "item2",
            Reason = Reason6Enum.OtherParty,
        },
    },
    FallbackReason = GuideReplyFallbackReason.FromFallbackReason(FallbackReasonEnum.Late),
    StateChanged = false,
    Template = TemplateEnum.NOGUARANTEE,
    Text = "text6",
};
```

