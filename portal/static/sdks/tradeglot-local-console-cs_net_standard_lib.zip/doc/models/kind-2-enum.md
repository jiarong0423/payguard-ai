
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `Date` |
| `Choice` |
| `Text` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Kind2Enum kind2 = Kind2Enum.Choice;
```

