
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Category` | [`SignalCategory`](../../doc/models/containers/signal-category.md) | Optional | This is a container for any-of cases. |
| `Confidence` | [`SignalConfidence`](../../doc/models/containers/signal-confidence.md) | Optional | This is a container for any-of cases. |
| `Source` | [`Source2Enum?`](../../doc/models/source-2-enum.md) | Optional | Source. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

Signal signal = new Signal
{
    Category = SignalCategory.FromString("String1"),
    Confidence = SignalConfidence.FromConfidence(ConfidenceEnum.HIGH),
    Source = Source2Enum.Channel3,
};
```

