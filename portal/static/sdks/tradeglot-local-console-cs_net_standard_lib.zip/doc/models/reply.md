
# Reply

Reply.

## Structure

`Reply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Chooser` | [`ChooserEnum?`](../../doc/models/chooser-enum.md) | Optional | Chooser. |
| `Dropped` | [`List<GuideDropped>`](../../doc/models/guide-dropped.md) | Optional | Dropped. |
| `FallbackReason` | [`ReplyFallbackReason`](../../doc/models/containers/reply-fallback-reason.md) | Optional | This is a container for any-of cases. |
| `StateChanged` | `bool?` | Optional | State changed. |
| `Template` | [`TemplateEnum?`](../../doc/models/template-enum.md) | Optional | Template. |
| `Text` | `string` | Optional | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

Reply reply = new Reply
{
    Chooser = ChooserEnum.Keyword,
    Dropped = new List<GuideDropped>
    {
        new GuideDropped
        {
            Item = "item2",
            Reason = Reason6Enum.OtherParty,
        },
        new GuideDropped
        {
            Item = "item2",
            Reason = Reason6Enum.OtherParty,
        },
    },
    FallbackReason = ReplyFallbackReason.FromFallbackReason(FallbackReasonEnum.ProviderError),
    StateChanged = false,
    Template = TemplateEnum.SUBTRACTION,
};
```

