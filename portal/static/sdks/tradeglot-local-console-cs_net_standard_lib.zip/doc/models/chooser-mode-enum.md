
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `Keyword` |
| `Gemini` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ChooserModeEnum chooserMode = ChooserModeEnum.Keyword;
```

