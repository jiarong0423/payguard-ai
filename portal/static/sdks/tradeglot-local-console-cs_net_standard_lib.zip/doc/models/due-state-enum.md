
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

DueStateEnum dueState = DueStateEnum.OPEN;
```

