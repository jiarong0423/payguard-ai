
# Case Outcome Enum

## Enumeration

`CaseOutcomeEnum`

## Fields

| Name |
|  --- |
| `SETTLEMENTAPPROVALNOTFINALMERITS` |
| `ARBITRATIONCOMPELLEDUNDERLYINGMERITSNOTDECIDED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CaseOutcomeEnum caseOutcome = CaseOutcomeEnum.SETTLEMENTAPPROVALNOTFINALMERITS;
```

