
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITINGFORSELLERRESPONSE` |
| `WAITINGFORBUYERRESPONSE` |
| `UNDERREVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status3Enum status3 = Status3Enum.OPEN;
```

