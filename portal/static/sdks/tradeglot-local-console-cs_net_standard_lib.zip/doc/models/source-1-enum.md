
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SessionMemory` |
| `HostedDemo` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source1Enum source1 = Source1Enum.SessionMemory;
```

