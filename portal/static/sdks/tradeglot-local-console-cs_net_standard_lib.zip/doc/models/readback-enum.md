
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADDTRACKINGPREVIEW` |
| `ADDTRACKINGSUBMITTED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ReadbackEnum readback = ReadbackEnum.ADDTRACKINGPREVIEW;
```

