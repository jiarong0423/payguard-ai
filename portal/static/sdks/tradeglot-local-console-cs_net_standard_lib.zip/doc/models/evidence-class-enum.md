
# Evidence Class Enum

Evidence class.

## Enumeration

`EvidenceClassEnum`

## Fields

| Name |
|  --- |
| `AUTHENTICSANDBOXRESPONSE` |
| `SYNTHETICTESTRESPONSE` |
| `SYNTHETICFIXTURE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

EvidenceClassEnum evidenceClass = EvidenceClassEnum.SYNTHETICFIXTURE;
```

