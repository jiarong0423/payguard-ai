
# Readback 1 Enum

Readback.

## Enumeration

`Readback1Enum`

## Fields

| Name |
|  --- |
| `PROVIDEEVIDENCEPREVIEW` |
| `PROVIDEEVIDENCESUBMITTED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Readback1Enum readback1 = Readback1Enum.PROVIDEEVIDENCEPREVIEW;
```

