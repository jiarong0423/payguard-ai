
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `EnumPayguardtimeEvidencev1` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SchemaVersionEnum schemaVersion = SchemaVersionEnum.EnumPayguardtimeEvidencev1;
```

