
# Requirement State Enum

Requirement state.

## Enumeration

`RequirementStateEnum`

## Fields

| Name |
|  --- |
| `CONTEXTONLY` |
| `UNMAPPEDEVIDENCETYPE` |
| `PROVIDERREQUESTOUTSIDELOCALMATRIX` |
| `STRUCTURALLYPRESENT` |
| `MANDATORYEVIDENCEMISSING` |
| `OPTIONALEVIDENCEMISSING` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

RequirementStateEnum requirementState = RequirementStateEnum.MANDATORYEVIDENCEMISSING;
```

