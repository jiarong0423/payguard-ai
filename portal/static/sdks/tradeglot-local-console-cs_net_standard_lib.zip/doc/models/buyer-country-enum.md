
# Buyer Country Enum

Buyer country.

## Enumeration

`BuyerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

BuyerCountryEnum buyerCountry = BuyerCountryEnum.US;
```

