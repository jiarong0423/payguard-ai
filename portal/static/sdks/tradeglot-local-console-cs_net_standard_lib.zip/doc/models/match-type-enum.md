
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `Exact` |
| `Close` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MatchTypeEnum matchType = MatchTypeEnum.Exact;
```

