
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETICTESTRESPONSE` |
| `OPERATORLIVERESPONSE` |
| `LOCALRUNTIMERESPONSE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ExecutionEvidenceEnum executionEvidence = ExecutionEvidenceEnum.OPERATORLIVERESPONSE;
```

