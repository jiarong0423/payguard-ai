
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTHCONNECT` |
| `CREATEINVOICEDRAFT` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ActionEnum action = ActionEnum.OAUTHCONNECT;
```

