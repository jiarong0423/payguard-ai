
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Scenario` | [`Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

InjectRequest injectRequest = new InjectRequest
{
    Scenario = Scenario5Enum.Burst,
};
```

