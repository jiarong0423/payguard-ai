
# Reference Request

ReferenceRequest.

## Structure

`ReferenceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AsOf` | [`ReferenceRequestAsOf`](../../doc/models/containers/reference-request-as-of.md) | Optional | This is a container for any-of cases. |
| `CaseStage` | [`CaseStage2Enum?`](../../doc/models/case-stage-2-enum.md) | Optional | Case stage.<br><br>**Default**: `CaseStage2Enum.any` |
| `Jurisdiction` | `string` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` |
| `Limit` | `int?` | Optional | Limit.<br><br>**Default**: `3`<br><br>**Constraints**: `>= 1`, `<= 10` |
| `MaterialTypes` | [`ReferenceRequestMaterialTypes`](../../doc/models/containers/reference-request-material-types.md) | Optional | This is a container for any-of cases. |
| `MaxSourceAgeDays` | [`ReferenceRequestMaxSourceAgeDays`](../../doc/models/containers/reference-request-max-source-age-days.md) | Optional | This is a container for any-of cases. |
| `Query` | `string` | Required | Query.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `512` |
| `RequireKnownSourceDate` | `bool?` | Optional | Require known source date.<br><br>**Default**: `false` |
| `Theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

ReferenceRequest referenceRequest = new ReferenceRequest
{
    Jurisdiction = "US",
    Query = "query4",
    Theme = ThemeEnum.DisputeMediation,
    AsOf = ReferenceRequestAsOf.FromString("String7"),
    CaseStage = CaseStage2Enum.Any,
    Limit = 3,
    MaterialTypes = ReferenceRequestMaterialTypes.FromListOfMaterialType4(
        new List<MaterialType4Enum>
        {
            MaterialType4Enum.PublicCourtOrderCopy,
        }
    ),
    MaxSourceAgeDays = ReferenceRequestMaxSourceAgeDays.FromNumber(110),
    RequireKnownSourceDate = false,
};
```

