
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `Local` |
| `HostedDemo` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ModeEnum mode = ModeEnum.Local;
```

