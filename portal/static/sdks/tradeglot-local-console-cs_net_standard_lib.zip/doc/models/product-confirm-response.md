
# Product Confirm Response

The seller's own choice: one of the cards they were shown, or none of them.

## Structure

`ProductConfirmResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AffectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `"False"` |
| `Card` | [`ProductConfirmResponseCard`](../../doc/models/containers/product-confirm-response-card.md) | Required | This is a container for any-of cases. |
| `CardDigest` | [`ProductConfirmResponseCardDigest`](../../doc/models/containers/product-confirm-response-card-digest.md) | Required | This is a container for any-of cases. |
| `Choice` | [`Choice2Enum`](../../doc/models/choice-2-enum.md) | Required | Choice. |
| `ConfirmedBy` | `string` | Required, Constant | Confirmed by.<br><br>**Value**: `"seller"` |
| `DescriptionDigest` | `string` | Required | Description digest.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |
| `EvaluationId` | `string` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |
| `RecordedAt` | [`ProductConfirmResponseRecordedAt`](../../doc/models/containers/product-confirm-response-recorded-at.md) | Required | This is a container for any-of cases. |
| `Source` | [`Source10Enum`](../../doc/models/source-10-enum.md) | Required | Source. |

## Example

```csharp
using System.Collections.Generic;
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

ProductConfirmResponse productConfirmResponse = new ProductConfirmResponse
{
    AffectsDecision = "False",
    Card = ProductConfirmResponseCard.FromProductCard(
        new ProductCard
        {
            Brand = ProductCardBrand.FromString("String9"),
            Category = ProductCardCategory.FromString("String3"),
            ImageUrl = ProductCardImageUrl.FromString("String1"),
            KeyFeatures = new List<string>
            {
                "key_features0",
                "key_features1",
                "key_features2",
            },
            Materials = new List<string>
            {
                "materials5",
                "materials6",
            },
            ProductId = "product_id0",
            Title = "title0",
        }
    ),
    CardDigest = ProductConfirmResponseCardDigest.FromString("String1"),
    Choice = Choice2Enum.CONFIRMED,
    ConfirmedBy = "seller",
    DescriptionDigest = "description_digest2",
    EvaluationId = "evaluation_id8",
    RecordedAt = ProductConfirmResponseRecordedAt.FromString("String1"),
    Source = Source10Enum.Channel3Live,
};
```

