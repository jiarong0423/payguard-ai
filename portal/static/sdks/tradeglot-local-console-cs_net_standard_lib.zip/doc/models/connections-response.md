
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |
| `SandboxReads` | [`ConnectionsResponseSandboxReads`](../../doc/models/containers/connections-response-sandbox-reads.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

ConnectionsResponse connectionsResponse = new ConnectionsResponse
{
    Mode = ModeEnum.Local,
    SandboxReads = ConnectionsResponseSandboxReads.FromBoolean(true),
};
```

