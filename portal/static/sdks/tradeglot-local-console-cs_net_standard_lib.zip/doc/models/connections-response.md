
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ConnectionsResponse connectionsResponse = new ConnectionsResponse
{
    Mode = ModeEnum.Local,
};
```

