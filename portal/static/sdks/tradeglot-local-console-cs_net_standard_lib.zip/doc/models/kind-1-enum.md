
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Kind1Enum kind1 = Kind1Enum.MESSAGE;
```

