
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOTPERFORMED` |
| `PERFORMED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

ProviderSubmissionEnum providerSubmission = ProviderSubmissionEnum.NOTPERFORMED;
```

