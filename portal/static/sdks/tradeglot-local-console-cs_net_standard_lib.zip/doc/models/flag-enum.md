
# Flag Enum

## Enumeration

`FlagEnum`

## Fields

| Name |
|  --- |
| `ORDERRECORDABSENT` |
| `DELIVERYNOTRECORDED` |
| `DELIVERYAFTERCLAIM` |
| `CLAIMTIMEEARLIERTHANPAYMENTTIME` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

FlagEnum flag = FlagEnum.ORDERRECORDABSENT;
```

