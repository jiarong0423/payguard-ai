
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is ErrorBodyException)
    {
        // TODO: Handle ErrorBodyException
        Console.WriteLine(e.Message);
    }
}
```

