
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `Channel3` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source2Enum source2 = Source2Enum.Channel3;
```

