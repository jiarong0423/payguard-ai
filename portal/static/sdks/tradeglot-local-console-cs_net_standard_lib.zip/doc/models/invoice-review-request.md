
# Invoice Review Request

InvoiceReviewRequest.

## Structure

`InvoiceReviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AcknowledgementToken` | [`InvoiceReviewRequestAcknowledgementToken`](../../doc/models/containers/invoice-review-request-acknowledgement-token.md) | Optional | This is a container for any-of cases. |
| `Amount` | `string` | Required | Amount.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,9}(?:\.[0-9]{1,2})?$` |
| `ConfirmSandboxDraft` | `bool` | Required | Confirm sandbox draft. |
| `Currency` | [`CurrencyEnum`](../../doc/models/currency-enum.md) | Required | Currency. |
| `Description` | `string` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` |
| `DescriptionDigest` | [`InvoiceReviewRequestDescriptionDigest`](../../doc/models/containers/invoice-review-request-description-digest.md) | Optional | This is a container for any-of cases. |
| `EvaluationId` | [`InvoiceReviewRequestEvaluationId`](../../doc/models/containers/invoice-review-request-evaluation-id.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

InvoiceReviewRequest invoiceReviewRequest = new InvoiceReviewRequest
{
    Amount = "amount8",
    ConfirmSandboxDraft = false,
    Currency = CurrencyEnum.USD,
    Description = "description6",
    AcknowledgementToken = InvoiceReviewRequestAcknowledgementToken.FromString("String7"),
    DescriptionDigest = InvoiceReviewRequestDescriptionDigest.FromString("String5"),
    EvaluationId = InvoiceReviewRequestEvaluationId.FromString("String1"),
};
```

