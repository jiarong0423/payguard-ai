
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Burst` | `bool` | Required | Burst. |
| `Dispute` | `bool` | Required | Dispute. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Scenario scenario = new Scenario
{
    Burst = false,
    Dispute = false,
};
```

