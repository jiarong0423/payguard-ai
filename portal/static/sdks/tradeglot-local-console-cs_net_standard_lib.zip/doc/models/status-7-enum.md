
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NeedsReview` |
| `DraftReady` |
| `LocalDraftReviewed` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Status7Enum status7 = Status7Enum.NeedsReview;
```

