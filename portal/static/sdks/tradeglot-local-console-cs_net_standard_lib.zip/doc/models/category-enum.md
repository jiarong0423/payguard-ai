
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UnsupportedFinancialPromise` |
| `Weapons` |
| `ControlledSubstances` |
| `CounterfeitGoods` |
| `RegulatedActivity` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CategoryEnum category = CategoryEnum.ControlledSubstances;
```

