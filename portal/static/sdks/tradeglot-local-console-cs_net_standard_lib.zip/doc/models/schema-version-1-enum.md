
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `Enum1` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

SchemaVersion1Enum schemaVersion1 = SchemaVersion1Enum.Enum1;
```

