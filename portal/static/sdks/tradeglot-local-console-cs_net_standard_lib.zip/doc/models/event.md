
# Event

## Structure

`Event`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `string` | Optional | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `Channel` | [`ChannelEnum?`](../../doc/models/channel-enum.md) | Optional | Channel. |
| `Direction` | [`DirectionEnum?`](../../doc/models/direction-enum.md) | Optional | Direction. |
| `Kind` | [`Kind1Enum?`](../../doc/models/kind-1-enum.md) | Optional | Kind. |
| `MessageDigest` | `string` | Optional | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `Source` | [`Source6Enum?`](../../doc/models/source-6-enum.md) | Optional | Source. |
| `Topic` | [`TopicEnum?`](../../doc/models/topic-enum.md) | Optional | Topic. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Event mEvent = new Event
{
    At = "at0",
    Channel = ChannelEnum.EMAIL,
    Direction = DirectionEnum.INBOUND,
    Kind = Kind1Enum.MESSAGE,
    MessageDigest = "message_digest8",
};
```

