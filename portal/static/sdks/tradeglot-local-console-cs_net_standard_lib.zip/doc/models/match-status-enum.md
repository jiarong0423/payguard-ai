
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NOMATCH` |
| `REVIEWSIGNAL` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

MatchStatusEnum matchStatus = MatchStatusEnum.NOMATCH;
```

