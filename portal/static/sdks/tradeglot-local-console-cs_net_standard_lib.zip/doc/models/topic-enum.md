
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENTNOTICE` |
| `ORDERDETAILSREQUEST` |
| `ORDERDETAILSPROVIDED` |
| `DELIVERYNOTICE` |
| `REFUNDREQUEST` |
| `OTHER` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

TopicEnum topic = TopicEnum.ORDERDETAILSPROVIDED;
```

