
# Ai Usage Entry

AiUsageEntry.

## Structure

`AiUsageEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `At` | `string` | Required | At. |
| `EstimatedCostUsd` | [`AiUsageEntryEstimatedCostUsd`](../../doc/models/containers/ai-usage-entry-estimated-cost-usd.md) | Optional | This is a container for any-of cases. |
| `LatencyMs` | `int` | Required | Latency ms.<br><br>**Constraints**: `>= 0`, `<= 3600000` |
| `Model` | [`AiUsageEntryModel`](../../doc/models/containers/ai-usage-entry-model.md) | Optional | This is a container for any-of cases. |
| `Outcome` | [`OutcomeEnum`](../../doc/models/outcome-enum.md) | Required | Outcome. |
| `Stage` | [`Stage2Enum`](../../doc/models/stage-2-enum.md) | Required | Stage. |
| `TokensIn` | [`AiUsageEntryTokensIn`](../../doc/models/containers/ai-usage-entry-tokens-in.md) | Optional | This is a container for any-of cases. |
| `TokensOut` | [`AiUsageEntryTokensOut`](../../doc/models/containers/ai-usage-entry-tokens-out.md) | Optional | This is a container for any-of cases. |
| `TokensTotal` | [`AiUsageEntryTokensTotal`](../../doc/models/containers/ai-usage-entry-tokens-total.md) | Optional | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

AiUsageEntry aiUsageEntry = new AiUsageEntry
{
    At = "at4",
    LatencyMs = 38,
    Outcome = OutcomeEnum.Ok,
    Stage = Stage2Enum.VelocityGuard,
    EstimatedCostUsd = AiUsageEntryEstimatedCostUsd.FromString("String5"),
    Model = AiUsageEntryModel.FromString("String7"),
    TokensIn = AiUsageEntryTokensIn.FromNumber(236),
    TokensOut = AiUsageEntryTokensOut.FromNumber(94),
    TokensTotal = AiUsageEntryTokensTotal.FromNumber(158),
};
```

