
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SourceCompliance` |
| `VelocityGuard` |
| `DisputeMediation` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

StageEnum stage = StageEnum.DisputeMediation;
```

