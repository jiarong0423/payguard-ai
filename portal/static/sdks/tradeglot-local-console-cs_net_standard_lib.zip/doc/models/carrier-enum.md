
# Carrier Enum

Carrier.

## Enumeration

`CarrierEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TWCHUNGHWAPOST` |
| `JPJAPANPOST` |
| `OTHER` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CarrierEnum carrier = CarrierEnum.USPS;
```

