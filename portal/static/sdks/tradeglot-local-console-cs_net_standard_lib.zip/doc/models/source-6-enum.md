
# Source 6 Enum

Source.

## Enumeration

`Source6Enum`

## Fields

| Name |
|  --- |
| `SELLERPROVIDEDUNVERIFIED` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

Source6Enum source6 = Source6Enum.SELLERPROVIDEDUNVERIFIED;
```

