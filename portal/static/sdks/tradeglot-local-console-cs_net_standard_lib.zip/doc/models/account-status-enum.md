
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

AccountStatusEnum accountStatus = AccountStatusEnum.UNKNOWN;
```

