
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PaypalAccount` |
| `GuestCard` |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;

CheckoutEnum checkout = CheckoutEnum.PaypalAccount;
```

