
# Time Gaps

TimeGaps.

## Structure

`TimeGaps`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DeliveryToClaim` | [`TimeGapsDeliveryToClaim`](../../doc/models/containers/time-gaps-delivery-to-claim.md) | Required | This is a container for any-of cases. |
| `PaymentToClaim` | [`TimeGapsPaymentToClaim`](../../doc/models/containers/time-gaps-payment-to-claim.md) | Required | This is a container for any-of cases. |
| `PaymentToDelivery` | [`TimeGapsPaymentToDelivery`](../../doc/models/containers/time-gaps-payment-to-delivery.md) | Required | This is a container for any-of cases. |
| `PaymentToOrderRecord` | [`TimeGapsPaymentToOrderRecord`](../../doc/models/containers/time-gaps-payment-to-order-record.md) | Required | This is a container for any-of cases. |

## Example

```csharp
using TradeGlotLocalConsole.Standard.Models;
using TradeGlotLocalConsole.Standard.Models.Containers;

TimeGaps timeGaps = new TimeGaps
{
    DeliveryToClaim = TimeGapsDeliveryToClaim.FromNumber(152),
    PaymentToClaim = TimeGapsPaymentToClaim.FromNumber(212),
    PaymentToDelivery = TimeGapsPaymentToDelivery.FromNumber(222),
    PaymentToOrderRecord = TimeGapsPaymentToOrderRecord.FromNumber(10),
};
```

