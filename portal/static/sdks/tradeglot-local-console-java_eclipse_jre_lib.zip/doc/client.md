
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |

The API client can be initialized as follows:

```java
import m18000.m0.m0.m127.TradeGlotLocalConsoleClient;
import m18000.m0.m0.m127.exceptions.ApiException;

public class Program {
    public static void main(String[] args) {
        TradeGlotLocalConsoleClient client = new TradeGlotLocalConsoleClient.Builder()
            .httpClientConfig(configBuilder -> configBuilder
                    .timeout(0))
            .build();

    }
}
```

## TradeGlot Local ConsoleClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getAiController()` | Provides access to Ai controller. | `AiController` |
| `getAupController()` | Provides access to Aup controller. | `AupController` |
| `getDemoController()` | Provides access to Demo controller. | `DemoController` |
| `getGuideController()` | Provides access to Guide controller. | `GuideController` |
| `getHealthController()` | Provides access to Health controller. | `HealthController` |
| `getOtherController()` | Provides access to Other controller. | `OtherController` |
| `getPaypalController()` | Provides access to Paypal controller. | `PaypalController` |
| `getReferencesController()` | Provides access to References controller. | `ReferencesController` |
| `getStudioController()` | Provides access to Studio controller. | `StudioController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

