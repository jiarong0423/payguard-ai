
# Custom Header Signature



Documentation for accessing and setting credentials for DemoCsrf.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| X-CSRF-Token | `String` | CSRF token for the same session. Get it from the csrf_token field of the response to POST /api/v1/demo/sessions. Every POST also needs it; without it the API answers 403 csrf_rejected. | `xCSRFToken` | `getXCSRFToken()` |



**Note:** Auth credentials can be set using `demoCsrfCredentials` in the client builder and accessed through `getDemoCsrfCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import m18000.m0.m0.m127.TradeGlotLocalConsoleClient;
import m18000.m0.m0.m127.authentication.DemoCsrfModel;

public class Program {
    public static void main(String[] args) {
        TradeGlotLocalConsoleClient client = new TradeGlotLocalConsoleClient.Builder()
            .demoCsrfCredentials(new DemoCsrfModel.Builder(
                    "X-CSRF-Token"
                )
                .build())
            .build();
    }
}
```


