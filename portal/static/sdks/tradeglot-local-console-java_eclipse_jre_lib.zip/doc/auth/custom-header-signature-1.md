
# Custom Header Signature



Documentation for accessing and setting credentials for DemoSession.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| X-Demo-Session | `String` | Demo session id. Get it from the session_id field of the response to POST /api/v1/demo/sessions (that request needs no header). Without it the API answers 401 session_required. | `xDemoSession` | `getXDemoSession()` |



**Note:** Auth credentials can be set using `demoSessionCredentials` in the client builder and accessed through `getDemoSessionCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import m18000.m0.m0.m127.TradeGlotLocalConsoleClient;
import m18000.m0.m0.m127.authentication.DemoSessionModel;

public class Program {
    public static void main(String[] args) {
        TradeGlotLocalConsoleClient client = new TradeGlotLocalConsoleClient.Builder()
            .demoSessionCredentials(new DemoSessionModel.Builder(
                    "X-Demo-Session"
                )
                .build())
            .build();
    }
}
```


