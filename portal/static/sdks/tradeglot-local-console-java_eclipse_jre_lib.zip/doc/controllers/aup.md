# Aup

Acceptable-use keyword check and the invoice review that follows it.

```java
AupController aupController = client.getAupController();
```

## Class Name

`AupController`

## Methods

* [Post Aup Acknowledge](../../doc/controllers/aup.md#post-aup-acknowledge)
* [Post Aup Category Signal](../../doc/controllers/aup.md#post-aup-category-signal)
* [Post Aup Product Reference](../../doc/controllers/aup.md#post-aup-product-reference)
* [Post Aup Product Reference Confirm](../../doc/controllers/aup.md#post-aup-product-reference-confirm)
* [Post Aup Review](../../doc/controllers/aup.md#post-aup-review)


# Post Aup Acknowledge

Acknowledge Aup. Local console route POST /api/v1/aup/acknowledge on synthetic data; advisory only.

```java
CompletableFuture<AupAcknowledgeResponse> postAupAcknowledgeAsync(
    final AupAcknowledgeRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupAcknowledgeRequest`](../../doc/models/aup-acknowledge-request.md) | Body, Required | JSON body for: Acknowledge Aup. |

## Response Type

**200**: Successful Response

[`AupAcknowledgeResponse`](../../doc/models/aup-acknowledge-response.md)

## Example Usage

```java
AupAcknowledgeRequest body = new AupAcknowledgeRequest.Builder(
    ChoiceEnum.CANCEL,
    "description_digest4",
    "evaluation_id0"
)
.build();

aupController.postAupAcknowledgeAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Category Signal

Aup Category Signal. Local console route POST /api/v1/aup/category-signal on synthetic data; advisory only.

```java
CompletableFuture<AupCategorySignalResponse> postAupCategorySignalAsync(
    final AupCategorySignalRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupCategorySignalRequest`](../../doc/models/aup-category-signal-request.md) | Body, Required | JSON body for: Aup Category Signal. |

## Response Type

**200**: Successful Response

[`AupCategorySignalResponse`](../../doc/models/aup-category-signal-response.md)

## Example Usage

```java
AupCategorySignalRequest body = new AupCategorySignalRequest.Builder(
    "example",
    "examplexxxxxxxxxxxxxxxxxxxxxxxxx"
)
.build();

aupController.postAupCategorySignalAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference

Aup Product Reference. Local console route POST /api/v1/aup/product-reference on synthetic data; advisory only.

```java
CompletableFuture<ProductReferenceResponse> postAupProductReferenceAsync(
    final ProductReferenceRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductReferenceRequest`](../../doc/models/product-reference-request.md) | Body, Required | JSON body for: Aup Product Reference. |

## Response Type

**200**: Successful Response

[`ProductReferenceResponse`](../../doc/models/product-reference-response.md)

## Example Usage

```java
ProductReferenceRequest body = new ProductReferenceRequest.Builder(
    "example",
    "examplexxxxxxxxxxxxxxxxxxxxxxxxx"
)
.build();

aupController.postAupProductReferenceAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference Confirm

Aup Product Confirm. Local console route POST /api/v1/aup/product-reference/confirm on synthetic data; advisory only.

```java
CompletableFuture<ProductConfirmResponse> postAupProductReferenceConfirmAsync(
    final ProductConfirmRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductConfirmRequest`](../../doc/models/product-confirm-request.md) | Body, Required | JSON body for: Aup Product Confirm. |

## Response Type

**200**: Successful Response

[`ProductConfirmResponse`](../../doc/models/product-confirm-response.md)

## Example Usage

```java
ProductConfirmRequest body = new ProductConfirmRequest.Builder(
    "example",
    "examplexxxxxxxxxxxxxxxxxxxxxxxxx",
    ProductConfirmRequestProductId.fromString(
        "example"
    )
)
.build();

aupController.postAupProductReferenceConfirmAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Review

Aup. Local console route POST /api/v1/aup/review on synthetic data; advisory only.

```java
CompletableFuture<AupResponse> postAupReviewAsync(
    final AupRequest body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupRequest`](../../doc/models/aup-request.md) | Body, Required | JSON body for: Aup. |

## Response Type

**200**: Successful Response

[`AupResponse`](../../doc/models/aup-response.md)

## Example Usage

```java
AupRequest body = new AupRequest.Builder(
    "Handmade ceramic coffee mug, shipped in a padded box"
)
.build();

aupController.postAupReviewAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

