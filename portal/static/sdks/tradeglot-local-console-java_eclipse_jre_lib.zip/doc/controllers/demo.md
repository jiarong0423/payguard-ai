# Demo

Demo session, scenarios and local state.

```java
DemoController demoController = client.getDemoController();
```

## Class Name

`DemoController`

## Methods

* [Post Demo Inject](../../doc/controllers/demo.md#post-demo-inject)
* [Post Demo Sessions](../../doc/controllers/demo.md#post-demo-sessions)
* [Get Demo State](../../doc/controllers/demo.md#get-demo-state)


# Post Demo Inject

Inject. Local console route POST /api/v1/demo/inject on synthetic data; advisory only.

```java
CompletableFuture<StateResponse> postDemoInjectAsync(
    final InjectRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InjectRequest`](../../doc/models/inject-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```java
InjectRequest body = new InjectRequest.Builder(
    Scenario5Enum.DISPUTE
)
.build();

demoController.postDemoInjectAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Demo Sessions

New Session. Local console route POST /api/v1/demo/sessions on synthetic data; advisory only.

```java
CompletableFuture<SessionResponse> postDemoSessionsAsync(
    final Object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `Object` | Body, Required | - |

## Response Type

**201**: Successful Response

[`SessionResponse`](../../doc/models/session-response.md)

## Example Usage

```java
Object body = ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}");

demoController.postDemoSessionsAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Demo State

State. Local console route GET /api/v1/demo/state on synthetic data; advisory only.

```java
CompletableFuture<StateResponse> getDemoStateAsync()
```

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```java
demoController.getDemoStateAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

