# Guide

Evidence guide: gap filling over closed form items.

```java
GuideController guideController = client.getGuideController();
```

## Class Name

`GuideController`

## Methods

* [Post Guide Form](../../doc/controllers/guide.md#post-guide-form)
* [Post Guide Review](../../doc/controllers/guide.md#post-guide-review)
* [Post Guide Start](../../doc/controllers/guide.md#post-guide-start)
* [Get Guide State](../../doc/controllers/guide.md#get-guide-state)
* [Post Guide Turn](../../doc/controllers/guide.md#post-guide-turn)


# Post Guide Form

Guide Form. Local console route POST /api/v1/guide/form on synthetic data; advisory only.

```java
CompletableFuture<GuideStateResponse> postGuideFormAsync(
    final GuideFormRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideFormRequest`](../../doc/models/guide-form-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```java
GuideFormRequest body = new GuideFormRequest.Builder()
    .confirmReview(false)
    .build();

guideController.postGuideFormAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Review

Guide Review. Local console route POST /api/v1/guide/review on synthetic data; advisory only.

```java
CompletableFuture<GuideStateResponse> postGuideReviewAsync(
    final GuideReviewRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideReviewRequest`](../../doc/models/guide-review-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```java
GuideReviewRequest body = new GuideReviewRequest.Builder()
    .confirm(false)
    .build();

guideController.postGuideReviewAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Start

Guide Start. Local console route POST /api/v1/guide/start on synthetic data; advisory only.

```java
CompletableFuture<GuideStateResponse> postGuideStartAsync(
    final GuideStartRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideStartRequest`](../../doc/models/guide-start-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```java
GuideStartRequest body = new GuideStartRequest.Builder(
    Scenario2Enum.VELOCITY
)
.build();

guideController.postGuideStartAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Guide State

Guide State. Local console route GET /api/v1/guide/state on synthetic data; advisory only.

```java
CompletableFuture<GuideStateResponse> getGuideStateAsync(
    final GetGuideStateScenario scenario)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`GetGuideStateScenario`](../../doc/models/containers/get-guide-state-scenario.md) | Query, Optional | This is a container for any-of cases. |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```java
guideController.getGuideStateAsync(null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Guide Turn

Guide Turn. Local console route POST /api/v1/guide/turn on synthetic data; advisory only.

```java
CompletableFuture<GuideStateResponse> postGuideTurnAsync(
    final GuideTurnRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GuideTurnRequest`](../../doc/models/guide-turn-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`GuideStateResponse`](../../doc/models/guide-state-response.md)

## Example Usage

```java
GuideTurnRequest body = new GuideTurnRequest.Builder(
    "text4"
)
.build();

guideController.postGuideTurnAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

