# References

Pinned official references and search over them.

```java
ReferencesController referencesController = client.getReferencesController();
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```java
CompletableFuture<ReferenceResponse> postReferencesSearchAsync(
    final ReferenceRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ReferenceResponse`](../../doc/models/reference-response.md)

## Example Usage

```java
ReferenceRequest body = new ReferenceRequest.Builder(
    "US",
    "query6",
    ThemeEnum.DISPUTE_MEDIATION
)
.caseStage(CaseStage2Enum.ANY)
.limit(3)
.requireKnownSourceDate(false)
.build();

referencesController.postReferencesSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

