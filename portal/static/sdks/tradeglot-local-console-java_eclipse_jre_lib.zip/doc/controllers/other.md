# Other

Other console routes.

```java
OtherController otherController = client.getOtherController();
```

## Class Name

`OtherController`

## Methods

* [Post Advisory Evaluate](../../doc/controllers/other.md#post-advisory-evaluate)
* [Post Cases Route](../../doc/controllers/other.md#post-cases-route)
* [Get Connections](../../doc/controllers/other.md#get-connections)
* [Post Country Rules Check](../../doc/controllers/other.md#post-country-rules-check)
* [Get Country Rules Countries](../../doc/controllers/other.md#get-country-rules-countries)
* [Post Country Rules Search](../../doc/controllers/other.md#post-country-rules-search)
* [Post Disputes Case Ref Approve](../../doc/controllers/other.md#post-disputes-case-ref-approve)
* [Post Disputes Case Ref Draft](../../doc/controllers/other.md#post-disputes-case-ref-draft)
* [Post Policy Assess](../../doc/controllers/other.md#post-policy-assess)


# Post Advisory Evaluate

Advisory Evaluate. Local console route POST /api/v1/advisory/evaluate on synthetic data; advisory only.

```java
CompletableFuture<AdvisoryEvaluationResponse> postAdvisoryEvaluateAsync(
    final AdvisoryRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AdvisoryRequest`](../../doc/models/advisory-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AdvisoryEvaluationResponse`](../../doc/models/advisory-evaluation-response.md)

## Example Usage

```java
AdvisoryRequest body = new AdvisoryRequest.Builder(
    "as_of2",
    "candidate_json2",
    "US",
    102,
    ThemeEnum.DISPUTE_MEDIATION
)
.build();

otherController.postAdvisoryEvaluateAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Cases Route

Case Route. Local console route POST /api/v1/cases/route on synthetic data; advisory only.

```java
CompletableFuture<CaseRouteResponse> postCasesRouteAsync(
    final CaseRouteRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CaseRouteRequest`](../../doc/models/case-route-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`CaseRouteResponse`](../../doc/models/case-route-response.md)

## Example Usage

```java
CaseRouteRequest body = new CaseRouteRequest.Builder(
    "text4"
)
.build();

otherController.postCasesRouteAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Connections

Connections. Local console route GET /api/v1/connections on synthetic data; advisory only.

```java
CompletableFuture<ConnectionsResponse> getConnectionsAsync()
```

## Response Type

**200**: Successful Response

[`ConnectionsResponse`](../../doc/models/connections-response.md)

## Example Usage

```java
otherController.getConnectionsAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Check

Country Rules Check. Local console route POST /api/v1/country-rules/check on synthetic data; advisory only.

```java
CompletableFuture<Object> postCountryRulesCheckAsync(
    final CountryRulesCheckRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesCheckRequest`](../../doc/models/country-rules-check-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```java
CountryRulesCheckRequest body = new CountryRulesCheckRequest.Builder(
    BuyerCountryEnum.AU,
    SellerCountryEnum.AU
)
.accountOpened(AccountOpenedEnum.UNKNOWN)
.accountType(AccountTypeEnum.BUSINESS)
.checkout(CheckoutEnum.PAYPAL_ACCOUNT)
.build();

otherController.postCountryRulesCheckAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Country Rules Countries

Country Rules Countries. Local console route GET /api/v1/country-rules/countries on synthetic data; advisory only.

```java
CompletableFuture<Object> getCountryRulesCountriesAsync()
```

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```java
otherController.getCountryRulesCountriesAsync().thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Search

Country Rules Search. Local console route POST /api/v1/country-rules/search on synthetic data; advisory only.

```java
CompletableFuture<Object> postCountryRulesSearchAsync(
    final CountryRulesSearchRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesSearchRequest`](../../doc/models/country-rules-search-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```java
CountryRulesSearchRequest body = new CountryRulesSearchRequest.Builder(
    "query6"
)
.limit(5)
.build();

otherController.postCountryRulesSearchAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Approve

Approve. Local console route POST /api/v1/disputes/{case_ref}/approve on synthetic data; advisory only.

```java
CompletableFuture<DisputeApprovalResponse> postDisputesCaseRefApproveAsync(
    final String caseRef,
    final ApproveRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `caseRef` | `String` | Template, Required | Case ref. |
| `body` | [`ApproveRequest`](../../doc/models/approve-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`DisputeApprovalResponse`](../../doc/models/dispute-approval-response.md)

## Example Usage

```java
String caseRef = "case_ref4";
ApproveRequest body = new ApproveRequest.Builder(
    "draft_digest6"
)
.build();

otherController.postDisputesCaseRefApproveAsync(caseRef, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Draft

Draft. Local console route POST /api/v1/disputes/{case_ref}/draft on synthetic data; advisory only.

```java
CompletableFuture<DisputeDraftResponse> postDisputesCaseRefDraftAsync(
    final String caseRef,
    final Object body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `caseRef` | `String` | Template, Required | Case ref. |
| `body` | `Object` | Body, Required | - |

## Response Type

**200**: Successful Response

[`DisputeDraftResponse`](../../doc/models/dispute-draft-response.md)

## Example Usage

```java
String caseRef = "case_ref4";
Object body = ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}");

otherController.postDisputesCaseRefDraftAsync(caseRef, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Policy Assess

Policy Assess. Local console route POST /api/v1/policy/assess on synthetic data; advisory only.

```java
CompletableFuture<PolicyAssessmentResponse> postPolicyAssessAsync(
    final PolicyRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PolicyRequest`](../../doc/models/policy-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`PolicyAssessmentResponse`](../../doc/models/policy-assessment-response.md)

## Example Usage

```java
PolicyRequest body = new PolicyRequest.Builder(
    "as_of2",
    "US",
    102,
    ThemeEnum.DISPUTE_MEDIATION
)
.build();

otherController.postPolicyAssessAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof ErrorBodyException) {
        ErrorBodyException errorBodyException = (ErrorBodyException) cause;
        errorBodyException.printStackTrace();
    } else if (cause instanceof HTTPValidationErrorException) {
        HTTPValidationErrorException hTTPValidationErrorException = (HTTPValidationErrorException) cause;
        hTTPValidationErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

