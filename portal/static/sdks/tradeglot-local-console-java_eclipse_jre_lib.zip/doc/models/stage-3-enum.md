
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `FUNNEL` |
| `ECHO` |
| `FILL` |
| `REVIEW` |
| `DONE` |

## Example

```java
import m18000.m0.m0.m127.models.Stage3Enum;

Stage3Enum stage3 = Stage3Enum.DONE;
```

