
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `KEYWORD` |
| `MODEL` |
| `KEYWORD_FALLBACK` |
| `FORM` |

## Example

```java
import m18000.m0.m0.m127.models.ChooserEnum;

ChooserEnum chooser = ChooserEnum.FORM;
```

