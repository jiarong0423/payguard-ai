
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITING_FOR_SELLER_RESPONSE` |
| `WAITING_FOR_BUYER_RESPONSE` |
| `UNDER_REVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```java
import m18000.m0.m0.m127.models.Status3Enum;

Status3Enum status3 = Status3Enum.OPEN;
```

