
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTH_CONNECT` |
| `CREATE_INVOICE_DRAFT` |

## Example

```java
import m18000.m0.m0.m127.models.ActionEnum;

ActionEnum action = ActionEnum.OAUTH_CONNECT;
```

