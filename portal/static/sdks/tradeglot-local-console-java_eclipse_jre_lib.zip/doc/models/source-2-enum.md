
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3` |

## Example

```java
import m18000.m0.m0.m127.models.Source2Enum;

Source2Enum source2 = Source2Enum.CHANNEL3;
```

