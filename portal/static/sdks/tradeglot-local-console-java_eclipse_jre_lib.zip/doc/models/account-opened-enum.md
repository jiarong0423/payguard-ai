
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `BEFORE_CUTOFF` |
| `AFTER_CUTOFF` |

## Example

```java
import m18000.m0.m0.m127.models.AccountOpenedEnum;

AccountOpenedEnum accountOpened = AccountOpenedEnum.AFTER_CUTOFF;
```

