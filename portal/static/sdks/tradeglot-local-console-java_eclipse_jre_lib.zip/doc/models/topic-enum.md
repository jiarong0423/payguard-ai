
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENT_NOTICE` |
| `ORDER_DETAILS_REQUEST` |
| `ORDER_DETAILS_PROVIDED` |
| `DELIVERY_NOTICE` |
| `REFUND_REQUEST` |
| `OTHER` |

## Example

```java
import m18000.m0.m0.m127.models.TopicEnum;

TopicEnum topic = TopicEnum.ORDER_DETAILS_PROVIDED;
```

