
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `WORDS` |
| `WORDS_PENDING` |

## Example

```java
import m18000.m0.m0.m127.models.Source9Enum;

Source9Enum source9 = Source9Enum.WORDS;
```

