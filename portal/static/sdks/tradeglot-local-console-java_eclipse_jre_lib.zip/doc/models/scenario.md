
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Burst` | `boolean` | Required | Burst. | boolean getBurst() | setBurst(boolean burst) |
| `Dispute` | `boolean` | Required | Dispute. | boolean getDispute() | setDispute(boolean dispute) |

## Example

```java
import m18000.m0.m0.m127.models.Scenario;

Scenario scenario = new Scenario.Builder(
    false,
    false
)
.build();
```

