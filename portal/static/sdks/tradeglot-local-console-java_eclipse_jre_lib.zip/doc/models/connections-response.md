
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. | ModeEnum getMode() | setMode(ModeEnum mode) |
| `SandboxReads` | [`ConnectionsResponseSandboxReads`](../../doc/models/containers/connections-response-sandbox-reads.md) | Optional | This is a container for any-of cases. | ConnectionsResponseSandboxReads getSandboxReads() | setSandboxReads(ConnectionsResponseSandboxReads sandboxReads) |

## Example

```java
import m18000.m0.m0.m127.models.ConnectionsResponse;
import m18000.m0.m0.m127.models.ModeEnum;
import m18000.m0.m0.m127.models.containers.ConnectionsResponseSandboxReads;

ConnectionsResponse connectionsResponse = new ConnectionsResponse.Builder(
    ModeEnum.LOCAL
)
.sandboxReads(ConnectionsResponseSandboxReads.fromBoolean(
        true
    ))
.build();
```

