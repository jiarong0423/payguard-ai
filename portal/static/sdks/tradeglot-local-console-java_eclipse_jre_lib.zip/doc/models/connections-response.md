
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. | ModeEnum getMode() | setMode(ModeEnum mode) |

## Example

```java
import m18000.m0.m0.m127.models.ConnectionsResponse;
import m18000.m0.m0.m127.models.ModeEnum;

ConnectionsResponse connectionsResponse = new ConnectionsResponse.Builder(
    ModeEnum.LOCAL
)
.build();
```

