
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```java
import m18000.m0.m0.m127.models.SellerCountryEnum;

SellerCountryEnum sellerCountry = SellerCountryEnum.AU;
```

