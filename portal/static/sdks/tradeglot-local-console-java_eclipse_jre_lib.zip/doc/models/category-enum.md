
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UNSUPPORTED_FINANCIAL_PROMISE` |
| `WEAPONS` |
| `CONTROLLED_SUBSTANCES` |
| `COUNTERFEIT_GOODS` |
| `REGULATED_ACTIVITY` |

## Example

```java
import m18000.m0.m0.m127.models.CategoryEnum;

CategoryEnum category = CategoryEnum.CONTROLLED_SUBSTANCES;
```

