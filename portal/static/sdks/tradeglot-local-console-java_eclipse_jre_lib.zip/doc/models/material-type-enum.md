
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |

## Example

```java
import m18000.m0.m0.m127.models.MaterialTypeEnum;

MaterialTypeEnum materialType = MaterialTypeEnum.OFFICIAL_API_REFERENCE;
```

