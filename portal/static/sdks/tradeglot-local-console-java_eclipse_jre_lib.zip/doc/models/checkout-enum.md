
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_ACCOUNT` |
| `GUEST_CARD` |

## Example

```java
import m18000.m0.m0.m127.models.CheckoutEnum;

CheckoutEnum checkout = CheckoutEnum.PAYPAL_ACCOUNT;
```

