
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OTHER_PARTY` |
| `INFERRED` |

## Example

```java
import m18000.m0.m0.m127.models.Reason6Enum;

Reason6Enum reason6 = Reason6Enum.OTHER_PARTY;
```

