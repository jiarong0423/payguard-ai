
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOT_MADE` |

## Example

```java
import m18000.m0.m0.m127.models.JudgementEnum;

JudgementEnum judgement = JudgementEnum.NOT_MADE;
```

