
# Guide Turn Request Scenario

## Class Name

`GuideTurnRequestScenario`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) | GuideTurnRequestScenario.fromScenario1(Scenario1Enum scenario1) |

## Scenario1Enum

### Initialization Code

#### Example

```java
GuideTurnRequestScenario.fromScenario1(
        Scenario1Enum.PREFLIGHT
    )
```

