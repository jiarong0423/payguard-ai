
# Guide State Response Goods Type

## Class Name

`GuideStateResponseGoodsType`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GoodsTypeEnum`](../../../doc/models/goods-type-enum.md) | GuideStateResponseGoodsType.fromGoodsType(GoodsTypeEnum goodsType) |

## GoodsTypeEnum

### Initialization Code

#### Example

```java
GuideStateResponseGoodsType.fromGoodsType(
        GoodsTypeEnum.PHYSICAL
    )
```

