
# Dispute Record Seller Response Due Date

## Class Name

`DisputeRecordSellerResponseDueDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeRecordSellerResponseDueDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeRecordSellerResponseDueDate.fromString(
        "String0"
    )
```

