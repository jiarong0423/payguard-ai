
# Evidence Carrier Status

## Class Name

`EvidenceCarrierStatus`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceCarrierStatus.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceCarrierStatus.fromString(
        "String0"
    )
```

