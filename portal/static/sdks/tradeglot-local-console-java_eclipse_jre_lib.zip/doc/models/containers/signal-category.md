
# Signal Category

## Class Name

`SignalCategory`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SignalCategory.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SignalCategory.fromString(
        "String0"
    )
```

