
# Policy Source Decision Date

## Class Name

`PolicySourceDecisionDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | PolicySourceDecisionDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
PolicySourceDecisionDate.fromString(
        "String0"
    )
```

