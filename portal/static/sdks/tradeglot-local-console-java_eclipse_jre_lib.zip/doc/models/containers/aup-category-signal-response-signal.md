
# Aup Category Signal Response Signal

## Class Name

`AupCategorySignalResponseSignal`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`CategorySignal`](../../../doc/models/category-signal.md) | AupCategorySignalResponseSignal.fromCategorySignal(CategorySignal categorySignal) |

## CategorySignal

### Initialization Code

#### Example

```java
AupCategorySignalResponseSignal.fromCategorySignal(
        new CategorySignal.Builder(
            CategorySignalCategory.fromString(
                "String9"
            ),
            CategorySignalConfidence.fromConfidence(
                ConfidenceEnum.HIGH
            ),
            "channel3"
        )
        .build()
    )
```

