
# Dispute Detail Response Dispute State

## Class Name

`DisputeDetailResponseDisputeState`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeDetailResponseDisputeState.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeDetailResponseDisputeState.fromString(
        "String0"
    )
```

