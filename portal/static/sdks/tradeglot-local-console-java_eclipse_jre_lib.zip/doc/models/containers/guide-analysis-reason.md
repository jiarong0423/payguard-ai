
# Guide Analysis Reason

## Class Name

`GuideAnalysisReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Reason5Enum`](../../../doc/models/reason-5-enum.md) | GuideAnalysisReason.fromReason5(Reason5Enum reason5) |

## Reason5Enum

### Initialization Code

#### Example

```java
GuideAnalysisReason.fromReason5(
        Reason5Enum.BUDGET
    )
```

