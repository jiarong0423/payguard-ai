
# Invoice Review Request Evaluation Id

## Class Name

`InvoiceReviewRequestEvaluationId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | InvoiceReviewRequestEvaluationId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
InvoiceReviewRequestEvaluationId.fromString(
        "String0"
    )
```

