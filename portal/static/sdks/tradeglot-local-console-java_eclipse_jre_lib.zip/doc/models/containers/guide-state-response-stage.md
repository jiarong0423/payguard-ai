
# Guide State Response Stage

## Class Name

`GuideStateResponseStage`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Stage3Enum`](../../../doc/models/stage-3-enum.md) | GuideStateResponseStage.fromStage3(Stage3Enum stage3) |

## Stage3Enum

### Initialization Code

#### Example

```java
GuideStateResponseStage.fromStage3(
        Stage3Enum.FUNNEL
    )
```

