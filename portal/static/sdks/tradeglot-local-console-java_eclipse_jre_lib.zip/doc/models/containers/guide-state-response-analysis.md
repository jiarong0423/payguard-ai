
# Guide State Response Analysis

## Class Name

`GuideStateResponseAnalysis`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GuideAnalysis`](../../../doc/models/guide-analysis.md) | GuideStateResponseAnalysis.fromGuideAnalysis(GuideAnalysis guideAnalysis) |

## GuideAnalysis

### Initialization Code

#### Example

```java
GuideStateResponseAnalysis.fromGuideAnalysis(
        new GuideAnalysis.Builder(
            GuideAnalysisReason.fromReason5(
                Reason5Enum.INVALID_REPLY
            ),
            Status8Enum.REPLACED,
            186
        )
        .build()
    )
```

