
# Guide Form Request Fields

## Class Name

`GuideFormRequestFields`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`List<GuideField>`](../../../doc/models/guide-field.md) | GuideFormRequestFields.fromListOfGuideField(List<GuideField> listOfGuideField) |

## List<GuideField>

### Initialization Code

#### Example

```java
GuideFormRequestFields.fromListOfGuideField(
        Arrays.asList(
            new GuideField.Builder(
                "item8",
                "value8"
            )
            .build()
        )
    )
```

