
# Send Guard Dispute Seller Masked

## Class Name

`SendGuardDisputeSellerMasked`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SendGuardDisputeSellerMasked.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SendGuardDisputeSellerMasked.fromString(
        "String0"
    )
```

