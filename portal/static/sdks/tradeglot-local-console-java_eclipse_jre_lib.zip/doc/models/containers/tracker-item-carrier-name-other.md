
# Tracker Item Carrier Name Other

## Class Name

`TrackerItemCarrierNameOther`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | TrackerItemCarrierNameOther.fromString(String string) |

## String

### Initialization Code

#### Example

```java
TrackerItemCarrierNameOther.fromString(
        "String0"
    )
```

