
# Guide Reply Fallback Reason

## Class Name

`GuideReplyFallbackReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`FallbackReasonEnum`](../../../doc/models/fallback-reason-enum.md) | GuideReplyFallbackReason.fromFallbackReason(FallbackReasonEnum fallbackReason) |

## FallbackReasonEnum

### Initialization Code

#### Example

```java
GuideReplyFallbackReason.fromFallbackReason(
        FallbackReasonEnum.BUDGET
    )
```

