
# Disputed Transaction Seller Protection Eligible

## Class Name

`DisputedTransactionSellerProtectionEligible`

## Cases

| Type | Factory Method |
|  --- | --- |
| `boolean` | DisputedTransactionSellerProtectionEligible.fromBoolean(boolean mBoolean) |

## boolean

### Initialization Code

#### Example

```java
DisputedTransactionSellerProtectionEligible.fromBoolean(
        false
    )
```

