
# Reference Citation Effective Date

## Class Name

`ReferenceCitationEffectiveDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceCitationEffectiveDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceCitationEffectiveDate.fromString(
        "String0"
    )
```

