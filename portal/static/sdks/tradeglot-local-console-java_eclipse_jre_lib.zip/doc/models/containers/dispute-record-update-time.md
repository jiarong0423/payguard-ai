
# Dispute Record Update Time

## Class Name

`DisputeRecordUpdateTime`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeRecordUpdateTime.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeRecordUpdateTime.fromString(
        "String0"
    )
```

