
# Case Route Match Category

## Class Name

`CaseRouteMatchCategory`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CaseRouteMatchCategory.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CaseRouteMatchCategory.fromString(
        "String0"
    )
```

