
# Guide Form Placeholder

## Class Name

`GuideFormPlaceholder`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | GuideFormPlaceholder.fromString(String string) |

## String

### Initialization Code

#### Example

```java
GuideFormPlaceholder.fromString(
        "String0"
    )
```

