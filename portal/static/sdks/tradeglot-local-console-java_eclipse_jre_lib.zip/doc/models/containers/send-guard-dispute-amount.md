
# Send Guard Dispute Amount

## Class Name

`SendGuardDisputeAmount`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`ProviderMoney`](../../../doc/models/provider-money.md) | SendGuardDisputeAmount.fromProviderMoney(ProviderMoney providerMoney) |

## ProviderMoney

### Initialization Code

#### Example

```java
SendGuardDisputeAmount.fromProviderMoney(
        new ProviderMoney.Builder(
            "currency_code0",
            "value6"
        )
        .build()
    )
```

