
# Provide Evidence Response Paypal Debug Id

## Class Name

`ProvideEvidenceResponsePaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProvideEvidenceResponsePaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProvideEvidenceResponsePaypalDebugId.fromString(
        "String0"
    )
```

