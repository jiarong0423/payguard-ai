
# Policy Source Effective Date

## Class Name

`PolicySourceEffectiveDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | PolicySourceEffectiveDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
PolicySourceEffectiveDate.fromString(
        "String0"
    )
```

