
# Guide Turn Request Fields

## Class Name

`GuideTurnRequestFields`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`List<GuideField>`](../../../doc/models/guide-field.md) | GuideTurnRequestFields.fromListOfGuideField(List<GuideField> listOfGuideField) |

## List<GuideField>

### Initialization Code

#### Example

```java
GuideTurnRequestFields.fromListOfGuideField(
        Arrays.asList(
            new GuideField.Builder(
                "item8",
                "value8"
            )
            .build()
        )
    )
```

