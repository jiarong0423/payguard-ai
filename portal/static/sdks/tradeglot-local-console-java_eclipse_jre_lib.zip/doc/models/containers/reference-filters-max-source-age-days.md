
# Reference Filters Max Source Age Days

## Class Name

`ReferenceFiltersMaxSourceAgeDays`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | ReferenceFiltersMaxSourceAgeDays.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
ReferenceFiltersMaxSourceAgeDays.fromNumber(
        0
    )
```

