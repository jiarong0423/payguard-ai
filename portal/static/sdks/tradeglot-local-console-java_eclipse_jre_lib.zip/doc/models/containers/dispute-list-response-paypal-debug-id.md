
# Dispute List Response Paypal Debug Id

## Class Name

`DisputeListResponsePaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeListResponsePaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeListResponsePaypalDebugId.fromString(
        "String0"
    )
```

