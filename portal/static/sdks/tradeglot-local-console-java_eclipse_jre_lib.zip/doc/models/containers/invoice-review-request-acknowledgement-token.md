
# Invoice Review Request Acknowledgement Token

## Class Name

`InvoiceReviewRequestAcknowledgementToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | InvoiceReviewRequestAcknowledgementToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
InvoiceReviewRequestAcknowledgementToken.fromString(
        "String0"
    )
```

