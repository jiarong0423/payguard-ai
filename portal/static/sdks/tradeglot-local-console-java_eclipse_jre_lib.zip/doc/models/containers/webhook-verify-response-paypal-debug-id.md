
# Webhook Verify Response Paypal Debug Id

## Class Name

`WebhookVerifyResponsePaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookVerifyResponsePaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookVerifyResponsePaypalDebugId.fromString(
        "String0"
    )
```

