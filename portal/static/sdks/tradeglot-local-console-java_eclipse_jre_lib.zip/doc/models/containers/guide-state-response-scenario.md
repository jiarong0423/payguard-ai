
# Guide State Response Scenario

## Class Name

`GuideStateResponseScenario`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) | GuideStateResponseScenario.fromScenario1(Scenario1Enum scenario1) |

## Scenario1Enum

### Initialization Code

#### Example

```java
GuideStateResponseScenario.fromScenario1(
        Scenario1Enum.PREFLIGHT
    )
```

