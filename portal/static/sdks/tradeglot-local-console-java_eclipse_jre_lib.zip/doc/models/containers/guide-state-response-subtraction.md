
# Guide State Response Subtraction

## Class Name

`GuideStateResponseSubtraction`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GuideSubtraction`](../../../doc/models/guide-subtraction.md) | GuideStateResponseSubtraction.fromGuideSubtraction(GuideSubtraction guideSubtraction) |

## GuideSubtraction

### Initialization Code

#### Example

```java
GuideStateResponseSubtraction.fromGuideSubtraction(
        new GuideSubtraction.Builder(
            64,
            190,
            178,
            "text0"
        )
        .build()
    )
```

