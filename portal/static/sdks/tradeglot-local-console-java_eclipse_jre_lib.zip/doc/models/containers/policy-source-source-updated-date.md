
# Policy Source Source Updated Date

## Class Name

`PolicySourceSourceUpdatedDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | PolicySourceSourceUpdatedDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
PolicySourceSourceUpdatedDate.fromString(
        "String0"
    )
```

