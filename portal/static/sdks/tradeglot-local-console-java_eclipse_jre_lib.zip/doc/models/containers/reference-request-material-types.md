
# Reference Request Material Types

## Class Name

`ReferenceRequestMaterialTypes`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`List<MaterialType4Enum>`](../../../doc/models/material-type-4-enum.md) | ReferenceRequestMaterialTypes.fromListOfMaterialType4(List<MaterialType4Enum> listOfMaterialType4) |

## List<MaterialType4Enum>

### Initialization Code

#### Example

```java
ReferenceRequestMaterialTypes.fromListOfMaterialType4(
        Arrays.asList(
            MaterialType4Enum.PUBLIC_COURT_ORDER_COPY
        )
    )
```

