
# Add Tracking Request Confirm Token

## Class Name

`AddTrackingRequestConfirmToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AddTrackingRequestConfirmToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AddTrackingRequestConfirmToken.fromString(
        "String0"
    )
```

