
# Category Signal Confidence

## Class Name

`CategorySignalConfidence`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`ConfidenceEnum`](../../../doc/models/confidence-enum.md) | CategorySignalConfidence.fromConfidence(ConfidenceEnum confidence) |

## ConfidenceEnum

### Initialization Code

#### Example

```java
CategorySignalConfidence.fromConfidence(
        ConfidenceEnum.HIGH
    )
```

