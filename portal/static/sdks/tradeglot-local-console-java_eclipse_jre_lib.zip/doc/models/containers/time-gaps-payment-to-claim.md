
# Time Gaps Payment to Claim

## Class Name

`TimeGapsPaymentToClaim`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | TimeGapsPaymentToClaim.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
TimeGapsPaymentToClaim.fromNumber(
        0
    )
```

