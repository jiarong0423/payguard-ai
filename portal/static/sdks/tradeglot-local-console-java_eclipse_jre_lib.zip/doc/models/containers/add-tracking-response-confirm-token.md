
# Add Tracking Response Confirm Token

## Class Name

`AddTrackingResponseConfirmToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AddTrackingResponseConfirmToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AddTrackingResponseConfirmToken.fromString(
        "String0"
    )
```

