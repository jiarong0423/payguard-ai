
# Send Guard Dispute Reason

## Class Name

`SendGuardDisputeReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SendGuardDisputeReason.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SendGuardDisputeReason.fromString(
        "String0"
    )
```

