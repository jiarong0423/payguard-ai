
# Invoice Review Request Description Digest

## Class Name

`InvoiceReviewRequestDescriptionDigest`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | InvoiceReviewRequestDescriptionDigest.fromString(String string) |

## String

### Initialization Code

#### Example

```java
InvoiceReviewRequestDescriptionDigest.fromString(
        "String0"
    )
```

