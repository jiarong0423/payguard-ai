
# Reference Request Max Source Age Days

## Class Name

`ReferenceRequestMaxSourceAgeDays`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | ReferenceRequestMaxSourceAgeDays.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
ReferenceRequestMaxSourceAgeDays.fromNumber(
        0
    )
```

