
# Case Route Response Query

## Class Name

`CaseRouteResponseQuery`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CaseRouteResponseQuery.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CaseRouteResponseQuery.fromString(
        "String0"
    )
```

