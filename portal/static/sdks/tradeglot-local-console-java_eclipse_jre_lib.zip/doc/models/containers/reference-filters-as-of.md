
# Reference Filters as Of

## Class Name

`ReferenceFiltersAsOf`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceFiltersAsOf.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceFiltersAsOf.fromString(
        "String0"
    )
```

