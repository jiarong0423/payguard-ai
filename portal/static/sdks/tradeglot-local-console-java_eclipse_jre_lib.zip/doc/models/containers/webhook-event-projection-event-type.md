
# Webhook Event Projection Event Type

## Class Name

`WebhookEventProjectionEventType`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookEventProjectionEventType.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookEventProjectionEventType.fromString(
        "String0"
    )
```

