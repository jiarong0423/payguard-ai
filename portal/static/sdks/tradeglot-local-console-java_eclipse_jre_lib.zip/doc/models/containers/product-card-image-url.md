
# Product Card Image Url

## Class Name

`ProductCardImageUrl`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductCardImageUrl.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductCardImageUrl.fromString(
        "String0"
    )
```

