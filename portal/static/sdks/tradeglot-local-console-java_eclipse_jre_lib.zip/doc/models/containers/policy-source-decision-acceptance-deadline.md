
# Policy Source Decision Acceptance Deadline

## Class Name

`PolicySourceDecisionAcceptanceDeadline`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | PolicySourceDecisionAcceptanceDeadline.fromString(String string) |

## String

### Initialization Code

#### Example

```java
PolicySourceDecisionAcceptanceDeadline.fromString(
        "String0"
    )
```

