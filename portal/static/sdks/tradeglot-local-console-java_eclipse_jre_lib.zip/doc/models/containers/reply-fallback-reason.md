
# Reply Fallback Reason

## Class Name

`ReplyFallbackReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`FallbackReasonEnum`](../../../doc/models/fallback-reason-enum.md) | ReplyFallbackReason.fromFallbackReason(FallbackReasonEnum fallbackReason) |

## FallbackReasonEnum

### Initialization Code

#### Example

```java
ReplyFallbackReason.fromFallbackReason(
        FallbackReasonEnum.BUDGET
    )
```

