
# Reference Citation Decision Acceptance Deadline

## Class Name

`ReferenceCitationDecisionAcceptanceDeadline`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceCitationDecisionAcceptanceDeadline.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceCitationDecisionAcceptanceDeadline.fromString(
        "String0"
    )
```

