
# Aup Category Signal Response Reason

## Class Name

`AupCategorySignalResponseReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`ReasonEnum`](../../../doc/models/reason-enum.md) | AupCategorySignalResponseReason.fromReason(ReasonEnum reason) |

## ReasonEnum

### Initialization Code

#### Example

```java
AupCategorySignalResponseReason.fromReason(
        ReasonEnum.NOTHING_TO_SEND
    )
```

