
# Dispute Detail Response Update Time

## Class Name

`DisputeDetailResponseUpdateTime`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeDetailResponseUpdateTime.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeDetailResponseUpdateTime.fromString(
        "String0"
    )
```

