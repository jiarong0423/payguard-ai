
# Disputed Transaction Gross Amount

## Class Name

`DisputedTransactionGrossAmount`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`ProviderMoney`](../../../doc/models/provider-money.md) | DisputedTransactionGrossAmount.fromProviderMoney(ProviderMoney providerMoney) |

## ProviderMoney

### Initialization Code

#### Example

```java
DisputedTransactionGrossAmount.fromProviderMoney(
        new ProviderMoney.Builder(
            "currency_code0",
            "value6"
        )
        .build()
    )
```

