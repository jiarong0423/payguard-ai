
# Validation Error Loc

## Class Name

`ValidationErrorLoc`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ValidationErrorLoc.fromString(String string) |
| `int` | ValidationErrorLoc.fromNumber(int number) |

## String

### Initialization Code

#### Example

```java
ValidationErrorLoc.fromString(
        "String0"
    )
```

## int

### Initialization Code

#### Example

```java
ValidationErrorLoc.fromNumber(
        0
    )
```

