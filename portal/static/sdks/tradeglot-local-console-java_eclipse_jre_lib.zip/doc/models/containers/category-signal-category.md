
# Category Signal Category

## Class Name

`CategorySignalCategory`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CategorySignalCategory.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CategorySignalCategory.fromString(
        "String0"
    )
```

