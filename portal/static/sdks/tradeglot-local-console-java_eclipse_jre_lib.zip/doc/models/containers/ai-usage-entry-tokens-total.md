
# Ai Usage Entry Tokens Total

## Class Name

`AiUsageEntryTokensTotal`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | AiUsageEntryTokensTotal.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
AiUsageEntryTokensTotal.fromNumber(
        0
    )
```

