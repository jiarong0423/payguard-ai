
# Dispute Evidence Row Action

## Class Name

`DisputeEvidenceRowAction`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeEvidenceRowAction.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeEvidenceRowAction.fromString(
        "String0"
    )
```

