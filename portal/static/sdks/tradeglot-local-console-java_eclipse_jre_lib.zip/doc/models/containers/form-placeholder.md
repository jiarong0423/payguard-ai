
# Form Placeholder

## Class Name

`FormPlaceholder`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | FormPlaceholder.fromString(String string) |

## String

### Initialization Code

#### Example

```java
FormPlaceholder.fromString(
        "String0"
    )
```

