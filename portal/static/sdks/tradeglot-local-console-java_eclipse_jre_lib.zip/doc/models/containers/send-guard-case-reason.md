
# Send Guard Case Reason

## Class Name

`SendGuardCaseReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SendGuardCaseReason.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SendGuardCaseReason.fromString(
        "String0"
    )
```

