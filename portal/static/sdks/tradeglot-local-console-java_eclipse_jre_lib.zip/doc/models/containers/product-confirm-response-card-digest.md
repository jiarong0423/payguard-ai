
# Product Confirm Response Card Digest

## Class Name

`ProductConfirmResponseCardDigest`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductConfirmResponseCardDigest.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductConfirmResponseCardDigest.fromString(
        "String0"
    )
```

