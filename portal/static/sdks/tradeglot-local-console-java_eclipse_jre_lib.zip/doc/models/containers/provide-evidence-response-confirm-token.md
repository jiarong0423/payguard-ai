
# Provide Evidence Response Confirm Token

## Class Name

`ProvideEvidenceResponseConfirmToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProvideEvidenceResponseConfirmToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProvideEvidenceResponseConfirmToken.fromString(
        "String0"
    )
```

