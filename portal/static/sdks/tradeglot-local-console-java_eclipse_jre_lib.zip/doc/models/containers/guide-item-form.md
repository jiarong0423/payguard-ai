
# Guide Item Form

## Class Name

`GuideItemForm`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GuideForm`](../../../doc/models/guide-form.md) | GuideItemForm.fromGuideForm(GuideForm guideForm) |

## GuideForm

### Initialization Code

#### Example

```java
GuideItemForm.fromGuideForm(
        new GuideForm.Builder(
            Kind2Enum.CHOICE,
            Arrays.asList(
                new GuideOption.Builder(
                    "label2",
                    "value4"
                )
                .build()
            ),
            GuideFormPlaceholder.fromString(
                "String9"
            )
        )
        .build()
    )
```

