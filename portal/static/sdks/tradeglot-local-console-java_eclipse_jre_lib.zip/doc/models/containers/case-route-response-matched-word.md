
# Case Route Response Matched Word

## Class Name

`CaseRouteResponseMatchedWord`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CaseRouteResponseMatchedWord.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CaseRouteResponseMatchedWord.fromString(
        "String0"
    )
```

