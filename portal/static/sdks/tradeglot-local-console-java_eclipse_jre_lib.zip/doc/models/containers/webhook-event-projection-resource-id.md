
# Webhook Event Projection Resource Id

## Class Name

`WebhookEventProjectionResourceId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookEventProjectionResourceId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookEventProjectionResourceId.fromString(
        "String0"
    )
```

