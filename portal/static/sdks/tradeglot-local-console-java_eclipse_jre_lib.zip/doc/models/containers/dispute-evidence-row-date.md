
# Dispute Evidence Row Date

## Class Name

`DisputeEvidenceRowDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeEvidenceRowDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeEvidenceRowDate.fromString(
        "String0"
    )
```

