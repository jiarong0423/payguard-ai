
# Ai Usage Entry Estimated Cost Usd

## Class Name

`AiUsageEntryEstimatedCostUsd`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AiUsageEntryEstimatedCostUsd.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AiUsageEntryEstimatedCostUsd.fromString(
        "String0"
    )
```

