
# Evidence Reason

## Class Name

`EvidenceReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceReason.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceReason.fromString(
        "String0"
    )
```

