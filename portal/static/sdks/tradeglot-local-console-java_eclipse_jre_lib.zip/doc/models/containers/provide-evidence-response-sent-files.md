
# Provide Evidence Response Sent Files

## Class Name

`ProvideEvidenceResponseSentFiles`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`List<SentFileFingerprint>`](../../../doc/models/sent-file-fingerprint.md) | ProvideEvidenceResponseSentFiles.fromListOfSentFileFingerprint(List<SentFileFingerprint> listOfSentFileFingerprint) |

## List<SentFileFingerprint>

### Initialization Code

#### Example

```java
ProvideEvidenceResponseSentFiles.fromListOfSentFileFingerprint(
        Arrays.asList(
            new SentFileFingerprint.Builder(
                196,
                ContentTypeEnum.ENUM_IMAGEPNG,
                "filename6",
                "sha2566"
            )
            .build()
        )
    )
```

