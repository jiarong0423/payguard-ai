
# Ai Usage Entry Tokens Out

## Class Name

`AiUsageEntryTokensOut`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | AiUsageEntryTokensOut.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
AiUsageEntryTokensOut.fromNumber(
        0
    )
```

