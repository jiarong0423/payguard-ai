
# Product Confirm Response Recorded At

## Class Name

`ProductConfirmResponseRecordedAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductConfirmResponseRecordedAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductConfirmResponseRecordedAt.fromString(
        "String0"
    )
```

