
# Evidence Receipt Paypal Debug Id

## Class Name

`EvidenceReceiptPaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceReceiptPaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceReceiptPaypalDebugId.fromString(
        "String0"
    )
```

