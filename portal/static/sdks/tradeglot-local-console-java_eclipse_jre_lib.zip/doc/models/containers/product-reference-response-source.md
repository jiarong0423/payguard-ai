
# Product Reference Response Source

## Class Name

`ProductReferenceResponseSource`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Source11Enum`](../../../doc/models/source-11-enum.md) | ProductReferenceResponseSource.fromSource11(Source11Enum source11) |

## Source11Enum

### Initialization Code

#### Example

```java
ProductReferenceResponseSource.fromSource11(
        Source11Enum.CHANNEL3_LIVE
    )
```

