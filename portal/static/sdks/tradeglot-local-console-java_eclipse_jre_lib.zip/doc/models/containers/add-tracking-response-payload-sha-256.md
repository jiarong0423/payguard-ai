
# Add Tracking Response Payload Sha 256

## Class Name

`AddTrackingResponsePayloadSha256`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AddTrackingResponsePayloadSha256.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AddTrackingResponsePayloadSha256.fromString(
        "String0"
    )
```

