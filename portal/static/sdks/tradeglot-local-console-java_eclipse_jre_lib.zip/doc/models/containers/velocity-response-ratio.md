
# Velocity Response Ratio

## Class Name

`VelocityResponseRatio`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | VelocityResponseRatio.fromString(String string) |

## String

### Initialization Code

#### Example

```java
VelocityResponseRatio.fromString(
        "String0"
    )
```

