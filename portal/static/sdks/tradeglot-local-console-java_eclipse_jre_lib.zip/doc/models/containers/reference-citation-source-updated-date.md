
# Reference Citation Source Updated Date

## Class Name

`ReferenceCitationSourceUpdatedDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceCitationSourceUpdatedDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceCitationSourceUpdatedDate.fromString(
        "String0"
    )
```

