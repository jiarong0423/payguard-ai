
# Dispute Requirement Action

## Class Name

`DisputeRequirementAction`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeRequirementAction.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeRequirementAction.fromString(
        "String0"
    )
```

