
# Webhook Event Projection Resource Type

## Class Name

`WebhookEventProjectionResourceType`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookEventProjectionResourceType.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookEventProjectionResourceType.fromString(
        "String0"
    )
```

