
# Velocity Response Currency

## Class Name

`VelocityResponseCurrency`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | VelocityResponseCurrency.fromString(String string) |

## String

### Initialization Code

#### Example

```java
VelocityResponseCurrency.fromString(
        "String0"
    )
```

