
# Dispute Requirement Evidence Type

## Class Name

`DisputeRequirementEvidenceType`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeRequirementEvidenceType.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeRequirementEvidenceType.fromString(
        "String0"
    )
```

