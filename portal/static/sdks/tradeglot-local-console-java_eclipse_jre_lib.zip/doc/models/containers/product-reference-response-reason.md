
# Product Reference Response Reason

## Class Name

`ProductReferenceResponseReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Reason7Enum`](../../../doc/models/reason-7-enum.md) | ProductReferenceResponseReason.fromReason7(Reason7Enum reason7) |

## Reason7Enum

### Initialization Code

#### Example

```java
ProductReferenceResponseReason.fromReason7(
        Reason7Enum.NOTHING_TO_SEND
    )
```

