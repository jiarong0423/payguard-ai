
# Aup Acknowledge Response Expires At

## Class Name

`AupAcknowledgeResponseExpiresAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AupAcknowledgeResponseExpiresAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AupAcknowledgeResponseExpiresAt.fromString(
        "String0"
    )
```

