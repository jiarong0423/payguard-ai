
# Card Category

## Class Name

`CardCategory`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CardCategory.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CardCategory.fromString(
        "String0"
    )
```

