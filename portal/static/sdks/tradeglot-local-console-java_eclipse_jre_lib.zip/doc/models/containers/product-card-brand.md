
# Product Card Brand

## Class Name

`ProductCardBrand`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductCardBrand.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductCardBrand.fromString(
        "String0"
    )
```

