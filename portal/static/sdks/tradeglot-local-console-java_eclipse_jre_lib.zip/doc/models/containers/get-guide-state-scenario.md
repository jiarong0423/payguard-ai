
# Get Guide State Scenario

## Class Name

`GetGuideStateScenario`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) | GetGuideStateScenario.fromScenario1(Scenario1Enum scenario1) |

## Scenario1Enum

### Initialization Code

#### Example

```java
GetGuideStateScenario.fromScenario1(
        Scenario1Enum.PREFLIGHT
    )
```

