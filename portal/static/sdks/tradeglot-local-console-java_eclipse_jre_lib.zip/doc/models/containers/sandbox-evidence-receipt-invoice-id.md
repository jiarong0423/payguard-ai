
# Sandbox Evidence Receipt Invoice Id

## Class Name

`SandboxEvidenceReceiptInvoiceId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SandboxEvidenceReceiptInvoiceId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SandboxEvidenceReceiptInvoiceId.fromString(
        "String0"
    )
```

