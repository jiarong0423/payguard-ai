
# Country Rules Check Request Currency

## Class Name

`CountryRulesCheckRequestCurrency`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CountryRulesCheckRequestCurrency.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CountryRulesCheckRequestCurrency.fromString(
        "String0"
    )
```

