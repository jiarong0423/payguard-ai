
# Disputed Transaction Transaction Status

## Class Name

`DisputedTransactionTransactionStatus`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputedTransactionTransactionStatus.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputedTransactionTransactionStatus.fromString(
        "String0"
    )
```

