
# Guide State Response Form Result

## Class Name

`GuideStateResponseFormResult`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GuideFormResult`](../../../doc/models/guide-form-result.md) | GuideStateResponseFormResult.fromGuideFormResult(GuideFormResult guideFormResult) |

## GuideFormResult

### Initialization Code

#### Example

```java
GuideStateResponseFormResult.fromGuideFormResult(
        new GuideFormResult.Builder(
            "item2",
            false
        )
        .build()
    )
```

