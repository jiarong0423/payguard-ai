
# Guide Form Request Scenario

## Class Name

`GuideFormRequestScenario`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) | GuideFormRequestScenario.fromScenario1(Scenario1Enum scenario1) |

## Scenario1Enum

### Initialization Code

#### Example

```java
GuideFormRequestScenario.fromScenario1(
        Scenario1Enum.PREFLIGHT
    )
```

