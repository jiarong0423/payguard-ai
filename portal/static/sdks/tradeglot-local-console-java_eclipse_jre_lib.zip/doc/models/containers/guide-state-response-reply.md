
# Guide State Response Reply

## Class Name

`GuideStateResponseReply`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GuideReply`](../../../doc/models/guide-reply.md) | GuideStateResponseReply.fromGuideReply(GuideReply guideReply) |

## GuideReply

### Initialization Code

#### Example

```java
GuideStateResponseReply.fromGuideReply(
        new GuideReply.Builder(
            ChooserEnum.FORM,
            Arrays.asList(
                new GuideDropped.Builder(
                    "item2",
                    Reason6Enum.OTHER_PARTY
                )
                .build()
            ),
            GuideReplyFallbackReason.fromFallbackReason(
                FallbackReasonEnum.LATE
            ),
            false,
            TemplateEnum.REVIEW,
            "text0"
        )
        .build()
    )
```

