
# Guide State Response Flow Name

## Class Name

`GuideStateResponseFlowName`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | GuideStateResponseFlowName.fromString(String string) |

## String

### Initialization Code

#### Example

```java
GuideStateResponseFlowName.fromString(
        "String0"
    )
```

