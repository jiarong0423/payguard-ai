
# Analysis Reason

## Class Name

`AnalysisReason`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Reason5Enum`](../../../doc/models/reason-5-enum.md) | AnalysisReason.fromReason5(Reason5Enum reason5) |

## Reason5Enum

### Initialization Code

#### Example

```java
AnalysisReason.fromReason5(
        Reason5Enum.BUDGET
    )
```

