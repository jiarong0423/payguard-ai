
# Reference Citation Case Outcome

## Class Name

`ReferenceCitationCaseOutcome`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`CaseOutcomeEnum`](../../../doc/models/case-outcome-enum.md) | ReferenceCitationCaseOutcome.fromCaseOutcome(CaseOutcomeEnum caseOutcome) |

## CaseOutcomeEnum

### Initialization Code

#### Example

```java
ReferenceCitationCaseOutcome.fromCaseOutcome(
        CaseOutcomeEnum.SETTLEMENT_APPROVAL_NOT_FINAL_MERITS
    )
```

