
# Sandbox Evidence Receipt Paypal Debug Id

## Class Name

`SandboxEvidenceReceiptPaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SandboxEvidenceReceiptPaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SandboxEvidenceReceiptPaypalDebugId.fromString(
        "String0"
    )
```

