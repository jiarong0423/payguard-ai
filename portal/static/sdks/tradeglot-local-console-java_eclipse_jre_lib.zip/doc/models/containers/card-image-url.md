
# Card Image Url

## Class Name

`CardImageUrl`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CardImageUrl.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CardImageUrl.fromString(
        "String0"
    )
```

