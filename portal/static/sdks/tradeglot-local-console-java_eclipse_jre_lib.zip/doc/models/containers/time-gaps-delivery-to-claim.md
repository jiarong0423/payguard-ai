
# Time Gaps Delivery to Claim

## Class Name

`TimeGapsDeliveryToClaim`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | TimeGapsDeliveryToClaim.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
TimeGapsDeliveryToClaim.fromNumber(
        0
    )
```

