
# Reference Citation Decision Date

## Class Name

`ReferenceCitationDecisionDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceCitationDecisionDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceCitationDecisionDate.fromString(
        "String0"
    )
```

