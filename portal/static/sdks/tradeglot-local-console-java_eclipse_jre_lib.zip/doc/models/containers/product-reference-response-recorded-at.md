
# Product Reference Response Recorded At

## Class Name

`ProductReferenceResponseRecordedAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductReferenceResponseRecordedAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductReferenceResponseRecordedAt.fromString(
        "String0"
    )
```

