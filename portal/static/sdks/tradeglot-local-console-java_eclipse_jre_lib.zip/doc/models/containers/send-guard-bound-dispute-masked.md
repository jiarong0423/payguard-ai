
# Send Guard Bound Dispute Masked

## Class Name

`SendGuardBoundDisputeMasked`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SendGuardBoundDisputeMasked.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SendGuardBoundDisputeMasked.fromString(
        "String0"
    )
```

