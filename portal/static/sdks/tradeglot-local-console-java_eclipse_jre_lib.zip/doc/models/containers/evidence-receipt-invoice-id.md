
# Evidence Receipt Invoice Id

## Class Name

`EvidenceReceiptInvoiceId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceReceiptInvoiceId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceReceiptInvoiceId.fromString(
        "String0"
    )
```

