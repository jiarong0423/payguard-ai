
# Dispute Record Dispute State

## Class Name

`DisputeRecordDisputeState`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeRecordDisputeState.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeRecordDisputeState.fromString(
        "String0"
    )
```

