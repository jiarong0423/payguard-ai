
# Ai Usage Entry Tokens In

## Class Name

`AiUsageEntryTokensIn`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | AiUsageEntryTokensIn.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
AiUsageEntryTokensIn.fromNumber(
        0
    )
```

