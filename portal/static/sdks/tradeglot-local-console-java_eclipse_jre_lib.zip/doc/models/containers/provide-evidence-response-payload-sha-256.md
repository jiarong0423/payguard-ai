
# Provide Evidence Response Payload Sha 256

## Class Name

`ProvideEvidenceResponsePayloadSha256`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProvideEvidenceResponsePayloadSha256.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProvideEvidenceResponsePayloadSha256.fromString(
        "String0"
    )
```

