
# Dispute Detail Response Dispute Channel

## Class Name

`DisputeDetailResponseDisputeChannel`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeDetailResponseDisputeChannel.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeDetailResponseDisputeChannel.fromString(
        "String0"
    )
```

