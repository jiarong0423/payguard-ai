
# Policy Chunk Case Outcome

## Class Name

`PolicyChunkCaseOutcome`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`CaseOutcomeEnum`](../../../doc/models/case-outcome-enum.md) | PolicyChunkCaseOutcome.fromCaseOutcome(CaseOutcomeEnum caseOutcome) |

## CaseOutcomeEnum

### Initialization Code

#### Example

```java
PolicyChunkCaseOutcome.fromCaseOutcome(
        CaseOutcomeEnum.SETTLEMENT_APPROVAL_NOT_FINAL_MERITS
    )
```

