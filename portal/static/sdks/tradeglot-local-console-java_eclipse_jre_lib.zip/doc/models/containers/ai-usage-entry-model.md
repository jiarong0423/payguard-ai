
# Ai Usage Entry Model

## Class Name

`AiUsageEntryModel`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AiUsageEntryModel.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AiUsageEntryModel.fromString(
        "String0"
    )
```

