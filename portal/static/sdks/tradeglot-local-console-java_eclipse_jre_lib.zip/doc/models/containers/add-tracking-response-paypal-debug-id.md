
# Add Tracking Response Paypal Debug Id

## Class Name

`AddTrackingResponsePaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AddTrackingResponsePaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AddTrackingResponsePaypalDebugId.fromString(
        "String0"
    )
```

