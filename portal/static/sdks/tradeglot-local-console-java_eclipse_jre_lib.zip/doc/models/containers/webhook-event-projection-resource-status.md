
# Webhook Event Projection Resource Status

## Class Name

`WebhookEventProjectionResourceStatus`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookEventProjectionResourceStatus.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookEventProjectionResourceStatus.fromString(
        "String0"
    )
```

