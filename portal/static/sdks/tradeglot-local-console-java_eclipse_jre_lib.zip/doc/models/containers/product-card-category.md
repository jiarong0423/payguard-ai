
# Product Card Category

## Class Name

`ProductCardCategory`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductCardCategory.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductCardCategory.fromString(
        "String0"
    )
```

