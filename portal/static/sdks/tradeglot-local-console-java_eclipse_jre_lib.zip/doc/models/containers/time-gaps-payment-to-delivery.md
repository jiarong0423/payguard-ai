
# Time Gaps Payment to Delivery

## Class Name

`TimeGapsPaymentToDelivery`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | TimeGapsPaymentToDelivery.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
TimeGapsPaymentToDelivery.fromNumber(
        0
    )
```

