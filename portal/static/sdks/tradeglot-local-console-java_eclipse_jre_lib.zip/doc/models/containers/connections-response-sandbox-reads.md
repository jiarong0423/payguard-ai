
# Connections Response Sandbox Reads

## Class Name

`ConnectionsResponseSandboxReads`

## Cases

| Type | Factory Method |
|  --- | --- |
| `boolean` | ConnectionsResponseSandboxReads.fromBoolean(boolean mBoolean) |

## boolean

### Initialization Code

#### Example

```java
ConnectionsResponseSandboxReads.fromBoolean(
        false
    )
```

