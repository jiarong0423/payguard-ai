
# Time Evidence Events

## Class Name

`TimeEvidenceEvents`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`MessageTimeEvent`](../../../doc/models/message-time-event.md) | TimeEvidenceEvents.fromMessageTimeEvent(MessageTimeEvent messageTimeEvent) |
| [`TimeEvent`](../../../doc/models/time-event.md) | TimeEvidenceEvents.fromTimeEvent(TimeEvent timeEvent) |

## MessageTimeEvent

### Initialization Code

#### Example

```java
TimeEvidenceEvents.fromMessageTimeEvent(
        new MessageTimeEvent.Builder(
            "at4",
            ChannelEnum.EMAIL,
            DirectionEnum.INBOUND,
            "MESSAGE",
            "message_digest2",
            "SELLER_PROVIDED_UNVERIFIED",
            TopicEnum.ORDER_DETAILS_PROVIDED
        )
        .build()
    )
```

## TimeEvent

### Initialization Code

#### Example

```java
TimeEvidenceEvents.fromTimeEvent(
        new TimeEvent.Builder(
            "at2",
            KindEnum.DELIVERY,
            Source5Enum.PROVIDER
        )
        .build()
    )
```

