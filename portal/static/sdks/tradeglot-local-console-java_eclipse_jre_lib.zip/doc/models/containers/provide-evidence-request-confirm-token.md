
# Provide Evidence Request Confirm Token

## Class Name

`ProvideEvidenceRequestConfirmToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProvideEvidenceRequestConfirmToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProvideEvidenceRequestConfirmToken.fromString(
        "String0"
    )
```

