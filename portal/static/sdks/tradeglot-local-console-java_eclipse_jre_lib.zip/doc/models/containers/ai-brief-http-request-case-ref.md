
# Ai Brief Http Request Case Ref

## Class Name

`AiBriefHttpRequestCaseRef`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AiBriefHttpRequestCaseRef.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AiBriefHttpRequestCaseRef.fromString(
        "String0"
    )
```

