
# Paypal Status Response Last Verified At

## Class Name

`PaypalStatusResponseLastVerifiedAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | PaypalStatusResponseLastVerifiedAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
PaypalStatusResponseLastVerifiedAt.fromString(
        "String0"
    )
```

