
# Send Guard Sending Account Masked

## Class Name

`SendGuardSendingAccountMasked`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | SendGuardSendingAccountMasked.fromString(String string) |

## String

### Initialization Code

#### Example

```java
SendGuardSendingAccountMasked.fromString(
        "String0"
    )
```

