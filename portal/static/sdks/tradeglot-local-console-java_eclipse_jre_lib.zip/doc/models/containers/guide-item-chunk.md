
# Guide Item Chunk

## Class Name

`GuideItemChunk`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | GuideItemChunk.fromString(String string) |

## String

### Initialization Code

#### Example

```java
GuideItemChunk.fromString(
        "String0"
    )
```

