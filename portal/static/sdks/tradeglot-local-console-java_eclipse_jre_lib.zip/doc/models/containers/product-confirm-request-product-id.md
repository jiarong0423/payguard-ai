
# Product Confirm Request Product Id

## Class Name

`ProductConfirmRequestProductId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ProductConfirmRequestProductId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ProductConfirmRequestProductId.fromString(
        "String0"
    )
```

