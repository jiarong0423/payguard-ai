
# Dispute Detail Response Seller Response Due Date

## Class Name

`DisputeDetailResponseSellerResponseDueDate`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeDetailResponseSellerResponseDueDate.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeDetailResponseSellerResponseDueDate.fromString(
        "String0"
    )
```

