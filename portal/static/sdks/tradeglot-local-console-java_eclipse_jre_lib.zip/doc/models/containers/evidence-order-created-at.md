
# Evidence Order Created At

## Class Name

`EvidenceOrderCreatedAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceOrderCreatedAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceOrderCreatedAt.fromString(
        "String0"
    )
```

