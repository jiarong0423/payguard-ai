
# Tracking Info Carrier Name Other

## Class Name

`TrackingInfoCarrierNameOther`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | TrackingInfoCarrierNameOther.fromString(String string) |

## String

### Initialization Code

#### Example

```java
TrackingInfoCarrierNameOther.fromString(
        "String0"
    )
```

