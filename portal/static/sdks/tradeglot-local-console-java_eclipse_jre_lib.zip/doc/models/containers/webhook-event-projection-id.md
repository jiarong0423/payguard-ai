
# Webhook Event Projection Id

## Class Name

`WebhookEventProjectionId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | WebhookEventProjectionId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
WebhookEventProjectionId.fromString(
        "String0"
    )
```

