
# Card Brand

## Class Name

`CardBrand`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CardBrand.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CardBrand.fromString(
        "String0"
    )
```

