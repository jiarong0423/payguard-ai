
# Country Rules Check Request Amount

## Class Name

`CountryRulesCheckRequestAmount`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | CountryRulesCheckRequestAmount.fromString(String string) |

## String

### Initialization Code

#### Example

```java
CountryRulesCheckRequestAmount.fromString(
        "String0"
    )
```

