
# Signal Confidence

## Class Name

`SignalConfidence`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`ConfidenceEnum`](../../../doc/models/confidence-enum.md) | SignalConfidence.fromConfidence(ConfidenceEnum confidence) |

## ConfidenceEnum

### Initialization Code

#### Example

```java
SignalConfidence.fromConfidence(
        ConfidenceEnum.HIGH
    )
```

