
# Guide Form Request Item

## Class Name

`GuideFormRequestItem`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | GuideFormRequestItem.fromString(String string) |

## String

### Initialization Code

#### Example

```java
GuideFormRequestItem.fromString(
        "String0"
    )
```

