
# Evidence Delivered At

## Class Name

`EvidenceDeliveredAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceDeliveredAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceDeliveredAt.fromString(
        "String0"
    )
```

