
# Time Gaps Payment to Order Record

## Class Name

`TimeGapsPaymentToOrderRecord`

## Cases

| Type | Factory Method |
|  --- | --- |
| `int` | TimeGapsPaymentToOrderRecord.fromNumber(int number) |

## int

### Initialization Code

#### Example

```java
TimeGapsPaymentToOrderRecord.fromNumber(
        0
    )
```

