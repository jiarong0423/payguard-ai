
# Send Guard Send Refusal

## Class Name

`SendGuardSendRefusal`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`SendRefusalEnum`](../../../doc/models/send-refusal-enum.md) | SendGuardSendRefusal.fromSendRefusal(SendRefusalEnum sendRefusal) |

## SendRefusalEnum

### Initialization Code

#### Example

```java
SendGuardSendRefusal.fromSendRefusal(
        SendRefusalEnum.ACCOUNT_IDENTITY_UNKNOWN
    )
```

