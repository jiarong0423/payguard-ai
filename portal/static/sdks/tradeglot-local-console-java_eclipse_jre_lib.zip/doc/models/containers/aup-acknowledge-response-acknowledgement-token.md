
# Aup Acknowledge Response Acknowledgement Token

## Class Name

`AupAcknowledgeResponseAcknowledgementToken`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | AupAcknowledgeResponseAcknowledgementToken.fromString(String string) |

## String

### Initialization Code

#### Example

```java
AupAcknowledgeResponseAcknowledgementToken.fromString(
        "String0"
    )
```

