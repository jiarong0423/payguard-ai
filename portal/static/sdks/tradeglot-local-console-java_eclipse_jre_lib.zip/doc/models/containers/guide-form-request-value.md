
# Guide Form Request Value

## Class Name

`GuideFormRequestValue`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | GuideFormRequestValue.fromString(String string) |

## String

### Initialization Code

#### Example

```java
GuideFormRequestValue.fromString(
        "String0"
    )
```

