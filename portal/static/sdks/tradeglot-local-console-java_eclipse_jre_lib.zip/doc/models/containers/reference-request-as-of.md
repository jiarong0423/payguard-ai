
# Reference Request as Of

## Class Name

`ReferenceRequestAsOf`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | ReferenceRequestAsOf.fromString(String string) |

## String

### Initialization Code

#### Example

```java
ReferenceRequestAsOf.fromString(
        "String0"
    )
```

