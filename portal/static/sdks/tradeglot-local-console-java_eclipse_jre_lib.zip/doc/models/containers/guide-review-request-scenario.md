
# Guide Review Request Scenario

## Class Name

`GuideReviewRequestScenario`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) | GuideReviewRequestScenario.fromScenario1(Scenario1Enum scenario1) |

## Scenario1Enum

### Initialization Code

#### Example

```java
GuideReviewRequestScenario.fromScenario1(
        Scenario1Enum.PREFLIGHT
    )
```

