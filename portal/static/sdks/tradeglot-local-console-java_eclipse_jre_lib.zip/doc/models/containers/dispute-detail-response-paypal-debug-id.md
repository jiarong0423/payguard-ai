
# Dispute Detail Response Paypal Debug Id

## Class Name

`DisputeDetailResponsePaypalDebugId`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | DisputeDetailResponsePaypalDebugId.fromString(String string) |

## String

### Initialization Code

#### Example

```java
DisputeDetailResponsePaypalDebugId.fromString(
        "String0"
    )
```

