
# Evidence Opened At

## Class Name

`EvidenceOpenedAt`

## Cases

| Type | Factory Method |
|  --- | --- |
| `String` | EvidenceOpenedAt.fromString(String string) |

## String

### Initialization Code

#### Example

```java
EvidenceOpenedAt.fromString(
        "String0"
    )
```

