
# Guide Start Request Goods Type

## Class Name

`GuideStartRequestGoodsType`

## Cases

| Type | Factory Method |
|  --- | --- |
| [`GoodsTypeEnum`](../../../doc/models/goods-type-enum.md) | GuideStartRequestGoodsType.fromGoodsType(GoodsTypeEnum goodsType) |

## GoodsTypeEnum

### Initialization Code

#### Example

```java
GuideStartRequestGoodsType.fromGoodsType(
        GoodsTypeEnum.PHYSICAL
    )
```

