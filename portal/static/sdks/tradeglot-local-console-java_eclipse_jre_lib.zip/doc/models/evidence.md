
# Evidence

Evidence.

## Structure

`Evidence`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierStatus` | [`EvidenceCarrierStatus`](../../doc/models/containers/evidence-carrier-status.md) | Optional | This is a container for any-of cases. | EvidenceCarrierStatus getCarrierStatus() | setCarrierStatus(EvidenceCarrierStatus carrierStatus) |
| `DeliveredAt` | [`EvidenceDeliveredAt`](../../doc/models/containers/evidence-delivered-at.md) | Optional | This is a container for any-of cases. | EvidenceDeliveredAt getDeliveredAt() | setDeliveredAt(EvidenceDeliveredAt deliveredAt) |
| `EvidenceSource` | `String` | Required, Constant | Evidence source.<br><br>**Value**: `"synthetic"` | String getEvidenceSource() | setEvidenceSource(String evidenceSource) |
| `OpenedAt` | [`EvidenceOpenedAt`](../../doc/models/containers/evidence-opened-at.md) | Optional | This is a container for any-of cases. | EvidenceOpenedAt getOpenedAt() | setOpenedAt(EvidenceOpenedAt openedAt) |
| `OrderCreatedAt` | [`EvidenceOrderCreatedAt`](../../doc/models/containers/evidence-order-created-at.md) | Optional | This is a container for any-of cases. | EvidenceOrderCreatedAt getOrderCreatedAt() | setOrderCreatedAt(EvidenceOrderCreatedAt orderCreatedAt) |
| `Reason` | [`EvidenceReason`](../../doc/models/containers/evidence-reason.md) | Optional | This is a container for any-of cases. | EvidenceReason getReason() | setReason(EvidenceReason reason) |

## Example

```java
import m18000.m0.m0.m127.models.Evidence;
import m18000.m0.m0.m127.models.containers.EvidenceCarrierStatus;
import m18000.m0.m0.m127.models.containers.EvidenceDeliveredAt;
import m18000.m0.m0.m127.models.containers.EvidenceOpenedAt;
import m18000.m0.m0.m127.models.containers.EvidenceOrderCreatedAt;
import m18000.m0.m0.m127.models.containers.EvidenceReason;

Evidence evidence = new Evidence.Builder(
    "synthetic"
)
.carrierStatus(EvidenceCarrierStatus.fromString(
        "String5"
    ))
.deliveredAt(EvidenceDeliveredAt.fromString(
        "String1"
    ))
.openedAt(EvidenceOpenedAt.fromString(
        "String1"
    ))
.orderCreatedAt(EvidenceOrderCreatedAt.fromString(
        "String3"
    ))
.reason(EvidenceReason.fromString(
        "String3"
    ))
.build();
```

