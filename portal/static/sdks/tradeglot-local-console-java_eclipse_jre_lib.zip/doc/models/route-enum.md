
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |
| `SERVICE` |
| `UNKNOWN` |

## Example

```java
import m18000.m0.m0.m127.models.RouteEnum;

RouteEnum route = RouteEnum.PHYSICAL;
```

