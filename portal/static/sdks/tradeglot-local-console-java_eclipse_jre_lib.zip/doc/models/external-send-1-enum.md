
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```java
import m18000.m0.m0.m127.models.ExternalSend1Enum;

ExternalSend1Enum externalSend1 = ExternalSend1Enum.FROZEN;
```

