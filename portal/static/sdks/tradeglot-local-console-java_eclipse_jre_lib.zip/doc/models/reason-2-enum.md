
# Reason 2 Enum

Reason.

## Enumeration

`Reason2Enum`

## Fields

| Name |
|  --- |
| `MERCHANDISE_OR_SERVICE_NOT_RECEIVED` |
| `MERCHANDISE_OR_SERVICE_NOT_AS_DESCRIBED` |
| `UNAUTHORISED` |
| `CREDIT_NOT_PROCESSED` |
| `DUPLICATE_TRANSACTION` |
| `INCORRECT_AMOUNT` |
| `PAYMENT_BY_OTHER_MEANS` |
| `CANCELED_RECURRING_BILLING` |
| `OTHER` |

## Example

```java
import m18000.m0.m0.m127.models.Reason2Enum;

Reason2Enum reason2 = Reason2Enum.CANCELED_RECURRING_BILLING;
```

