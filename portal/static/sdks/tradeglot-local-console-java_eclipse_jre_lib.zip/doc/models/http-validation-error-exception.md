
# HTTP Validation Error Exception

HTTPValidationError.

## Structure

`HTTPValidationErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Detail` | [`List<ValidationError>`](../../doc/models/validation-error.md) | Optional | Detail. | List<ValidationError> getDetail() | setDetail(List<ValidationError> detail) |

## Example

```java
try {
    // make the API call
} catch (HTTPValidationErrorException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```

