
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `EXACT` |
| `CLOSE` |

## Example

```java
import m18000.m0.m0.m127.models.MatchTypeEnum;

MatchTypeEnum matchType = MatchTypeEnum.EXACT;
```

