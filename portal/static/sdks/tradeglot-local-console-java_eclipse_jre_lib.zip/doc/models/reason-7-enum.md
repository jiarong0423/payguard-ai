
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `NOT_RECORDED` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```java
import m18000.m0.m0.m127.models.Reason7Enum;

Reason7Enum reason7 = Reason7Enum.NOTHING_TO_SEND;
```

