
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```java
import m18000.m0.m0.m127.models.DueStateEnum;

DueStateEnum dueState = DueStateEnum.OPEN;
```

