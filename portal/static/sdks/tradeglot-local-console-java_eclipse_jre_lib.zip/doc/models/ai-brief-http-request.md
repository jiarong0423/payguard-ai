
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CaseRef` | [`AiBriefHttpRequestCaseRef`](../../doc/models/containers/ai-brief-http-request-case-ref.md) | Optional | This is a container for any-of cases. | AiBriefHttpRequestCaseRef getCaseRef() | setCaseRef(AiBriefHttpRequestCaseRef caseRef) |
| `Stage` | [`StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. | StageEnum getStage() | setStage(StageEnum stage) |

## Example

```java
import m18000.m0.m0.m127.models.AiBriefHttpRequest;
import m18000.m0.m0.m127.models.StageEnum;
import m18000.m0.m0.m127.models.containers.AiBriefHttpRequestCaseRef;

AiBriefHttpRequest aiBriefHttpRequest = new AiBriefHttpRequest.Builder(
    StageEnum.VELOCITY_GUARD
)
.caseRef(AiBriefHttpRequestCaseRef.fromString(
        "String9"
    ))
.build();
```

