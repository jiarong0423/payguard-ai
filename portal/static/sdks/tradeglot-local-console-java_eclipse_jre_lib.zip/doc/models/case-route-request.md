
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Text` | `String` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` | String getText() | setText(String text) |

## Example

```java
import m18000.m0.m0.m127.models.CaseRouteRequest;

CaseRouteRequest caseRouteRequest = new CaseRouteRequest.Builder(
    "text6"
)
.build();
```

