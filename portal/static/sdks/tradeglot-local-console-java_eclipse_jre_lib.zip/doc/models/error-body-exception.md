
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. | Error getError() | setError(Error error) |

## Example

```java
try {
    // make the API call
} catch (ErrorBodyException e) {
    e.printStackTrace();
} catch (ApiException e) {
    e.printStackTrace();
}
```

