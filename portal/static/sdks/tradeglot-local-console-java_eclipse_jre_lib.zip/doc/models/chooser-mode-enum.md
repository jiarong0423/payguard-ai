
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `KEYWORD` |
| `GEMINI` |

## Example

```java
import m18000.m0.m0.m127.models.ChooserModeEnum;

ChooserModeEnum chooserMode = ChooserModeEnum.KEYWORD;
```

