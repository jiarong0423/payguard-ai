
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |

## Example

```java
import m18000.m0.m0.m127.models.GoodsTypeEnum;

GoodsTypeEnum goodsType = GoodsTypeEnum.PHYSICAL;
```

