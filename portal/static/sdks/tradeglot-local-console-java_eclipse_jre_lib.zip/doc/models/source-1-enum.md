
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SESSION_MEMORY` |
| `HOSTED_DEMO` |

## Example

```java
import m18000.m0.m0.m127.models.Source1Enum;

Source1Enum source1 = Source1Enum.SESSION_MEMORY;
```

