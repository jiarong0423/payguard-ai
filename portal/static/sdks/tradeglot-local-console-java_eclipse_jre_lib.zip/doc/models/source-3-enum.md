
# Source 3 Enum

Source.

## Enumeration

`Source3Enum`

## Fields

| Name |
|  --- |
| `REQUESTED_FROM_SELLER` |
| `REQUESTED_FROM_BUYER` |
| `SUBMITTED_BY_SELLER` |
| `SUBMITTED_BY_BUYER` |
| `SUBMITTED_BY_PARTNER` |
| `UNKNOWN` |

## Example

```java
import m18000.m0.m0.m127.models.Source3Enum;

Source3Enum source3 = Source3Enum.REQUESTED_FROM_SELLER;
```

