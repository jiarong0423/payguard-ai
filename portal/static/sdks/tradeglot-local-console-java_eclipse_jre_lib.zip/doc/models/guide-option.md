
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Label` | `String` | Required | Label. | String getLabel() | setLabel(String label) |
| `Value` | `String` | Required | Value. | String getValue() | setValue(String value) |

## Example

```java
import m18000.m0.m0.m127.models.GuideOption;

GuideOption guideOption = new GuideOption.Builder(
    "label2",
    "value4"
)
.build();
```

