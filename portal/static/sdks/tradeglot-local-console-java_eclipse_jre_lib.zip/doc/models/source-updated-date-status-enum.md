
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `MISSING` |

## Example

```java
import m18000.m0.m0.m127.models.SourceUpdatedDateStatusEnum;

SourceUpdatedDateStatusEnum sourceUpdatedDateStatus = SourceUpdatedDateStatusEnum.DOCUMENT_STATED;
```

