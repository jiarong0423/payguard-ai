
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `ANALYSING` |
| `REPLACED` |
| `KEPT` |

## Example

```java
import m18000.m0.m0.m127.models.Status8Enum;

Status8Enum status8 = Status8Enum.REPLACED;
```

