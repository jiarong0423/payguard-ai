
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```java
import m18000.m0.m0.m127.models.Source10Enum;

Source10Enum source10 = Source10Enum.CHANNEL3_LIVE;
```

