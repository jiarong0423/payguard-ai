
# Material Type 1 Enum

Material type.

## Enumeration

`MaterialType1Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |
| `PUBLIC_COURT_ORDER_COPY` |

## Example

```java
import m18000.m0.m0.m127.models.MaterialType1Enum;

MaterialType1Enum materialType1 = MaterialType1Enum.OFFICIAL_POLICY;
```

