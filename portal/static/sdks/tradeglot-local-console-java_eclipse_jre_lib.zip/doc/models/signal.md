
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Category` | [`SignalCategory`](../../doc/models/containers/signal-category.md) | Optional | This is a container for any-of cases. | SignalCategory getCategory() | setCategory(SignalCategory category) |
| `Confidence` | [`SignalConfidence`](../../doc/models/containers/signal-confidence.md) | Optional | This is a container for any-of cases. | SignalConfidence getConfidence() | setConfidence(SignalConfidence confidence) |
| `Source` | [`Source2Enum`](../../doc/models/source-2-enum.md) | Optional | Source. | Source2Enum getSource() | setSource(Source2Enum source) |

## Example

```java
import m18000.m0.m0.m127.models.ConfidenceEnum;
import m18000.m0.m0.m127.models.Signal;
import m18000.m0.m0.m127.models.Source2Enum;
import m18000.m0.m0.m127.models.containers.SignalCategory;
import m18000.m0.m0.m127.models.containers.SignalConfidence;

Signal signal = new Signal.Builder()
    .category(SignalCategory.fromString(
        "String1"
    ))
    .confidence(SignalConfidence.fromConfidence(
        ConfidenceEnum.HIGH
    ))
    .source(Source2Enum.CHANNEL3)
    .build();
```

