
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```java
import m18000.m0.m0.m127.models.ExternalSendEnum;

ExternalSendEnum externalSend = ExternalSendEnum.FROZEN;
```

