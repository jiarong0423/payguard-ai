
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Item` | `String` | Optional | Item. | String getItem() | setItem(String item) |
| `Valid` | `Boolean` | Optional | Valid. | Boolean getValid() | setValid(Boolean valid) |

## Example

```java
import m18000.m0.m0.m127.models.FormResult;

FormResult formResult = new FormResult.Builder()
    .item("item8")
    .valid(false)
    .build();
```

