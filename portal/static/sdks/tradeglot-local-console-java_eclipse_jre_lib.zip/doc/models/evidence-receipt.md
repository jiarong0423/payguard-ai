
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Action` | [`ActionEnum`](../../doc/models/action-enum.md) | Optional | Action. | ActionEnum getAction() | setAction(ActionEnum action) |
| `Environment` | [`EnvironmentEnum`](../../doc/models/environment-enum.md) | Optional | Environment. | EnvironmentEnum getEnvironment() | setEnvironment(EnvironmentEnum environment) |
| `EvidenceClass` | [`EvidenceClass3Enum`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. | EvidenceClass3Enum getEvidenceClass() | setEvidenceClass(EvidenceClass3Enum evidenceClass) |
| `ExternalSend` | [`ExternalSend1Enum`](../../doc/models/external-send-1-enum.md) | Optional | External send. | ExternalSend1Enum getExternalSend() | setExternalSend(ExternalSend1Enum externalSend) |
| `InvoiceId` | [`EvidenceReceiptInvoiceId`](../../doc/models/containers/evidence-receipt-invoice-id.md) | Optional | This is a container for any-of cases. | EvidenceReceiptInvoiceId getInvoiceId() | setInvoiceId(EvidenceReceiptInvoiceId invoiceId) |
| `ObservedAt` | `String` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` | String getObservedAt() | setObservedAt(String observedAt) |
| `PaypalDebugId` | [`EvidenceReceiptPaypalDebugId`](../../doc/models/containers/evidence-receipt-paypal-debug-id.md) | Optional | This is a container for any-of cases. | EvidenceReceiptPaypalDebugId getPaypalDebugId() | setPaypalDebugId(EvidenceReceiptPaypalDebugId paypalDebugId) |
| `ProofKind` | [`ProofKindEnum`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. | ProofKindEnum getProofKind() | setProofKind(ProofKindEnum proofKind) |
| `SchemaVersion` | [`SchemaVersion1Enum`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. | SchemaVersion1Enum getSchemaVersion() | setSchemaVersion(SchemaVersion1Enum schemaVersion) |
| `SeparateGetReadback` | `Boolean` | Optional | Separate get readback. | Boolean getSeparateGetReadback() | setSeparateGetReadback(Boolean separateGetReadback) |
| `Status` | [`Status10Enum`](../../doc/models/status-10-enum.md) | Optional | Status. | Status10Enum getStatus() | setStatus(Status10Enum status) |

## Example

```java
import m18000.m0.m0.m127.models.ActionEnum;
import m18000.m0.m0.m127.models.EnvironmentEnum;
import m18000.m0.m0.m127.models.EvidenceClass3Enum;
import m18000.m0.m0.m127.models.EvidenceReceipt;
import m18000.m0.m0.m127.models.ExternalSend1Enum;
import m18000.m0.m0.m127.models.containers.EvidenceReceiptInvoiceId;

EvidenceReceipt evidenceReceipt = new EvidenceReceipt.Builder()
    .action(ActionEnum.OAUTH_CONNECT)
    .environment(EnvironmentEnum.SANDBOX)
    .evidenceClass(EvidenceClass3Enum.AUTHENTIC_SANDBOX_RESPONSE)
    .externalSend(ExternalSend1Enum.FROZEN)
    .invoiceId(EvidenceReceiptInvoiceId.fromString(
        "String1"
    ))
    .build();
```

