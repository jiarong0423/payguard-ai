
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `PAYGUARDFIXEDSYNTHETICBRIEFV1` |
| `PAYGUARDSESSIONBRIEFV1` |

## Example

```java
import m18000.m0.m0.m127.models.FixtureIdEnum;

FixtureIdEnum fixtureId = FixtureIdEnum.PAYGUARDFIXEDSYNTHETICBRIEFV1;
```

