
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```java
import m18000.m0.m0.m127.models.ReasonEnum;

ReasonEnum reason = ReasonEnum.CONTRACT_REJECTED;
```

