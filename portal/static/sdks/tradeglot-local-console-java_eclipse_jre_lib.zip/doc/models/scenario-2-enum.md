
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```java
import m18000.m0.m0.m127.models.Scenario2Enum;

Scenario2Enum scenario2 = Scenario2Enum.VELOCITY;
```

