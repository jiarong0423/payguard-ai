
# Guide Subtraction

GuideSubtraction.

## Structure

`GuideSubtraction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Left` | `int` | Required | Left. | int getLeft() | setLeft(int left) |
| `Needed` | `int` | Required | Needed. | int getNeeded() | setNeeded(int needed) |
| `Taken` | `int` | Required | Taken. | int getTaken() | setTaken(int taken) |
| `Text` | `String` | Required | Text. | String getText() | setText(String text) |

## Example

```java
import m18000.m0.m0.m127.models.GuideSubtraction;

GuideSubtraction guideSubtraction = new GuideSubtraction.Builder(
    18,
    112,
    124,
    "text8"
)
.build();
```

