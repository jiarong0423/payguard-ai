
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NOT_CONFIGURED` |
| `DISCONNECTED` |
| `CONNECTED` |
| `ERROR` |

## Example

```java
import m18000.m0.m0.m127.models.Status11Enum;

Status11Enum status11 = Status11Enum.CONNECTED;
```

