
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Item` | `String` | Required | Item. | String getItem() | setItem(String item) |
| `Valid` | `boolean` | Required | Valid. | boolean getValid() | setValid(boolean valid) |

## Example

```java
import m18000.m0.m0.m127.models.GuideFormResult;

GuideFormResult guideFormResult = new GuideFormResult.Builder(
    "item2",
    false
)
.build();
```

