
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `NAME` |
| `ADDRESS` |
| `EMAIL` |

## Example

```java
import m18000.m0.m0.m127.models.FieldEnum;

FieldEnum field = FieldEnum.ADDRESS;
```

