
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `MANUAL_REVIEW` |
| `REVIEW_EVIDENCE` |

## Example

```java
import m18000.m0.m0.m127.models.Status5Enum;

Status5Enum status5 = Status5Enum.MANUAL_REVIEW;
```

