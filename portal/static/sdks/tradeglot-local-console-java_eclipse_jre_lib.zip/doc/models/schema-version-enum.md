
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `ENUM_PAYGUARDTIME_EVIDENCEV1` |

## Example

```java
import m18000.m0.m0.m127.models.SchemaVersionEnum;

SchemaVersionEnum schemaVersion = SchemaVersionEnum.ENUM_PAYGUARDTIME_EVIDENCEV1;
```

