
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `REFERENCES_FOUND` |
| `EVIDENCE_MISSING` |

## Example

```java
import m18000.m0.m0.m127.models.Status13Enum;

Status13Enum status13 = Status13Enum.REFERENCES_FOUND;
```

