
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```java
import m18000.m0.m0.m127.models.Source5Enum;

Source5Enum source5 = Source5Enum.PROVIDER;
```

