
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |

## Example

```java
import m18000.m0.m0.m127.models.EnvironmentEnum;

EnvironmentEnum environment = EnvironmentEnum.SANDBOX;
```

