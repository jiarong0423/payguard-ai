
# Dispute Evidence Row

DisputeEvidenceRow.

## Structure

`DisputeEvidenceRow`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Action` | [`DisputeEvidenceRowAction`](../../doc/models/containers/dispute-evidence-row-action.md) | Optional | This is a container for any-of cases. | DisputeEvidenceRowAction getAction() | setAction(DisputeEvidenceRowAction action) |
| `Date` | [`DisputeEvidenceRowDate`](../../doc/models/containers/dispute-evidence-row-date.md) | Optional | This is a container for any-of cases. | DisputeEvidenceRowDate getDate() | setDate(DisputeEvidenceRowDate date) |
| `EvidenceType` | `String` | Required | Evidence type.<br><br>**Constraints**: *Pattern*: `^[A-Z][A-Z0-9_]{0,63}$` | String getEvidenceType() | setEvidenceType(String evidenceType) |
| `Source` | [`Source3Enum`](../../doc/models/source-3-enum.md) | Required | Source. | Source3Enum getSource() | setSource(Source3Enum source) |

## Example

```java
import m18000.m0.m0.m127.models.DisputeEvidenceRow;
import m18000.m0.m0.m127.models.Source3Enum;
import m18000.m0.m0.m127.models.containers.DisputeEvidenceRowAction;
import m18000.m0.m0.m127.models.containers.DisputeEvidenceRowDate;

DisputeEvidenceRow disputeEvidenceRow = new DisputeEvidenceRow.Builder(
    "evidence_type8",
    Source3Enum.REQUESTED_FROM_SELLER
)
.action(DisputeEvidenceRowAction.fromString(
        "String7"
    ))
.date(DisputeEvidenceRowDate.fromString(
        "String3"
    ))
.build();
```

