
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLY_PRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOT_APPLICABLE` |

## Example

```java
import m18000.m0.m0.m127.models.Status9Enum;

Status9Enum status9 = Status9Enum.STRUCTURALLY_PRESENT;
```

