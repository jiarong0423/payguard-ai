
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```java
import m18000.m0.m0.m127.models.Status10Enum;

Status10Enum status10 = Status10Enum.CONNECTED;
```

