
# Webhook Event Projection

All that is kept after a SUCCESS: identifiers and status only, no amounts, payer data, links or summary.

## Structure

`WebhookEventProjection`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EventType` | [`WebhookEventProjectionEventType`](../../doc/models/containers/webhook-event-projection-event-type.md) | Required | This is a container for any-of cases. | WebhookEventProjectionEventType getEventType() | setEventType(WebhookEventProjectionEventType eventType) |
| `Id` | [`WebhookEventProjectionId`](../../doc/models/containers/webhook-event-projection-id.md) | Required | This is a container for any-of cases. | WebhookEventProjectionId getId() | setId(WebhookEventProjectionId id) |
| `ResourceId` | [`WebhookEventProjectionResourceId`](../../doc/models/containers/webhook-event-projection-resource-id.md) | Required | This is a container for any-of cases. | WebhookEventProjectionResourceId getResourceId() | setResourceId(WebhookEventProjectionResourceId resourceId) |
| `ResourceStatus` | [`WebhookEventProjectionResourceStatus`](../../doc/models/containers/webhook-event-projection-resource-status.md) | Required | This is a container for any-of cases. | WebhookEventProjectionResourceStatus getResourceStatus() | setResourceStatus(WebhookEventProjectionResourceStatus resourceStatus) |
| `ResourceType` | [`WebhookEventProjectionResourceType`](../../doc/models/containers/webhook-event-projection-resource-type.md) | Required | This is a container for any-of cases. | WebhookEventProjectionResourceType getResourceType() | setResourceType(WebhookEventProjectionResourceType resourceType) |

## Example

```java
import m18000.m0.m0.m127.models.WebhookEventProjection;
import m18000.m0.m0.m127.models.containers.WebhookEventProjectionEventType;
import m18000.m0.m0.m127.models.containers.WebhookEventProjectionId;
import m18000.m0.m0.m127.models.containers.WebhookEventProjectionResourceId;
import m18000.m0.m0.m127.models.containers.WebhookEventProjectionResourceStatus;
import m18000.m0.m0.m127.models.containers.WebhookEventProjectionResourceType;

WebhookEventProjection webhookEventProjection = new WebhookEventProjection.Builder(
    WebhookEventProjectionEventType.fromString(
        "String9"
    ),
    WebhookEventProjectionId.fromString(
        "String9"
    ),
    WebhookEventProjectionResourceId.fromString(
        "String5"
    ),
    WebhookEventProjectionResourceStatus.fromString(
        "String1"
    ),
    WebhookEventProjectionResourceType.fromString(
        "String3"
    )
)
.build();
```

