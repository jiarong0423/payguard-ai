
# Tracker Batch

TrackerBatch.

## Structure

`TrackerBatch`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Trackers` | [`List<TrackerItem>`](../../doc/models/tracker-item.md) | Required | Trackers.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `1` | List<TrackerItem> getTrackers() | setTrackers(List<TrackerItem> trackers) |

## Example

```java
import java.util.Arrays;
import m18000.m0.m0.m127.models.CarrierEnum;
import m18000.m0.m0.m127.models.TrackerBatch;
import m18000.m0.m0.m127.models.TrackerItem;
import m18000.m0.m0.m127.models.containers.TrackerItemCarrierNameOther;

TrackerBatch trackerBatch = new TrackerBatch.Builder(
    Arrays.asList(
        new TrackerItem.Builder(
            CarrierEnum.JP_JAPANPOST,
            "SHIPPED",
            "tracking_number0",
            "transaction_id0"
        )
        .carrierNameOther(TrackerItemCarrierNameOther.fromString(
                "String5"
            ))
        .build()
    )
)
.build();
```

