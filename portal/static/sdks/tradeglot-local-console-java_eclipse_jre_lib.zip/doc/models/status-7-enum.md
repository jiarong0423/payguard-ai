
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NEEDS_REVIEW` |
| `DRAFT_READY` |
| `LOCAL_DRAFT_REVIEWED` |

## Example

```java
import m18000.m0.m0.m127.models.Status7Enum;

Status7Enum status7 = Status7Enum.NEEDS_REVIEW;
```

