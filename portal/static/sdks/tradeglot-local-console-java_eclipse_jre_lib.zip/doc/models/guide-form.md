
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. | Kind2Enum getKind() | setKind(Kind2Enum kind) |
| `Options` | [`List<GuideOption>`](../../doc/models/guide-option.md) | Required | Options. | List<GuideOption> getOptions() | setOptions(List<GuideOption> options) |
| `Placeholder` | [`GuideFormPlaceholder`](../../doc/models/containers/guide-form-placeholder.md) | Required | This is a container for any-of cases. | GuideFormPlaceholder getPlaceholder() | setPlaceholder(GuideFormPlaceholder placeholder) |

## Example

```java
import java.util.Arrays;
import m18000.m0.m0.m127.models.GuideForm;
import m18000.m0.m0.m127.models.GuideOption;
import m18000.m0.m0.m127.models.Kind2Enum;
import m18000.m0.m0.m127.models.containers.GuideFormPlaceholder;

GuideForm guideForm = new GuideForm.Builder(
    Kind2Enum.CHOICE,
    Arrays.asList(
        new GuideOption.Builder(
            "label2",
            "value4"
        )
        .build()
    ),
    GuideFormPlaceholder.fromString(
        "String3"
    )
)
.build();
```

