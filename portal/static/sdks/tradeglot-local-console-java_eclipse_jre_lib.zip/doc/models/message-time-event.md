
# Message Time Event

MessageTimeEvent.

## Structure

`MessageTimeEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `At` | `String` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` | String getAt() | setAt(String at) |
| `Channel` | [`ChannelEnum`](../../doc/models/channel-enum.md) | Required | Channel. | ChannelEnum getChannel() | setChannel(ChannelEnum channel) |
| `Direction` | [`DirectionEnum`](../../doc/models/direction-enum.md) | Required | Direction. | DirectionEnum getDirection() | setDirection(DirectionEnum direction) |
| `Kind` | `String` | Required, Constant | Kind.<br><br>**Value**: `"MESSAGE"` | String getKind() | setKind(String kind) |
| `MessageDigest` | `String` | Required | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` | String getMessageDigest() | setMessageDigest(String messageDigest) |
| `Source` | `String` | Required, Constant | Source.<br><br>**Value**: `"SELLER_PROVIDED_UNVERIFIED"` | String getSource() | setSource(String source) |
| `Topic` | [`TopicEnum`](../../doc/models/topic-enum.md) | Required | Topic. | TopicEnum getTopic() | setTopic(TopicEnum topic) |

## Example

```java
import m18000.m0.m0.m127.models.ChannelEnum;
import m18000.m0.m0.m127.models.DirectionEnum;
import m18000.m0.m0.m127.models.MessageTimeEvent;
import m18000.m0.m0.m127.models.TopicEnum;

MessageTimeEvent messageTimeEvent = new MessageTimeEvent.Builder(
    "at6",
    ChannelEnum.EMAIL,
    DirectionEnum.INBOUND,
    "MESSAGE",
    "message_digest4",
    "SELLER_PROVIDED_UNVERIFIED",
    TopicEnum.PAYMENT_NOTICE
)
.build();
```

