
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_STATED_IN_REVIEWED_DOCUMENT` |
| `NOT_APPLICABLE` |

## Example

```java
import m18000.m0.m0.m127.models.DecisionDateStatusEnum;

DecisionDateStatusEnum decisionDateStatus = DecisionDateStatusEnum.DOCUMENT_STATED;
```

