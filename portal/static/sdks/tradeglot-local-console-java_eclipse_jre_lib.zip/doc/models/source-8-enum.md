
# Source 8 Enum

Source.

## Enumeration

`Source8Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL` |
| `SUGGESTION` |

## Example

```java
import m18000.m0.m0.m127.models.Source8Enum;

Source8Enum source8 = Source8Enum.OFFICIAL;
```

