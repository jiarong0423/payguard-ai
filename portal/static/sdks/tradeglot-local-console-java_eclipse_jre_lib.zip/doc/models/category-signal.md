
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Category` | [`CategorySignalCategory`](../../doc/models/containers/category-signal-category.md) | Required | This is a container for any-of cases. | CategorySignalCategory getCategory() | setCategory(CategorySignalCategory category) |
| `Confidence` | [`CategorySignalConfidence`](../../doc/models/containers/category-signal-confidence.md) | Required | This is a container for any-of cases. | CategorySignalConfidence getConfidence() | setConfidence(CategorySignalConfidence confidence) |
| `Source` | `String` | Required, Constant | Source.<br><br>**Value**: `"channel3"` | String getSource() | setSource(String source) |

## Example

```java
import m18000.m0.m0.m127.models.CategorySignal;
import m18000.m0.m0.m127.models.ConfidenceEnum;
import m18000.m0.m0.m127.models.containers.CategorySignalCategory;
import m18000.m0.m0.m127.models.containers.CategorySignalConfidence;

CategorySignal categorySignal = new CategorySignal.Builder(
    CategorySignalCategory.fromString(
        "String1"
    ),
    CategorySignalConfidence.fromConfidence(
        ConfidenceEnum.HIGH
    ),
    "channel3"
)
.build();
```

