
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOT_PERFORMED` |
| `PERFORMED` |

## Example

```java
import m18000.m0.m0.m127.models.ProviderSubmissionEnum;

ProviderSubmissionEnum providerSubmission = ProviderSubmissionEnum.NOT_PERFORMED;
```

