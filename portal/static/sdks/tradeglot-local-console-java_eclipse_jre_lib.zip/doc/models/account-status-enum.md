
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```java
import m18000.m0.m0.m127.models.AccountStatusEnum;

AccountStatusEnum accountStatus = AccountStatusEnum.UNKNOWN;
```

