
# Dispute Record

DisputeRecord.

## Structure

`DisputeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CreateTime` | `String` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` | String getCreateTime() | setCreateTime(String createTime) |
| `DisputeAmount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. | ProviderMoney getDisputeAmount() | setDisputeAmount(ProviderMoney disputeAmount) |
| `DisputeId` | `String` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` | String getDisputeId() | setDisputeId(String disputeId) |
| `DisputeLifeCycleStage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. | DisputeLifeCycleStageEnum getDisputeLifeCycleStage() | setDisputeLifeCycleStage(DisputeLifeCycleStageEnum disputeLifeCycleStage) |
| `DisputeState` | [`DisputeRecordDisputeState`](../../doc/models/containers/dispute-record-dispute-state.md) | Optional | This is a container for any-of cases. | DisputeRecordDisputeState getDisputeState() | setDisputeState(DisputeRecordDisputeState disputeState) |
| `Reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. | Reason2Enum getReason() | setReason(Reason2Enum reason) |
| `SellerResponseDueDate` | [`DisputeRecordSellerResponseDueDate`](../../doc/models/containers/dispute-record-seller-response-due-date.md) | Optional | This is a container for any-of cases. | DisputeRecordSellerResponseDueDate getSellerResponseDueDate() | setSellerResponseDueDate(DisputeRecordSellerResponseDueDate sellerResponseDueDate) |
| `Status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. | Status3Enum getStatus() | setStatus(Status3Enum status) |
| `UpdateTime` | [`DisputeRecordUpdateTime`](../../doc/models/containers/dispute-record-update-time.md) | Optional | This is a container for any-of cases. | DisputeRecordUpdateTime getUpdateTime() | setUpdateTime(DisputeRecordUpdateTime updateTime) |

## Example

```java
import m18000.m0.m0.m127.models.DisputeLifeCycleStageEnum;
import m18000.m0.m0.m127.models.DisputeRecord;
import m18000.m0.m0.m127.models.ProviderMoney;
import m18000.m0.m0.m127.models.Reason2Enum;
import m18000.m0.m0.m127.models.Status3Enum;
import m18000.m0.m0.m127.models.containers.DisputeRecordDisputeState;
import m18000.m0.m0.m127.models.containers.DisputeRecordSellerResponseDueDate;
import m18000.m0.m0.m127.models.containers.DisputeRecordUpdateTime;

DisputeRecord disputeRecord = new DisputeRecord.Builder(
    "create_time0",
    new ProviderMoney.Builder(
        "currency_code6",
        "value0"
    )
    .build(),
    "dispute_id6",
    DisputeLifeCycleStageEnum.ARBITRATION,
    Reason2Enum.MERCHANDISE_OR_SERVICE_NOT_RECEIVED,
    Status3Enum.OPEN
)
.disputeState(DisputeRecordDisputeState.fromString(
        "String7"
    ))
.sellerResponseDueDate(DisputeRecordSellerResponseDueDate.fromString(
        "String3"
    ))
.updateTime(DisputeRecordUpdateTime.fromString(
        "String7"
    ))
.build();
```

