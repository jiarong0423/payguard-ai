
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |
| `FIXTURE` |

## Example

```java
import m18000.m0.m0.m127.models.DataSourceLabelEnum;

DataSourceLabelEnum dataSourceLabel = DataSourceLabelEnum.SANDBOX;
```

