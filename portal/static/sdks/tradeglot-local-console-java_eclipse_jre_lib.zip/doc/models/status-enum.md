
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURE_COMPATIBLE` |
| `INCOMPLETE_EVIDENCE` |
| `REJECTED` |

## Example

```java
import m18000.m0.m0.m127.models.StatusEnum;

StatusEnum status = StatusEnum.REJECTED;
```

