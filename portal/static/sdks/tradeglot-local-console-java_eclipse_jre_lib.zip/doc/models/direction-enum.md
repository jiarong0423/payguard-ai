
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```java
import m18000.m0.m0.m127.models.DirectionEnum;

DirectionEnum direction = DirectionEnum.INBOUND;
```

