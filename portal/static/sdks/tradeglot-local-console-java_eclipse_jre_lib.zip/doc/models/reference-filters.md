
# Reference Filters

ReferenceFilters.

## Structure

`ReferenceFilters`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AgeBasis` | `String` | Required, Constant | Age basis.<br><br>**Value**: `"source_updated_date_utc_calendar"` | String getAgeBasis() | setAgeBasis(String ageBasis) |
| `AsOf` | [`ReferenceFiltersAsOf`](../../doc/models/containers/reference-filters-as-of.md) | Required | This is a container for any-of cases. | ReferenceFiltersAsOf getAsOf() | setAsOf(ReferenceFiltersAsOf asOf) |
| `CaseStage` | [`CaseStage2Enum`](../../doc/models/case-stage-2-enum.md) | Required | Case stage. | CaseStage2Enum getCaseStage() | setCaseStage(CaseStage2Enum caseStage) |
| `Jurisdiction` | `String` | Required, Constant | Jurisdiction.<br><br>**Value**: `"US"` | String getJurisdiction() | setJurisdiction(String jurisdiction) |
| `Limit` | `int` | Required | Limit.<br><br>**Constraints**: `>= 1`, `<= 10` | int getLimit() | setLimit(int limit) |
| `MaterialTypes` | [`List<MaterialType4Enum>`](../../doc/models/material-type-4-enum.md) | Required | Material types.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `3` | List<MaterialType4Enum> getMaterialTypes() | setMaterialTypes(List<MaterialType4Enum> materialTypes) |
| `MaxSourceAgeDays` | [`ReferenceFiltersMaxSourceAgeDays`](../../doc/models/containers/reference-filters-max-source-age-days.md) | Required | This is a container for any-of cases. | ReferenceFiltersMaxSourceAgeDays getMaxSourceAgeDays() | setMaxSourceAgeDays(ReferenceFiltersMaxSourceAgeDays maxSourceAgeDays) |
| `RequireKnownSourceDate` | `boolean` | Required | Require known source date. | boolean getRequireKnownSourceDate() | setRequireKnownSourceDate(boolean requireKnownSourceDate) |
| `Theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. | ThemeEnum getTheme() | setTheme(ThemeEnum theme) |

## Example

```java
import java.util.Arrays;
import m18000.m0.m0.m127.models.CaseStage2Enum;
import m18000.m0.m0.m127.models.MaterialType4Enum;
import m18000.m0.m0.m127.models.ReferenceFilters;
import m18000.m0.m0.m127.models.ThemeEnum;
import m18000.m0.m0.m127.models.containers.ReferenceFiltersAsOf;
import m18000.m0.m0.m127.models.containers.ReferenceFiltersMaxSourceAgeDays;

ReferenceFilters referenceFilters = new ReferenceFilters.Builder(
    "source_updated_date_utc_calendar",
    ReferenceFiltersAsOf.fromString(
        "String9"
    ),
    CaseStage2Enum.PROCEDURAL_ORDER,
    "US",
    10,
    Arrays.asList(
        MaterialType4Enum.OFFICIAL_POLICY,
        MaterialType4Enum.PUBLIC_COURT_ORDER_COPY
    ),
    ReferenceFiltersMaxSourceAgeDays.fromNumber(
        238
    ),
    false,
    ThemeEnum.DISPUTE_MEDIATION
)
.build();
```

