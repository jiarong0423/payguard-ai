
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```java
import m18000.m0.m0.m127.models.StageEnum;

StageEnum stage = StageEnum.DISPUTE_MEDIATION;
```

