
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASE_NOT_ACTIONABLE` |
| `MANUAL_REVIEW` |
| `DUE_DATE_EXPIRED` |
| `ACTION_NOT_AVAILABLE` |
| `NEEDS_INPUT` |
| `READY_FOR_LOCAL_REVIEW` |

## Example

```java
import m18000.m0.m0.m127.models.OverallStateEnum;

OverallStateEnum overallState = OverallStateEnum.DUE_DATE_EXPIRED;
```

