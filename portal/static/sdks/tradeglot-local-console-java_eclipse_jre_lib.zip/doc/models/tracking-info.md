
# Tracking Info

TrackingInfo.

## Structure

`TrackingInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CarrierName` | [`CarrierNameEnum`](../../doc/models/carrier-name-enum.md) | Required | Carrier name. | CarrierNameEnum getCarrierName() | setCarrierName(CarrierNameEnum carrierName) |
| `CarrierNameOther` | [`TrackingInfoCarrierNameOther`](../../doc/models/containers/tracking-info-carrier-name-other.md) | Optional | This is a container for any-of cases. | TrackingInfoCarrierNameOther getCarrierNameOther() | setCarrierNameOther(TrackingInfoCarrierNameOther carrierNameOther) |
| `TrackingNumber` | `String` | Required | Tracking number.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` | String getTrackingNumber() | setTrackingNumber(String trackingNumber) |

## Example

```java
import m18000.m0.m0.m127.models.CarrierNameEnum;
import m18000.m0.m0.m127.models.TrackingInfo;
import m18000.m0.m0.m127.models.containers.TrackingInfoCarrierNameOther;

TrackingInfo trackingInfo = new TrackingInfo.Builder(
    CarrierNameEnum.TW_CHUNGHWA_POST,
    "tracking_number4"
)
.carrierNameOther(TrackingInfoCarrierNameOther.fromString(
        "String9"
    ))
.build();
```

