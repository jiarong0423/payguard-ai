
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```java
import m18000.m0.m0.m127.models.Source11Enum;

Source11Enum source11 = Source11Enum.CHANNEL3_LIVE;
```

