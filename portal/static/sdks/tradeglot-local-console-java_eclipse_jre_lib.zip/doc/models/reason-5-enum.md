
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |
| `SUPERSEDED` |

## Example

```java
import m18000.m0.m0.m127.models.Reason5Enum;

Reason5Enum reason5 = Reason5Enum.INVALID_REPLY;
```

