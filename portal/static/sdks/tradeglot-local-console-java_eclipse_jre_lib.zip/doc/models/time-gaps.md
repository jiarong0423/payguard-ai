
# Time Gaps

TimeGaps.

## Structure

`TimeGaps`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DeliveryToClaim` | [`TimeGapsDeliveryToClaim`](../../doc/models/containers/time-gaps-delivery-to-claim.md) | Required | This is a container for any-of cases. | TimeGapsDeliveryToClaim getDeliveryToClaim() | setDeliveryToClaim(TimeGapsDeliveryToClaim deliveryToClaim) |
| `PaymentToClaim` | [`TimeGapsPaymentToClaim`](../../doc/models/containers/time-gaps-payment-to-claim.md) | Required | This is a container for any-of cases. | TimeGapsPaymentToClaim getPaymentToClaim() | setPaymentToClaim(TimeGapsPaymentToClaim paymentToClaim) |
| `PaymentToDelivery` | [`TimeGapsPaymentToDelivery`](../../doc/models/containers/time-gaps-payment-to-delivery.md) | Required | This is a container for any-of cases. | TimeGapsPaymentToDelivery getPaymentToDelivery() | setPaymentToDelivery(TimeGapsPaymentToDelivery paymentToDelivery) |
| `PaymentToOrderRecord` | [`TimeGapsPaymentToOrderRecord`](../../doc/models/containers/time-gaps-payment-to-order-record.md) | Required | This is a container for any-of cases. | TimeGapsPaymentToOrderRecord getPaymentToOrderRecord() | setPaymentToOrderRecord(TimeGapsPaymentToOrderRecord paymentToOrderRecord) |

## Example

```java
import m18000.m0.m0.m127.models.TimeGaps;
import m18000.m0.m0.m127.models.containers.TimeGapsDeliveryToClaim;
import m18000.m0.m0.m127.models.containers.TimeGapsPaymentToClaim;
import m18000.m0.m0.m127.models.containers.TimeGapsPaymentToDelivery;
import m18000.m0.m0.m127.models.containers.TimeGapsPaymentToOrderRecord;

TimeGaps timeGaps = new TimeGaps.Builder(
    TimeGapsDeliveryToClaim.fromNumber(
        152
    ),
    TimeGapsPaymentToClaim.fromNumber(
        212
    ),
    TimeGapsPaymentToDelivery.fromNumber(
        222
    ),
    TimeGapsPaymentToOrderRecord.fromNumber(
        10
    )
)
.build();
```

