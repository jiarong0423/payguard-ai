
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Scenario` | [`Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. | Scenario5Enum getScenario() | setScenario(Scenario5Enum scenario) |

## Example

```java
import m18000.m0.m0.m127.models.InjectRequest;
import m18000.m0.m0.m127.models.Scenario5Enum;

InjectRequest injectRequest = new InjectRequest.Builder(
    Scenario5Enum.BURST
)
.build();
```

