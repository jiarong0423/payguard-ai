
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADD_TRACKING_PREVIEW` |
| `ADD_TRACKING_SUBMITTED` |

## Example

```java
import m18000.m0.m0.m127.models.ReadbackEnum;

ReadbackEnum readback = ReadbackEnum.ADD_TRACKING_PREVIEW;
```

