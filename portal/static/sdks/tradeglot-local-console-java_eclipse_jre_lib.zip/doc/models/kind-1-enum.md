
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```java
import m18000.m0.m0.m127.models.Kind1Enum;

Kind1Enum kind1 = Kind1Enum.MESSAGE;
```

