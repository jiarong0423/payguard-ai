
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |

## Example

```java
import m18000.m0.m0.m127.models.EvidenceClass3Enum;

EvidenceClass3Enum evidenceClass3 = EvidenceClass3Enum.AUTHENTIC_SANDBOX_RESPONSE;
```

