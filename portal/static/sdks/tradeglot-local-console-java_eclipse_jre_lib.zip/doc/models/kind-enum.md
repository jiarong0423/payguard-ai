
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDER_RECORD_CREATED` |
| `DELIVERY` |
| `CLAIM_OPENED` |

## Example

```java
import m18000.m0.m0.m127.models.KindEnum;

KindEnum kind = KindEnum.DELIVERY;
```

