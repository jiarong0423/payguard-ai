
# Buyer Country Enum

Buyer country.

## Enumeration

`BuyerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```java
import m18000.m0.m0.m127.models.BuyerCountryEnum;

BuyerCountryEnum buyerCountry = BuyerCountryEnum.US;
```

