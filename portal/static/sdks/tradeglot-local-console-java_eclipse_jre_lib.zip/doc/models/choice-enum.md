
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURN_TO_EDIT` |
| `CANCEL` |
| `ACKNOWLEDGE_AND_CONTINUE` |

## Example

```java
import m18000.m0.m0.m127.models.ChoiceEnum;

ChoiceEnum choice = ChoiceEnum.RETURN_TO_EDIT;
```

