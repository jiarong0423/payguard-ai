
# Requirement State Enum

Requirement state.

## Enumeration

`RequirementStateEnum`

## Fields

| Name |
|  --- |
| `CONTEXT_ONLY` |
| `UNMAPPED_EVIDENCE_TYPE` |
| `PROVIDER_REQUEST_OUTSIDE_LOCAL_MATRIX` |
| `STRUCTURALLY_PRESENT` |
| `MANDATORY_EVIDENCE_MISSING` |
| `OPTIONAL_EVIDENCE_MISSING` |

## Example

```java
import m18000.m0.m0.m127.models.RequirementStateEnum;

RequirementStateEnum requirementState = RequirementStateEnum.MANDATORY_EVIDENCE_MISSING;
```

