
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```java
import m18000.m0.m0.m127.models.ThemeEnum;

ThemeEnum theme = ThemeEnum.SOURCE_COMPLIANCE;
```

