
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `HOSTED_DEMO` |

## Example

```java
import m18000.m0.m0.m127.models.ModeEnum;

ModeEnum mode = ModeEnum.LOCAL;
```

