
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_SANDBOX` |
| `SYNTHETIC_FIXTURE` |

## Example

```java
import m18000.m0.m0.m127.models.SourceEnum;

SourceEnum source = SourceEnum.PAYPAL_SANDBOX;
```

