
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONE_MATCH` |

## Example

```java
import m18000.m0.m0.m127.models.Choice2Enum;

Choice2Enum choice2 = Choice2Enum.CONFIRMED;
```

