
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```java
import m18000.m0.m0.m127.models.ConfidenceEnum;

ConfidenceEnum confidence = ConfidenceEnum.HIGH;
```

