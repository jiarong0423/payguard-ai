
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTURE_OBSERVATION` |
| `STALE_OBSERVATION` |
| `WITHIN_OBSERVATION_BUDGET` |

## Example

```java
import m18000.m0.m0.m127.models.ObservationStatusEnum;

ObservationStatusEnum observationStatus = ObservationStatusEnum.FUTURE_OBSERVATION;
```

