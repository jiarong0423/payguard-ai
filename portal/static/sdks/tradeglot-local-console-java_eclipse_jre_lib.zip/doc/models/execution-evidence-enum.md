
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_TEST_RESPONSE` |
| `OPERATOR_LIVE_RESPONSE` |
| `LOCAL_RUNTIME_RESPONSE` |

## Example

```java
import m18000.m0.m0.m127.models.ExecutionEvidenceEnum;

ExecutionEvidenceEnum executionEvidence = ExecutionEvidenceEnum.OPERATOR_LIVE_RESPONSE;
```

