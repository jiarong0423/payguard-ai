
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_IMAGEJPEG` |
| `ENUM_IMAGEGIF` |
| `ENUM_IMAGEPNG` |
| `ENUM_APPLICATIONPDF` |

## Example

```java
import m18000.m0.m0.m127.models.ContentTypeEnum;

ContentTypeEnum contentType = ContentTypeEnum.ENUM_IMAGEPNG;
```

