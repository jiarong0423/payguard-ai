
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```java
import m18000.m0.m0.m127.models.CurrencyEnum;

CurrencyEnum currency = CurrencyEnum.USD;
```

