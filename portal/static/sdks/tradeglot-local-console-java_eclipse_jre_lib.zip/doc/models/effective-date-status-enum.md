
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_VERIFIED` |

## Example

```java
import m18000.m0.m0.m127.models.EffectiveDateStatusEnum;

EffectiveDateStatusEnum effectiveDateStatus = EffectiveDateStatusEnum.DOCUMENT_STATED;
```

