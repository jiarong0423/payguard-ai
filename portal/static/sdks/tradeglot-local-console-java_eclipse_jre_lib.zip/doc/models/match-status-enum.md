
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NO_MATCH` |
| `REVIEW_SIGNAL` |

## Example

```java
import m18000.m0.m0.m127.models.MatchStatusEnum;

MatchStatusEnum matchStatus = MatchStatusEnum.NO_MATCH;
```

