
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOT_FOUND` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```java
import m18000.m0.m0.m127.models.Status12Enum;

Status12Enum status12 = Status12Enum.NOT_SENT;
```

