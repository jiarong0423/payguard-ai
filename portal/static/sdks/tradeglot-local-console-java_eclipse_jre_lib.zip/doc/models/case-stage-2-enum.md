
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `ANY` |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```java
import m18000.m0.m0.m127.models.CaseStage2Enum;

CaseStage2Enum caseStage2 = CaseStage2Enum.ANY;
```

