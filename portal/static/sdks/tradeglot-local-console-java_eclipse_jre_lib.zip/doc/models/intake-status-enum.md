
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `READY_FOR_LOCAL_RULES` |
| `MANUAL_REVIEW` |

## Example

```java
import m18000.m0.m0.m127.models.IntakeStatusEnum;

IntakeStatusEnum intakeStatus = IntakeStatusEnum.READY_FOR_LOCAL_RULES;
```

