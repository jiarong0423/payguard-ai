
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PRE_ARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```java
import m18000.m0.m0.m127.models.DisputeLifeCycleStageEnum;

DisputeLifeCycleStageEnum disputeLifeCycleStage = DisputeLifeCycleStageEnum.INQUIRY;
```

