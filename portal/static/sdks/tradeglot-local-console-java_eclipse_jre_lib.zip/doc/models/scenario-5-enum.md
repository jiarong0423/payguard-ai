
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `BURST` |
| `DISPUTE` |
| `RESET` |

## Example

```java
import m18000.m0.m0.m127.models.Scenario5Enum;

Scenario5Enum scenario5 = Scenario5Enum.DISPUTE;
```

