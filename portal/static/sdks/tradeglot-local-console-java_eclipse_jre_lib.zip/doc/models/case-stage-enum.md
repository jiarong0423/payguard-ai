
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```java
import m18000.m0.m0.m127.models.CaseStageEnum;

CaseStageEnum caseStage = CaseStageEnum.PROCEDURAL_ORDER;
```

