
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `GoodsType` | [`GuideStartRequestGoodsType`](../../doc/models/containers/guide-start-request-goods-type.md) | Optional | This is a container for any-of cases. | GuideStartRequestGoodsType getGoodsType() | setGoodsType(GuideStartRequestGoodsType goodsType) |
| `Scenario` | [`Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. | Scenario2Enum getScenario() | setScenario(Scenario2Enum scenario) |

## Example

```java
import m18000.m0.m0.m127.models.GoodsTypeEnum;
import m18000.m0.m0.m127.models.GuideStartRequest;
import m18000.m0.m0.m127.models.Scenario2Enum;
import m18000.m0.m0.m127.models.containers.GuideStartRequestGoodsType;

GuideStartRequest guideStartRequest = new GuideStartRequest.Builder(
    Scenario2Enum.VELOCITY
)
.goodsType(GuideStartRequestGoodsType.fromGoodsType(
        GoodsTypeEnum.PHYSICAL
    ))
.build();
```

