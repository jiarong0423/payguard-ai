
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATE_MESSAGE` |

## Example

```java
import m18000.m0.m0.m127.models.ChannelEnum;

ChannelEnum channel = ChannelEnum.EMAIL;
```

