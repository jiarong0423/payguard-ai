
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `ENUM_1` |

## Example

```java
import m18000.m0.m0.m127.models.SchemaVersion1Enum;

SchemaVersion1Enum schemaVersion1 = SchemaVersion1Enum.ENUM_1;
```

