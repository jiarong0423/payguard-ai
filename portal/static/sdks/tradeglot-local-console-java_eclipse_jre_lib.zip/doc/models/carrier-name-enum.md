
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TW_CHUNGHWA_POST` |
| `JP_JAPANPOST` |
| `OTHER` |

## Example

```java
import m18000.m0.m0.m127.models.CarrierNameEnum;

CarrierNameEnum carrierName = CarrierNameEnum.JP_JAPANPOST;
```

