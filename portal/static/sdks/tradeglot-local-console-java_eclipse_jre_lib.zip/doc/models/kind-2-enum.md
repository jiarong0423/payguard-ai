
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `DATE` |
| `CHOICE` |
| `TEXT` |

## Example

```java
import m18000.m0.m0.m127.models.Kind2Enum;

Kind2Enum kind2 = Kind2Enum.CHOICE;
```

