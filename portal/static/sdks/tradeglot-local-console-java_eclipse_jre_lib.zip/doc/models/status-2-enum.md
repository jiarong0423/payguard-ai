
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```java
import m18000.m0.m0.m127.models.Status2Enum;

Status2Enum status2 = Status2Enum.NOT_SENT;
```

