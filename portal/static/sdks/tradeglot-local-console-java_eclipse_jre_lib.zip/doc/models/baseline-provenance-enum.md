
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_BASELINE` |
| `CALLER_SUPPLIED_UNVERIFIED` |

## Example

```java
import m18000.m0.m0.m127.models.BaselineProvenanceEnum;

BaselineProvenanceEnum baselineProvenance = BaselineProvenanceEnum.SYNTHETIC_BASELINE;
```

