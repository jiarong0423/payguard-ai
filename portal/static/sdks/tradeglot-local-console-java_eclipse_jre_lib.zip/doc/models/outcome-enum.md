
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ERROR` |

## Example

```java
import m18000.m0.m0.m127.models.OutcomeEnum;

OutcomeEnum outcome = OutcomeEnum.OK;
```

