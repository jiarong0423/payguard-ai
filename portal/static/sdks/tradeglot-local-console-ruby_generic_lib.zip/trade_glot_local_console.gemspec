Gem::Specification.new do |s|
  s.name = 'trade_glot_local_console'
  s.version = '0.2.0'
  s.summary = 'trade_glot_local_console'
  s.description = 'API of the local TradeGlot console (127.0.0.1:8000). It uses synthetic data, expects the demo session headers the console sets, and the hosted demo answers 503 on every route that would reach PayPal. Authentication: create a session with POST /api/v1/demo/sessions, then send X-Demo-Session on every other call and X-CSRF-Token on every POST. POST calls also need an Origin header equal to the console\'s own origin (browsers add it; scripts must set it), otherwise the API answers 403 origin_required.'
  s.authors = ['TradeGlot']
  s.email = ['support@apimatic.io']
  s.homepage = 'https://github.com/jiarong0423/payguard-ai'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.add_development_dependency('minitest', '~> 5.24.0')
  s.add_development_dependency('minitest-proveit', '~> 1.0')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end
