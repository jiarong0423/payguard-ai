
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| connection | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| adapter | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| timeout | `Float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| retry_interval | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| backoff_factor | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| retry_statuses | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put get put]** |
| http_callback | `HttpCallBack` | The Http CallBack allows defining callables for pre and post API calls. |
| proxy_settings | [`ProxySettings`](../doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| demo_csrf_credentials | [`DemoCsrfCredentials`](auth/custom-header-signature.md) | The credential object for Custom Header Signature |
| demo_session_credentials | [`DemoSessionCredentials`](auth/custom-header-signature-1.md) | The credential object for Custom Header Signature |

The API client can be initialized as follows:

## Code-Based Client Initialization

```ruby
require 'trade_glot_local_console'
include TradeGlotLocalConsole

client = Client.new(
  demo_csrf_credentials: DemoCsrfCredentials.new(
    x_csrf_token: 'X-CSRF-Token'
  ),
  demo_session_credentials: DemoSessionCredentials.new(
    x_demo_session: 'X-Demo-Session'
  )
)
```

## Environment-Based Client Initialization

```ruby
require 'trade_glot_local_console'
include TradeGlotLocalConsole

# Create client from environment
client = Client.from_env
```

See the [`Environment-Based Client Initialization`](../doc/environment-based-client-initialization.md) section for details.

## TradeGlot Local Console Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| ai | Gets AiController |
| aup | Gets AupController |
| demo | Gets DemoController |
| guide | Gets GuideController |
| health | Gets HealthController |
| other | Gets OtherController |
| paypal | Gets PaypalController |
| references | Gets ReferencesController |
| studio | Gets StudioController |

