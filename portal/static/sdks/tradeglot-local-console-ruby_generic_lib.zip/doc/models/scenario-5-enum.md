
# Scenario 5 Enum

Scenario.

## Enumeration

`Scenario5Enum`

## Fields

| Name |
|  --- |
| `BURST` |
| `DISPUTE` |
| `RESET` |

## Example

```ruby
scenario5 = Scenario5Enum::DISPUTE
```

