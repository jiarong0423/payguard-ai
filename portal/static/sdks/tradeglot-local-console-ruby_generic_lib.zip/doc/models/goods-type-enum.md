
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |

## Example

```ruby
goods_type = GoodsTypeEnum::PHYSICAL
```

