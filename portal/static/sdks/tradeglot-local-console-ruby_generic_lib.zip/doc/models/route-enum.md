
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |
| `SERVICE` |
| `UNKNOWN` |

## Example

```ruby
route = RouteEnum::PHYSICAL
```

