
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```ruby
currency = CurrencyEnum::USD
```

