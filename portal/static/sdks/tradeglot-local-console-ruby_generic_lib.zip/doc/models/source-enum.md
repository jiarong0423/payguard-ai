
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_SANDBOX` |
| `SYNTHETIC_FIXTURE` |

## Example

```ruby
source = SourceEnum::PAYPAL_SANDBOX
```

