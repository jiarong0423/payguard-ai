
# Error

What was refused and why.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Required | Stable machine-readable reason, for example session_required. |
| `message` | `String` | Required | A plain sentence for a person. |

## Example

```ruby
error = Error.new(
  'code2',
  'message4'
)
```

