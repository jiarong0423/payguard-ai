
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `DATE` |
| `CHOICE` |
| `TEXT` |

## Example

```ruby
kind2 = Kind2Enum::CHOICE
```

