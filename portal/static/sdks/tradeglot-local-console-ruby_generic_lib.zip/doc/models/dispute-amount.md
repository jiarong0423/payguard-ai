
# Dispute Amount

Dispute amount.

## Structure

`DisputeAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency_code` | `String` | Optional | Currency code.<br><br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `value` | `String` | Optional | Value.<br><br>**Constraints**: *Pattern*: `^[0-9]{1,10}(?:\.[0-9]{1,2})?$` |

## Example

```ruby
dispute_amount = DisputeAmount.new(
  'currency_code6',
  'value0'
)
```

