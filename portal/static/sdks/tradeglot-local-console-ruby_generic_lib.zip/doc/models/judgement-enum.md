
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOT_MADE` |

## Example

```ruby
judgement = JudgementEnum::NOT_MADE
```

