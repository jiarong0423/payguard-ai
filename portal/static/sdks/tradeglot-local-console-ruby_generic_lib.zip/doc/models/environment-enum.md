
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |

## Example

```ruby
environment = EnvironmentEnum::SANDBOX
```

