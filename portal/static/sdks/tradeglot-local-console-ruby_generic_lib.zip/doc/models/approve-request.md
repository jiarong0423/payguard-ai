
# Approve Request

ApproveRequest.

## Structure

`ApproveRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `draft_digest` | `String` | Required | Draft digest.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |

## Example

```ruby
approve_request = ApproveRequest.new(
  'draft_digest6'
)
```

