
# Source 11 Enum

## Enumeration

`Source11Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```ruby
source11 = Source11Enum::CHANNEL3_LIVE
```

