
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURE_COMPATIBLE` |
| `INCOMPLETE_EVIDENCE` |
| `REJECTED` |

## Example

```ruby
status = StatusEnum::REJECTED
```

