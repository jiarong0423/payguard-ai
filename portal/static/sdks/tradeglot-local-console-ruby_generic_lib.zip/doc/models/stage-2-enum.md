
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |
| `GUIDE` |
| `STUDIO_AGENT` |

## Example

```ruby
stage2 = Stage2Enum::STUDIO_AGENT
```

