
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `ANY` |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```ruby
case_stage2 = CaseStage2Enum::PROCEDURAL_ORDER
```

