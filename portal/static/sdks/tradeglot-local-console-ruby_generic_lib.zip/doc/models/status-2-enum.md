
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```ruby
status2 = Status2Enum::NOT_SENT
```

