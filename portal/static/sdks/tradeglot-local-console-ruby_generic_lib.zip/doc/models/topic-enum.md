
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENT_NOTICE` |
| `ORDER_DETAILS_REQUEST` |
| `ORDER_DETAILS_PROVIDED` |
| `DELIVERY_NOTICE` |
| `REFUND_REQUEST` |
| `OTHER` |

## Example

```ruby
topic = TopicEnum::ORDER_DETAILS_PROVIDED
```

