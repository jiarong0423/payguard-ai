
# Evidence Info

EvidenceInfo.

## Structure

`EvidenceInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tracking_info` | [`Array[TrackingInfo]`](../../doc/models/tracking-info.md) | Required | Tracking info.<br><br>**Constraints**: *Maximum Items*: `10` |

## Example

```ruby
evidence_info = EvidenceInfo.new(
  [
    TrackingInfo.new(
      CarrierNameEnum::DHL,
      'tracking_number6',
      'String1'
    )
  ]
)
```

