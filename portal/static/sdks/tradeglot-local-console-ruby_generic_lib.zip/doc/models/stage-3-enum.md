
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `FUNNEL` |
| `ECHO` |
| `FILL` |
| `REVIEW` |
| `DONE` |

## Example

```ruby
stage3 = Stage3Enum::DONE
```

