
# Evidence Class Enum

Evidence class.

## Enumeration

`EvidenceClassEnum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |
| `SYNTHETIC_FIXTURE` |

## Example

```ruby
evidence_class = EvidenceClassEnum::AUTHENTIC_SANDBOX_RESPONSE
```

