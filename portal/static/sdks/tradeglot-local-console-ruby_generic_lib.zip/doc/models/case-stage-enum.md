
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```ruby
case_stage = CaseStageEnum::PROCEDURAL_ORDER
```

