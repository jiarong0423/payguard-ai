
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `ENUM_1` |

## Example

```ruby
schema_version1 = SchemaVersion1Enum::ENUM_1
```

