
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTH_CONNECT` |
| `CREATE_INVOICE_DRAFT` |

## Example

```ruby
action = ActionEnum::OAUTH_CONNECT
```

