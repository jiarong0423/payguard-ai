
# Ai Brief Http Request

What the console may send: the stage and, for disputes, which case. Session facts are never caller input.

## Structure

`AiBriefHttpRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | String \| nil | Optional | This is a container for any-of cases. |
| `stage` | [`StageEnum`](../../doc/models/stage-enum.md) | Required | Stage. |

## Example

```ruby
ai_brief_http_request = AiBriefHttpRequest.new(
  StageEnum::DISPUTE_MEDIATION,
  'String7'
)
```

