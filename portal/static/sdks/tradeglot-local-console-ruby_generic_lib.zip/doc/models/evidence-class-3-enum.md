
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |

## Example

```ruby
evidence_class3 = EvidenceClass3Enum::AUTHENTIC_SANDBOX_RESPONSE
```

