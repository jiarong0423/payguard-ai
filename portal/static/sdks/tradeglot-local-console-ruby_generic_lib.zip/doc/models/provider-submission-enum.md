
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOT_PERFORMED` |
| `PERFORMED` |

## Example

```ruby
provider_submission = ProviderSubmissionEnum::NOT_PERFORMED
```

