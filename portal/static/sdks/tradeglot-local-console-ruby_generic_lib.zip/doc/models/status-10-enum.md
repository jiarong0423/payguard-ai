
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```ruby
status10 = Status10Enum::CONNECTED
```

