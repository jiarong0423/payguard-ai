
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario` | [`Scenario5Enum`](../../doc/models/scenario-5-enum.md) | Required | Scenario. |

## Example

```ruby
inject_request = InjectRequest.new(
  Scenario5Enum::BURST
)
```

