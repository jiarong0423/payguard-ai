
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `label` | `String` | Required | Label. |
| `value` | `String` | Required | Value. |

## Example

```ruby
guide_option = GuideOption.new(
  'label2',
  'value4'
)
```

