
# Country Rules Check Request

Seller and buyer countries plus closed choices; no free text reaches the check.

## Structure

`CountryRulesCheckRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_opened` | [`AccountOpenedEnum`](../../doc/models/account-opened-enum.md) | Optional | Account opened.<br><br>**Default**: `AccountOpenedEnum::UNKNOWN` |
| `account_type` | [`AccountTypeEnum`](../../doc/models/account-type-enum.md) | Optional | Account type.<br><br>**Default**: `AccountTypeEnum::BUSINESS` |
| `amount` | String \| nil | Optional | This is a container for any-of cases. |
| `buyer_country` | [`BuyerCountryEnum`](../../doc/models/buyer-country-enum.md) | Required | Buyer country. |
| `checkout` | [`CheckoutEnum`](../../doc/models/checkout-enum.md) | Optional | Checkout.<br><br>**Default**: `CheckoutEnum::PAYPAL_ACCOUNT` |
| `currency` | String \| nil | Optional | This is a container for any-of cases. |
| `goods_tags` | `Array[String]` | Optional | Goods tags.<br><br>**Constraints**: *Maximum Items*: `16` |
| `seller_country` | [`SellerCountryEnum`](../../doc/models/seller-country-enum.md) | Required | Seller country. |

## Example

```ruby
country_rules_check_request = CountryRulesCheckRequest.new(
  BuyerCountryEnum::JP,
  SellerCountryEnum::US,
  AccountOpenedEnum::UNKNOWN,
  AccountTypeEnum::BUSINESS,
  'String7',
  CheckoutEnum::PAYPAL_ACCOUNT,
  'String5',
  []
)
```

