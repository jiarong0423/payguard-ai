
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `goods_type` | [GoodsType](../../doc/models/goods-type-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `scenario` | [`Scenario2Enum`](../../doc/models/scenario-2-enum.md) | Required | Scenario. |

## Example

```ruby
guide_start_request = GuideStartRequest.new(
  Scenario2Enum::DISPUTE,
  GoodsTypeEnum::PHYSICAL
)
```

