
# Reason Enum

## Enumeration

`ReasonEnum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```ruby
reason = ReasonEnum::CONTRACT_REJECTED
```

