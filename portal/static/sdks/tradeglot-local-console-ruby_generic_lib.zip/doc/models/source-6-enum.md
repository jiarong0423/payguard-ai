
# Source 6 Enum

Source.

## Enumeration

`Source6Enum`

## Fields

| Name |
|  --- |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```ruby
source6 = Source6Enum::SELLER_PROVIDED_UNVERIFIED
```

