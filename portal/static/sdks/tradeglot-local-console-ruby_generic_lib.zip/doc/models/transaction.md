
# Transaction

Transaction.

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `String` | Required | Amount. |
| `currency` | `String` | Required | Currency. |
| `occurred_at` | `String` | Required | Occurred at. |
| `order_id` | `String` | Required | Order id. |

## Example

```ruby
transaction = Transaction.new(
  'amount0',
  'currency8',
  'occurred_at2',
  'order_id2'
)
```

