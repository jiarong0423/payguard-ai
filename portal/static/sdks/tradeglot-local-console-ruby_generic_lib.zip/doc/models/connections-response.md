
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mode` | [`ModeEnum`](../../doc/models/mode-enum.md) | Required | Mode. |
| `sandbox_reads` | TrueClass \| FalseClass \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
connections_response = ConnectionsResponse.new(
  ModeEnum::LOCAL,
  true
)
```

