
# Status 12 Enum

Status.

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `FOUND` |
| `NOT_FOUND` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```ruby
status12 = Status12Enum::NOT_SENT
```

