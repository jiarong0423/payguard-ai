
# Ai Usage Entry

AiUsageEntry.

## Structure

`AiUsageEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `String` | Required | At. |
| `estimated_cost_usd` | String \| nil | Optional | This is a container for any-of cases. |
| `latency_ms` | `Integer` | Required | Latency ms.<br><br>**Constraints**: `>= 0`, `<= 3600000` |
| `model` | String \| nil | Optional | This is a container for any-of cases. |
| `outcome` | [`OutcomeEnum`](../../doc/models/outcome-enum.md) | Required | Outcome. |
| `stage` | [`Stage2Enum`](../../doc/models/stage-2-enum.md) | Required | Stage. |
| `tokens_in` | Integer \| nil | Optional | This is a container for any-of cases. |
| `tokens_out` | Integer \| nil | Optional | This is a container for any-of cases. |
| `tokens_total` | Integer \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
ai_usage_entry = AiUsageEntry.new(
  'at8',
  36,
  OutcomeEnum::OK,
  Stage2Enum::DISPUTE_MEDIATION,
  'String9',
  'String1',
  234,
  92,
  156
)
```

