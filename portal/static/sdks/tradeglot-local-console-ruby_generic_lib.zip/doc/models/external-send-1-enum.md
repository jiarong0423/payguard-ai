
# External Send 1 Enum

External send.

## Enumeration

`ExternalSend1Enum`

## Fields

| Name |
|  --- |
| `FROZEN` |

## Example

```ruby
external_send1 = ExternalSend1Enum::FROZEN
```

