
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_VERIFIED` |

## Example

```ruby
effective_date_status = EffectiveDateStatusEnum::DOCUMENT_STATED
```

