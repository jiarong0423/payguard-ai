
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```ruby
kind1 = Kind1Enum::MESSAGE
```

