
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SESSION_MEMORY` |
| `HOSTED_DEMO` |

## Example

```ruby
source1 = Source1Enum::SESSION_MEMORY
```

