
# Claim Type Enum

Claim type.

## Enumeration

`ClaimTypeEnum`

## Fields

| Name |
|  --- |
| `POLICY_REFERENCE` |
| `CURRENT_POLICY` |
| `PROCEDURAL_REFERENCE` |
| `API_REFERENCE` |
| `FINANCIAL_ACTION` |
| `ASSURANCE` |

## Example

```ruby
claim_type = ClaimTypeEnum::PROCEDURAL_REFERENCE
```

