
# Guide Turn Request

GuideTurnRequest.

## Structure

`GuideTurnRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | Array[[GuideField](../../doc/models/guide-field.md)] \| nil | Optional | This is a container for any-of cases. |
| `scenario` | [Scenario1](../../doc/models/scenario-1-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `text` | `String` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `1600` |

## Example

```ruby
guide_turn_request = GuideTurnRequest.new(
  'text0',
  [
    GuideField.new(
      'item8',
      'value8'
    ),
    GuideField.new(
      'item8',
      'value8'
    ),
    GuideField.new(
      'item8',
      'value8'
    )
  ],
  Scenario1Enum::DISPUTE
)
```

