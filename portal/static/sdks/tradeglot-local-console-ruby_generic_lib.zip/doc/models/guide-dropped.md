
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `String` | Required | Item. |
| `reason` | [`Reason6Enum`](../../doc/models/reason-6-enum.md) | Required | Reason. |

## Example

```ruby
guide_dropped = GuideDropped.new(
  'item6',
  Reason6Enum::OTHER_PARTY
)
```

