
# Activity

Activity.

## Structure

`Activity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `String` | Required | At. |
| `id` | `String` | Required | Id. |
| `kind` | `String` | Required | Kind. |
| `label` | `String` | Required | Label. |
| `source` | `String` | Required, Constant | Source.<br><br>**Value**: `'synthetic'` |

## Example

```ruby
activity = Activity.new(
  'at4',
  'id8',
  'kind6',
  'label8',
  'synthetic'
)
```

