
# Policy Context

PolicyContext.

## Structure

`PolicyContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `as_of` | `String` | Required | As of.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `64` |
| `jurisdiction` | `String` | Required, Constant | Jurisdiction.<br><br>**Value**: `'US'` |
| `observation_max_age_days` | `Integer` | Required | Observation max age days.<br><br>**Constraints**: `>= 0`, `<= 365000` |
| `theme` | [`ThemeEnum`](../../doc/models/theme-enum.md) | Required | Theme. |

## Example

```ruby
policy_context = PolicyContext.new(
  'as_of0',
  'US',
  48,
  ThemeEnum::SOURCE_COMPLIANCE
)
```

