
# Product Reference Request

ProductReferenceRequest.

## Structure

`ProductReferenceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |
| `evaluation_id` | `String` | Required | Evaluation id.<br><br>**Constraints**: *Minimum Length*: `32`, *Maximum Length*: `128`, *Pattern*: `^[A-Za-z0-9_-]+$` |

## Example

```ruby
product_reference_request = ProductReferenceRequest.new(
  'description4',
  'evaluation_id0'
)
```

