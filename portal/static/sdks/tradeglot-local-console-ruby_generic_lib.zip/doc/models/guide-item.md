
# Guide Item

GuideItem.

## Structure

`GuideItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chunk` | String | Required | This is a container for any-of cases. |
| `form` | [GuideForm](../../doc/models/guide-form.md) | Required | This is a container for any-of cases. |
| `id` | `String` | Required | Id. |
| `label` | `String` | Required | Label. |
| `source` | [`Source8Enum`](../../doc/models/source-8-enum.md) | Required | Source. |
| `status` | [`Status9Enum`](../../doc/models/status-9-enum.md) | Required | Status. |

## Example

```ruby
guide_item = GuideItem.new(
  'String1',
  GuideForm.new(
    Kind2Enum::CHOICE,
    [
      GuideOption.new(
        'label2',
        'value4'
      )
    ],
    'String9'
  ),
  'id6',
  'label6',
  Source8Enum::OFFICIAL,
  Status9Enum::STRUCTURALLY_PRESENT
)
```

