
# Guide Field

GuideField.

## Structure

`GuideField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `String` | Required | Item.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-z_]+$` |
| `value` | `String` | Required | Value.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `120` |

## Example

```ruby
guide_field = GuideField.new(
  'item4',
  'value4'
)
```

