
# Tracker Batch

TrackerBatch.

## Structure

`TrackerBatch`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `trackers` | [`Array[TrackerItem]`](../../doc/models/tracker-item.md) | Required | Trackers.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `1` |

## Example

```ruby
tracker_batch = TrackerBatch.new(
  [
    TrackerItem.new(
      CarrierEnum::JP_JAPANPOST,
      'SHIPPED',
      'tracking_number0',
      'transaction_id0',
      'String5'
    )
  ]
)
```

