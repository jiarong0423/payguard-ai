
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PRE_ARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```ruby
dispute_life_cycle_stage = DisputeLifeCycleStageEnum::UNKNOWN
```

