
# Aup Request

AupRequest.

## Structure

`AupRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Required | Description.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `4000` |

## Example

```ruby
aup_request = AupRequest.new(
  'description8'
)
```

