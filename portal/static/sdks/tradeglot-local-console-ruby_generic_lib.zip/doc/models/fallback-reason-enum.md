
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |

## Example

```ruby
fallback_reason = FallbackReasonEnum::LATE
```

