
# Time Event

TimeEvent.

## Structure

`TimeEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `String` | Required | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `kind` | [`KindEnum`](../../doc/models/kind-enum.md) | Required | Kind. |
| `source` | [`Source5Enum`](../../doc/models/source-5-enum.md) | Required | Source. |

## Example

```ruby
time_event = TimeEvent.new(
  'at2',
  KindEnum::PAYMENT,
  Source5Enum::PROVIDER
)
```

