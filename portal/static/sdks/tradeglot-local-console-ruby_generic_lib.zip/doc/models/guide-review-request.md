
# Guide Review Request

GuideReviewRequest.

## Structure

`GuideReviewRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `change` | `Array[String]` | Optional | Change.<br><br>**Constraints**: *Maximum Items*: `9`, *Minimum Length*: `1`, *Maximum Length*: `40`, *Pattern*: `^[a-z_]+$` |
| `confirm` | `TrueClass \| FalseClass` | Optional | Confirm.<br><br>**Default**: `false` |
| `scenario` | [Scenario1](../../doc/models/scenario-1-enum.md) \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
guide_review_request = GuideReviewRequest.new(
  [
    'change1',
    'change2'
  ],
  false,
  Scenario1Enum::VELOCITY
)
```

