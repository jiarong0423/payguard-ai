
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `MISSING` |

## Example

```ruby
source_updated_date_status = SourceUpdatedDateStatusEnum::DOCUMENT_STATED
```

