
# Dispute Record

DisputeRecord.

## Structure

`DisputeRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `create_time` | `String` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` |
| `dispute_amount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. |
| `dispute_id` | `String` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` |
| `dispute_life_cycle_stage` | [`DisputeLifeCycleStageEnum`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. |
| `dispute_state` | String \| nil | Optional | This is a container for any-of cases. |
| `reason` | [`Reason2Enum`](../../doc/models/reason-2-enum.md) | Required | Reason. |
| `seller_response_due_date` | String \| nil | Optional | This is a container for any-of cases. |
| `status` | [`Status3Enum`](../../doc/models/status-3-enum.md) | Required | Status. |
| `update_time` | String \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
dispute_record = DisputeRecord.new(
  'create_time6',
  ProviderMoney.new(
    'currency_code6',
    'value0'
  ),
  'dispute_id2',
  DisputeLifeCycleStageEnum::UNKNOWN,
  Reason2Enum::INCORRECT_AMOUNT,
  Status3Enum::CLOSED,
  'String9',
  'String9',
  'String9'
)
```

