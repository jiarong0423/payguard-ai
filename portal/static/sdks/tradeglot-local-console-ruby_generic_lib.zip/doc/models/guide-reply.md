
# Guide Reply

GuideReply.

## Structure

`GuideReply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chooser` | [`ChooserEnum`](../../doc/models/chooser-enum.md) | Required | Chooser. |
| `dropped` | [`Array[GuideDropped]`](../../doc/models/guide-dropped.md) | Required | Dropped. |
| `fallback_reason` | [FallbackReason](../../doc/models/fallback-reason-enum.md) | Required | This is a container for any-of cases. |
| `state_changed` | `TrueClass \| FalseClass` | Required | State changed. |
| `template` | [`TemplateEnum`](../../doc/models/template-enum.md) | Required | Template. |
| `text` | `String` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```ruby
guide_reply = GuideReply.new(
  ChooserEnum::MODEL,
  [
    GuideDropped.new(
      'item2',
      Reason6Enum::OTHER_PARTY
    )
  ],
  FallbackReasonEnum::BUDGET,
  false,
  TemplateEnum::OTHER_PARTY,
  'text2'
)
```

