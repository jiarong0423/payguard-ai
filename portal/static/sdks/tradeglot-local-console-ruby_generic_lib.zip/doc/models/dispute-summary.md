
# Dispute Summary

DisputeSummary.

## Structure

`DisputeSummary`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | `String` | Required | Case ref. |
| `dispute_amount` | [`SyntheticMoney`](../../doc/models/synthetic-money.md) | Required | Same shape as the PayPal Disputes `dispute_amount` (ProviderMoney below); values are synthetic. |
| `opened_at` | `String` | Required | Opened at. |
| `order_ref` | `String` | Required | Order ref. |
| `reason` | `String` | Required | Reason. |
| `seller_response_due_date` | `String` | Required | Seller response due date. |
| `status` | [`Status7Enum`](../../doc/models/status-7-enum.md) | Required | Status. |

## Example

```ruby
dispute_summary = DisputeSummary.new(
  'case_ref6',
  SyntheticMoney.new(
    'currency_code6',
    'value0'
  ),
  'opened_at0',
  'order_ref8',
  'reason8',
  'seller_response_due_date0',
  Status7Enum::LOCAL_DRAFT_REVIEWED
)
```

