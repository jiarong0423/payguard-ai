
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```ruby
source5 = Source5Enum::PROVIDER
```

