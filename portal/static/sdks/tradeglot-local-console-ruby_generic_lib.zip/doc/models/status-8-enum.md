
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `ANALYSING` |
| `REPLACED` |
| `KEPT` |

## Example

```ruby
status8 = Status8Enum::REPLACED
```

