
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |
| `FIXTURE` |

## Example

```ruby
data_source_label = DataSourceLabelEnum::SANDBOX
```

