
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `NORMAL` |
| `REVIEW_VELOCITY` |
| `INSUFFICIENT_BASELINE` |

## Example

```ruby
status14 = Status14Enum::REVIEW_VELOCITY
```

