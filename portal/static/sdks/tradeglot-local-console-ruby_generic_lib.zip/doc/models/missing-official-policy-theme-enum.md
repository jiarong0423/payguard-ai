
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```ruby
missing_official_policy_theme = MissingOfficialPolicyThemeEnum::VELOCITY_GUARD
```

