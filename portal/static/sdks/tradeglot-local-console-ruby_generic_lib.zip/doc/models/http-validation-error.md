
# HTTP Validation Error

HTTPValidationError.

## Structure

`HTTPValidationError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `detail` | [`Array[ValidationError]`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```ruby
http_validation_error = HTTPValidationError.new(
  [
    ValidationError.new(
      [
        'String7',
        'String8',
        'String9'
      ],
      'msg2',
      'type4',
      { 'key1' => 'val1', 'key2' => 'val2' },
      JSON.parse('{"key1":"val1","key2":"val2"}')
    ),
    ValidationError.new(
      [
        'String7',
        'String8',
        'String9'
      ],
      'msg2',
      'type4',
      { 'key1' => 'val1', 'key2' => 'val2' },
      JSON.parse('{"key1":"val1","key2":"val2"}')
    )
  ]
)
```

