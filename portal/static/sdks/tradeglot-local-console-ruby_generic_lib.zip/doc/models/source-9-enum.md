
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `WORDS` |
| `WORDS_PENDING` |

## Example

```ruby
source9 = Source9Enum::WORDS
```

