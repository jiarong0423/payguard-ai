
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POST_RESPONSE_ONLY` |

## Example

```ruby
proof_kind = ProofKindEnum::POST_RESPONSE_ONLY
```

