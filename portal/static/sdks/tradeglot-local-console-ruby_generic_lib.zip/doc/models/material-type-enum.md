
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |

## Example

```ruby
material_type = MaterialTypeEnum::OFFICIAL_API_REFERENCE
```

