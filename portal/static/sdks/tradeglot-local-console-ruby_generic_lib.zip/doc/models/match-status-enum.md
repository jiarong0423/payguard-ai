
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NO_MATCH` |
| `REVIEW_SIGNAL` |

## Example

```ruby
match_status = MatchStatusEnum::NO_MATCH
```

