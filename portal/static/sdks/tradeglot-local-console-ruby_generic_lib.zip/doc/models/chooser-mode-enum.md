
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `KEYWORD` |
| `GEMINI` |

## Example

```ruby
chooser_mode = ChooserModeEnum::KEYWORD
```

