
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATE_MESSAGE` |

## Example

```ruby
channel = ChannelEnum::EMAIL
```

