
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `affects_decision` | `String` | Required, Constant | Affects decision.<br><br>**Value**: `'False'` |
| `reason` | [Reason](../../doc/models/reason-enum.md) | Required | This is a container for any-of cases. |
| `signal` | [CategorySignal](../../doc/models/category-signal.md) | Required | This is a container for any-of cases. |
| `status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Required | Status. |

## Example

```ruby
aup_category_signal_response = AupCategorySignalResponse.new(
  'False',
  ReasonEnum::TIMEOUT,
  CategorySignal.new(
    'String9',
    ConfidenceEnum::HIGH,
    'channel3'
  ),
  Status2Enum::OFF
)
```

