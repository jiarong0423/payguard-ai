
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action` | [`ActionEnum`](../../doc/models/action-enum.md) | Optional | Action. |
| `environment` | [`EnvironmentEnum`](../../doc/models/environment-enum.md) | Optional | Environment. |
| `evidence_class` | [`EvidenceClass3Enum`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. |
| `external_send` | [`ExternalSend1Enum`](../../doc/models/external-send-1-enum.md) | Optional | External send. |
| `invoice_id` | String \| nil | Optional | This is a container for any-of cases. |
| `observed_at` | `String` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` |
| `paypal_debug_id` | String \| nil | Optional | This is a container for any-of cases. |
| `proof_kind` | [`ProofKindEnum`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. |
| `schema_version` | [`SchemaVersion1Enum`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. |
| `separate_get_readback` | `TrueClass \| FalseClass` | Optional | Separate get readback. |
| `status` | [`Status10Enum`](../../doc/models/status-10-enum.md) | Optional | Status. |

## Example

```ruby
evidence_receipt = EvidenceReceipt.new(
  ActionEnum::OAUTH_CONNECT,
  EnvironmentEnum::SANDBOX,
  EvidenceClass3Enum::AUTHENTIC_SANDBOX_RESPONSE,
  ExternalSend1Enum::FROZEN,
  'String3',
  nil,
  nil,
  envrr,
  envrr,
  nil,
  envrr
)
```

