
# Model Enum

Model.

## Enumeration

`ModelEnum`

## Fields

| Name |
|  --- |
| `ENUM_GEMINI38FLASH` |
| `NVIDIANEMOTRON3NANO4B` |

## Example

```ruby
model = ModelEnum::ENUM_GEMINI38FLASH
```

