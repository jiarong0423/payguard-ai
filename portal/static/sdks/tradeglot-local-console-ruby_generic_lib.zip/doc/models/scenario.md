
# Scenario

Scenario.

## Structure

`Scenario`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `burst` | `TrueClass \| FalseClass` | Required | Burst. |
| `dispute` | `TrueClass \| FalseClass` | Required | Dispute. |

## Example

```ruby
scenario = Scenario.new(
  false,
  false
)
```

