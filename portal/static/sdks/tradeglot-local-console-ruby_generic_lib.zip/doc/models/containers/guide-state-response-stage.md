
# Guide State Response Stage

## Data Type

`Stage3Enum`

## Cases

| Type |
|  --- |
| [`Stage3Enum`](../../../doc/models/stage-3-enum.md) |

## Stage3Enum

### Initialization Code

#### Example

```ruby
value = Stage3Enum::FUNNEL
```

