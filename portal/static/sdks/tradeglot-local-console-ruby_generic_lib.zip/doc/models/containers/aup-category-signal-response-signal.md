
# Aup Category Signal Response Signal

## Data Type

`CategorySignal`

## Cases

| Type |
|  --- |
| [`CategorySignal`](../../../doc/models/category-signal.md) |

## CategorySignal

### Initialization Code

#### Example

```ruby
value = CategorySignal.new(
  'String9',
  ConfidenceEnum::HIGH,
  'channel3'
)
```

