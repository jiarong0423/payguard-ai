
# Guide Item Form

## Data Type

`GuideForm`

## Cases

| Type |
|  --- |
| [`GuideForm`](../../../doc/models/guide-form.md) |

## GuideForm

### Initialization Code

#### Example

```ruby
value = GuideForm.new(
  Kind2Enum::CHOICE,
  [
    GuideOption.new(
      'label2',
      'value4'
    )
  ],
  'String9'
)
```

