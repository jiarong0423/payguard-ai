
# Guide State Response Reply

## Data Type

`GuideReply`

## Cases

| Type |
|  --- |
| [`GuideReply`](../../../doc/models/guide-reply.md) |

## GuideReply

### Initialization Code

#### Example

```ruby
value = GuideReply.new(
  ChooserEnum::FORM,
  [
    GuideDropped.new(
      'item2',
      Reason6Enum::OTHER_PARTY
    )
  ],
  FallbackReasonEnum::LATE,
  false,
  TemplateEnum::REVIEW,
  'text0'
)
```

