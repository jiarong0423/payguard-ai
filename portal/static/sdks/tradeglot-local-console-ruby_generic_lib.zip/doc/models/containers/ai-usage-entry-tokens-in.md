
# Ai Usage Entry Tokens In

## Data Type

`Integer`

## Cases

| Type |
|  --- |
| `Integer` |

## Integer

### Initialization Code

#### Example

```ruby
value = 0
```

