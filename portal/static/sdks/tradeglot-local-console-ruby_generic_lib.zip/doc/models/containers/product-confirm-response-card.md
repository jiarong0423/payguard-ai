
# Product Confirm Response Card

## Data Type

`ProductCard`

## Cases

| Type |
|  --- |
| [`ProductCard`](../../../doc/models/product-card.md) |

## ProductCard

### Initialization Code

#### Example

```ruby
value = ProductCard.new(
  'String9',
  'String3',
  'String1',
  [
    'key_features0',
    'key_features1',
    'key_features2'
  ],
  [
    'materials5',
    'materials6'
  ],
  'product_id0',
  'title0'
)
```

