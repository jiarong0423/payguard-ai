
# Aup Category Signal Response Reason

## Data Type

`ReasonEnum`

## Cases

| Type |
|  --- |
| [`ReasonEnum`](../../../doc/models/reason-enum.md) |

## ReasonEnum

### Initialization Code

#### Example

```ruby
value = ReasonEnum::NOTHING_TO_SEND
```

