
# Dispute Detail Response Dispute State

## Data Type

`String`

## Cases

| Type |
|  --- |
| `String` |

## String

### Initialization Code

#### Example

```ruby
value = 'String0'
```

