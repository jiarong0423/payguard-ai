
# Ai Usage Entry Tokens Out

## Data Type

`Integer`

## Cases

| Type |
|  --- |
| `Integer` |

## Integer

### Initialization Code

#### Example

```ruby
value = 0
```

