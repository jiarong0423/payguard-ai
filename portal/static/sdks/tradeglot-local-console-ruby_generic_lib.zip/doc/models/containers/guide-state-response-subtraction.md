
# Guide State Response Subtraction

## Data Type

`GuideSubtraction`

## Cases

| Type |
|  --- |
| [`GuideSubtraction`](../../../doc/models/guide-subtraction.md) |

## GuideSubtraction

### Initialization Code

#### Example

```ruby
value = GuideSubtraction.new(
  64,
  190,
  178,
  'text0'
)
```

