
# Reference Filters Max Source Age Days

## Data Type

`Integer`

## Cases

| Type |
|  --- |
| `Integer` |

## Integer

### Initialization Code

#### Example

```ruby
value = 0
```

