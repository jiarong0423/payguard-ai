
# Category Signal Confidence

## Data Type

`ConfidenceEnum`

## Cases

| Type |
|  --- |
| [`ConfidenceEnum`](../../../doc/models/confidence-enum.md) |

## ConfidenceEnum

### Initialization Code

#### Example

```ruby
value = ConfidenceEnum::HIGH
```

