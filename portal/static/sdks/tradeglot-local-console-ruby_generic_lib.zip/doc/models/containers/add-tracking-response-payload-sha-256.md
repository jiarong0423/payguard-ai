
# Add Tracking Response Payload Sha 256

## Data Type

`String`

## Cases

| Type |
|  --- |
| `String` |

## String

### Initialization Code

#### Example

```ruby
value = 'String0'
```

