
# Disputed Transaction Gross Amount

## Data Type

`ProviderMoney`

## Cases

| Type |
|  --- |
| [`ProviderMoney`](../../../doc/models/provider-money.md) |

## ProviderMoney

### Initialization Code

#### Example

```ruby
value = ProviderMoney.new(
  'currency_code0',
  'value6'
)
```

