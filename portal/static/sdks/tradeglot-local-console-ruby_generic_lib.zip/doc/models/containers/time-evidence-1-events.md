
# Time Evidence 1 Events

## Data Type

`MessageTimeEvent | TimeEvent`

## Cases

| Type |
|  --- |
| [`MessageTimeEvent`](../../../doc/models/message-time-event.md) |
| [`TimeEvent`](../../../doc/models/time-event.md) |

## MessageTimeEvent

### Initialization Code

#### Example

```ruby
value = MessageTimeEvent.new(
  'at4',
  ChannelEnum::EMAIL,
  DirectionEnum::INBOUND,
  'MESSAGE',
  'message_digest2',
  'SELLER_PROVIDED_UNVERIFIED',
  TopicEnum::ORDER_DETAILS_PROVIDED
)
```

## TimeEvent

### Initialization Code

#### Example

```ruby
value = TimeEvent.new(
  'at2',
  KindEnum::DELIVERY,
  Source5Enum::PROVIDER
)
```

