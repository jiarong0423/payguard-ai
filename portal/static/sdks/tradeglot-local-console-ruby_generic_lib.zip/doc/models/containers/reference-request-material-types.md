
# Reference Request Material Types

## Data Type

`Array[MaterialType4Enum]`

## Cases

| Type |
|  --- |
| [`Array[MaterialType4Enum]`](../../../doc/models/material-type-4-enum.md) |

## Array[MaterialType4Enum]

### Initialization Code

#### Example

```ruby
value = [
  MaterialType4Enum::PUBLIC_COURT_ORDER_COPY
]
```

