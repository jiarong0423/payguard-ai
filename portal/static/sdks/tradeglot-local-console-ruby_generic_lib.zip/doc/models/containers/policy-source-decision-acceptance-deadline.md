
# Policy Source Decision Acceptance Deadline

## Data Type

`String`

## Cases

| Type |
|  --- |
| `String` |

## String

### Initialization Code

#### Example

```ruby
value = 'String0'
```

