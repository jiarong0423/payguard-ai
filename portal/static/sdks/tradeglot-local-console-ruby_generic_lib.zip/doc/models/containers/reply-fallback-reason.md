
# Reply Fallback Reason

## Data Type

`FallbackReasonEnum`

## Cases

| Type |
|  --- |
| [`FallbackReasonEnum`](../../../doc/models/fallback-reason-enum.md) |

## FallbackReasonEnum

### Initialization Code

#### Example

```ruby
value = FallbackReasonEnum::BUDGET
```

