
# Aup Acknowledge Response Expires At

## Data Type

`String`

## Cases

| Type |
|  --- |
| `String` |

## String

### Initialization Code

#### Example

```ruby
value = 'String0'
```

