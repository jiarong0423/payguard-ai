
# Send Guard Send Refusal

## Data Type

`SendRefusalEnum`

## Cases

| Type |
|  --- |
| [`SendRefusalEnum`](../../../doc/models/send-refusal-enum.md) |

## SendRefusalEnum

### Initialization Code

#### Example

```ruby
value = SendRefusalEnum::ACCOUNT_IDENTITY_UNKNOWN
```

