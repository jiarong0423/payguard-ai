
# Guide State Response Form Result

## Data Type

`GuideFormResult`

## Cases

| Type |
|  --- |
| [`GuideFormResult`](../../../doc/models/guide-form-result.md) |

## GuideFormResult

### Initialization Code

#### Example

```ruby
value = GuideFormResult.new(
  'item2',
  false
)
```

