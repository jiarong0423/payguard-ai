
# Guide State Response Analysis

## Data Type

`GuideAnalysis`

## Cases

| Type |
|  --- |
| [`GuideAnalysis`](../../../doc/models/guide-analysis.md) |

## GuideAnalysis

### Initialization Code

#### Example

```ruby
value = GuideAnalysis.new(
  Reason5Enum::INVALID_REPLY,
  Status8Enum::REPLACED,
  186
)
```

