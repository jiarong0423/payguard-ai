
# Disputed Transaction Seller Protection Eligible

## Data Type

`TrueClass | FalseClass`

## Cases

| Type |
|  --- |
| `TrueClass \| FalseClass` |

## TrueClass | FalseClass

### Initialization Code

#### Example

```ruby
value = false
```

