
# Ai Usage Entry Tokens Total

## Data Type

`Integer`

## Cases

| Type |
|  --- |
| `Integer` |

## Integer

### Initialization Code

#### Example

```ruby
value = 0
```

