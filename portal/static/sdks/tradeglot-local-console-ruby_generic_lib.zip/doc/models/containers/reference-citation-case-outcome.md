
# Reference Citation Case Outcome

## Data Type

`CaseOutcomeEnum`

## Cases

| Type |
|  --- |
| [`CaseOutcomeEnum`](../../../doc/models/case-outcome-enum.md) |

## CaseOutcomeEnum

### Initialization Code

#### Example

```ruby
value = CaseOutcomeEnum::SETTLEMENT_APPROVAL_NOT_FINAL_MERITS
```

