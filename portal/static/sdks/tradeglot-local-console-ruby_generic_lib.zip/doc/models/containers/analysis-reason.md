
# Analysis Reason

## Data Type

`Reason5Enum`

## Cases

| Type |
|  --- |
| [`Reason5Enum`](../../../doc/models/reason-5-enum.md) |

## Reason5Enum

### Initialization Code

#### Example

```ruby
value = Reason5Enum::BUDGET
```

