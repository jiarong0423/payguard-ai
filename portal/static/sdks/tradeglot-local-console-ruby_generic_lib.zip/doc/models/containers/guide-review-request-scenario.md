
# Guide Review Request Scenario

## Data Type

`Scenario1Enum`

## Cases

| Type |
|  --- |
| [`Scenario1Enum`](../../../doc/models/scenario-1-enum.md) |

## Scenario1Enum

### Initialization Code

#### Example

```ruby
value = Scenario1Enum::PREFLIGHT
```

