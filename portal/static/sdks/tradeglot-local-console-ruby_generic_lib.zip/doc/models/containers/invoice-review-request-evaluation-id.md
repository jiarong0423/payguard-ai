
# Invoice Review Request Evaluation Id

## Data Type

`String`

## Cases

| Type |
|  --- |
| `String` |

## String

### Initialization Code

#### Example

```ruby
value = 'String0'
```

