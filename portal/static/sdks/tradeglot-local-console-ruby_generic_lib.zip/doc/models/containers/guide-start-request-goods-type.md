
# Guide Start Request Goods Type

## Data Type

`GoodsTypeEnum`

## Cases

| Type |
|  --- |
| [`GoodsTypeEnum`](../../../doc/models/goods-type-enum.md) |

## GoodsTypeEnum

### Initialization Code

#### Example

```ruby
value = GoodsTypeEnum::PHYSICAL
```

