
# Guide Turn Request Fields

## Data Type

`Array[GuideField]`

## Cases

| Type |
|  --- |
| [`Array[GuideField]`](../../../doc/models/guide-field.md) |

## Array[GuideField]

### Initialization Code

#### Example

```ruby
value = [
  GuideField.new(
    'item8',
    'value8'
  )
]
```

