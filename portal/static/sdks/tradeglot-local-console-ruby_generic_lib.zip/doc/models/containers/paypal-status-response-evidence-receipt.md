
# Paypal Status Response Evidence Receipt

## Data Type

`SandboxEvidenceReceipt`

## Cases

| Type |
|  --- |
| [`SandboxEvidenceReceipt`](../../../doc/models/sandbox-evidence-receipt.md) |

## SandboxEvidenceReceipt

### Initialization Code

#### Example

```ruby
value = SandboxEvidenceReceipt.new(
  ActionEnum::OAUTH_CONNECT,
  'sandbox',
  EvidenceClass3Enum::AUTHENTIC_SANDBOX_RESPONSE,
  'FROZEN',
  'String5',
  'observed_at8',
  'String5',
  'POST_RESPONSE_ONLY',
  1,
  'False',
  Status10Enum::CONNECTED
)
```

