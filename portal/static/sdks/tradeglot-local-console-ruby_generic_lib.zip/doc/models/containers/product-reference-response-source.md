
# Product Reference Response Source

## Data Type

`Source11Enum`

## Cases

| Type |
|  --- |
| [`Source11Enum`](../../../doc/models/source-11-enum.md) |

## Source11Enum

### Initialization Code

#### Example

```ruby
value = Source11Enum::CHANNEL3_LIVE
```

