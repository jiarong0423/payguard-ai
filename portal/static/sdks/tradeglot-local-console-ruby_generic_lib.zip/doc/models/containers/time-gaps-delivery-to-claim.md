
# Time Gaps Delivery to Claim

## Data Type

`Integer`

## Cases

| Type |
|  --- |
| `Integer` |

## Integer

### Initialization Code

#### Example

```ruby
value = 0
```

