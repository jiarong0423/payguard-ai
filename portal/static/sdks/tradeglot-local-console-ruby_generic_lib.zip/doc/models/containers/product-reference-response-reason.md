
# Product Reference Response Reason

## Data Type

`Reason7Enum`

## Cases

| Type |
|  --- |
| [`Reason7Enum`](../../../doc/models/reason-7-enum.md) |

## Reason7Enum

### Initialization Code

#### Example

```ruby
value = Reason7Enum::NOTHING_TO_SEND
```

