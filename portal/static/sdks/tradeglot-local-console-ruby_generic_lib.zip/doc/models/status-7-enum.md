
# Status 7 Enum

Status.

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `NEEDS_REVIEW` |
| `DRAFT_READY` |
| `LOCAL_DRAFT_REVIEWED` |

## Example

```ruby
status7 = Status7Enum::NEEDS_REVIEW
```

