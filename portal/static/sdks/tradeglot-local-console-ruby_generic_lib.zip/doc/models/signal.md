
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | String \| nil | Optional | This is a container for any-of cases. |
| `confidence` | [Confidence](../../doc/models/confidence-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `source` | [`Source2Enum`](../../doc/models/source-2-enum.md) | Optional | Source. |

## Example

```ruby
signal = Signal.new(
  'String1',
  ConfidenceEnum::HIGH,
  Source2Enum::CHANNEL3
)
```

