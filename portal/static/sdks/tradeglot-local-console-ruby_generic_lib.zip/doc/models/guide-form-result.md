
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `String` | Required | Item. |
| `valid` | `TrueClass \| FalseClass` | Required | Valid. |

## Example

```ruby
guide_form_result = GuideFormResult.new(
  'item8',
  false
)
```

