
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_ACCOUNT` |
| `GUEST_CARD` |

## Example

```ruby
checkout = CheckoutEnum::PAYPAL_ACCOUNT
```

