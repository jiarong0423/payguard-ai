
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3` |

## Example

```ruby
source2 = Source2Enum::CHANNEL3
```

