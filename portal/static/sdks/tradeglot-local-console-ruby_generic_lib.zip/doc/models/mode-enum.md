
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `HOSTED_DEMO` |

## Example

```ruby
mode = ModeEnum::LOCAL
```

