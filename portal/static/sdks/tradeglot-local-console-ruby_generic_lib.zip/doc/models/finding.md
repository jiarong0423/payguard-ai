
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | [`CategoryEnum`](../../doc/models/category-enum.md) | Required | Category. |
| `code` | `String` | Required, Constant | Code.<br><br>**Value**: `'keyword_requires_policy_review'` |

## Example

```ruby
finding = Finding.new(
  CategoryEnum::UNSUPPORTED_FINANCIAL_PROMISE,
  'keyword_requires_policy_review'
)
```

