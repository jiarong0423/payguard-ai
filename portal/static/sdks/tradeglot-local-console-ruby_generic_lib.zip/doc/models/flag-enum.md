
# Flag Enum

## Enumeration

`FlagEnum`

## Fields

| Name |
|  --- |
| `ORDER_RECORD_ABSENT` |
| `DELIVERY_NOT_RECORDED` |
| `DELIVERY_AFTER_CLAIM` |
| `CLAIM_TIME_EARLIER_THAN_PAYMENT_TIME` |

## Example

```ruby
flag = FlagEnum::ORDER_RECORD_ABSENT
```

