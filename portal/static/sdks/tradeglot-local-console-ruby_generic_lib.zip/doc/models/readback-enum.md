
# Readback Enum

Readback.

## Enumeration

`ReadbackEnum`

## Fields

| Name |
|  --- |
| `ADD_TRACKING_PREVIEW` |
| `ADD_TRACKING_SUBMITTED` |

## Example

```ruby
readback = ReadbackEnum::ADD_TRACKING_PREVIEW
```

