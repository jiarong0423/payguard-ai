
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |
| `PUBLIC_COURT_ORDER_COPY` |

## Example

```ruby
material_type4 = MaterialType4Enum::PUBLIC_COURT_ORDER_COPY
```

