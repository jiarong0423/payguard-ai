
# Identity Redaction

IdentityRedaction.

## Structure

`IdentityRedaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fields` | [`Array[FieldEnum]`](../../doc/models/field-enum.md) | Required | Fields. |
| `method` | `String` | Required, Constant | Method.<br><br>**Value**: `'HMAC-SHA256 pseudonymization'` |
| `synthetic` | `String` | Required, Constant | Synthetic.<br><br>**Value**: `'True'` |
| `tokens` | [`IdentityTokens`](../../doc/models/identity-tokens.md) | Required | IdentityTokens. |

## Example

```ruby
identity_redaction = IdentityRedaction.new(
  [
    FieldEnum::ADDRESS,
    FieldEnum::EMAIL,
    FieldEnum::NAME
  ],
  'HMAC-SHA256 pseudonymization',
  'True',
  IdentityTokens.new(
    'address_token0',
    'email_token2',
    'name_token0'
  )
)
```

