
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `REFERENCES_FOUND` |
| `EVIDENCE_MISSING` |

## Example

```ruby
status13 = Status13Enum::REFERENCES_FOUND
```

