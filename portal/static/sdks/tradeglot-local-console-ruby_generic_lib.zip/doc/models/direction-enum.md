
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```ruby
direction = DirectionEnum::INBOUND
```

