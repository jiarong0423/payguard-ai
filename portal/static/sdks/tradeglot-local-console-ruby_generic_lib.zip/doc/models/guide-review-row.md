
# Guide Review Row

GuideReviewRow.

## Structure

`GuideReviewRow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `String` | Required | Item. |
| `source` | [`Source9Enum`](../../doc/models/source-9-enum.md) | Required | Source. |
| `value` | `String` | Required | Value.<br><br>**Constraints**: *Maximum Length*: `120` |

## Example

```ruby
guide_review_row = GuideReviewRow.new(
  'item2',
  Source9Enum::WORDS,
  'value2'
)
```

