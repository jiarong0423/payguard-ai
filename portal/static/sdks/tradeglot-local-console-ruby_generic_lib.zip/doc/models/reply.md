
# Reply

Reply.

## Structure

`Reply`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chooser` | [`ChooserEnum`](../../doc/models/chooser-enum.md) | Optional | Chooser. |
| `dropped` | [`Array[GuideDropped]`](../../doc/models/guide-dropped.md) | Optional | Dropped. |
| `fallback_reason` | [FallbackReason](../../doc/models/fallback-reason-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `state_changed` | `TrueClass \| FalseClass` | Optional | State changed. |
| `template` | [`TemplateEnum`](../../doc/models/template-enum.md) | Optional | Template. |
| `text` | `String` | Optional | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `400` |

## Example

```ruby
reply = Reply.new(
  ChooserEnum::KEYWORD,
  [
    GuideDropped.new(
      'item2',
      Reason6Enum::OTHER_PARTY
    ),
    GuideDropped.new(
      'item2',
      Reason6Enum::OTHER_PARTY
    )
  ],
  FallbackReasonEnum::PROVIDER_ERROR,
  false,
  TemplateEnum::SUBTRACTION
)
```

