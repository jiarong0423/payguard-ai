
# Guide Analysis

GuideAnalysis.

## Structure

`GuideAnalysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [Reason5](../../doc/models/reason-5-enum.md) | Required | This is a container for any-of cases. |
| `status` | [`Status8Enum`](../../doc/models/status-8-enum.md) | Required | Status. |
| `turn` | `Integer` | Required | Turn. |

## Example

```ruby
guide_analysis = GuideAnalysis.new(
  Reason5Enum::BUDGET,
  Status8Enum::REPLACED,
  142
)
```

