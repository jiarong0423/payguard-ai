
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```ruby
due_state = DueStateEnum::OPEN
```

