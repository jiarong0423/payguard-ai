
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```ruby
account_status = AccountStatusEnum::MATCH
```

