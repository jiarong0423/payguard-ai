
# Status 9 Enum

Status.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `STRUCTURALLY_PRESENT` |
| `PARTIAL` |
| `UNCLEAR` |
| `CONFLICTING` |
| `MISSING` |
| `NOT_APPLICABLE` |

## Example

```ruby
status9 = Status9Enum::STRUCTURALLY_PRESENT
```

