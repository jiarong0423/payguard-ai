
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `KEYWORD` |
| `MODEL` |
| `KEYWORD_FALLBACK` |
| `FORM` |

## Example

```ruby
chooser = ChooserEnum::FORM
```

