
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `US_PHONE` |
| `ID_LIKE` |
| `NAME` |
| `ADDRESS` |
| `MANUAL` |
| `MIXED` |

## Example

```ruby
type = TypeEnum::MANUAL
```

