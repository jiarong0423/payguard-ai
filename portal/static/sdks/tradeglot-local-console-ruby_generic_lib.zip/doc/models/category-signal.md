
# Category Signal

CategorySignal.

## Structure

`CategorySignal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category` | String | Required | This is a container for any-of cases. |
| `confidence` | [Confidence](../../doc/models/confidence-enum.md) | Required | This is a container for any-of cases. |
| `source` | `String` | Required, Constant | Source.<br><br>**Value**: `'channel3'` |

## Example

```ruby
category_signal = CategorySignal.new(
  'String9',
  ConfidenceEnum::HIGH,
  'channel3'
)
```

