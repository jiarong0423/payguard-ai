
# HTTP Validation Error Exception

HTTPValidationError.

## Structure

`HTTPValidationErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `detail` | [`Array[ValidationError]`](../../doc/models/validation-error.md) | Optional | Detail. |

## Example

```ruby
begin
  # make the API call
rescue HTTPValidationErrorException => e
  puts "Caught HTTPValidationErrorException: #{e.message}"
end
```

