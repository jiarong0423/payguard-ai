
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `EXACT` |
| `CLOSE` |

## Example

```ruby
match_type = MatchTypeEnum::EXACT
```

