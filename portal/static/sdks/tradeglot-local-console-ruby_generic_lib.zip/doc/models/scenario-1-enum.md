
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```ruby
scenario1 = Scenario1Enum::VELOCITY
```

