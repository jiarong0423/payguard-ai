
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `NAME` |
| `ADDRESS` |
| `EMAIL` |

## Example

```ruby
field = FieldEnum::ADDRESS
```

