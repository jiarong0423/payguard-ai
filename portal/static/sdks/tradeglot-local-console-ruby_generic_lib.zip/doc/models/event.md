
# Event

## Structure

`Event`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `at` | `String` | Optional | At.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `40` |
| `channel` | [`ChannelEnum`](../../doc/models/channel-enum.md) | Optional | Channel. |
| `direction` | [`DirectionEnum`](../../doc/models/direction-enum.md) | Optional | Direction. |
| `kind` | [`Kind1Enum`](../../doc/models/kind-1-enum.md) | Optional | Kind. |
| `message_digest` | `String` | Optional | Message digest.<br><br>**Constraints**: *Pattern*: `^[0-9a-f]{64}$` |
| `source` | [`Source6Enum`](../../doc/models/source-6-enum.md) | Optional | Source. |
| `topic` | [`TopicEnum`](../../doc/models/topic-enum.md) | Optional | Topic. |

## Example

```ruby
event = Event.new(
  'at6',
  ChannelEnum::EMAIL,
  DirectionEnum::INBOUND,
  Kind1Enum::MESSAGE,
  'message_digest6',
  envrr,
  envrr
)
```

