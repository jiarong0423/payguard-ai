
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASE_NOT_ACTIONABLE` |
| `MANUAL_REVIEW` |
| `DUE_DATE_EXPIRED` |
| `ACTION_NOT_AVAILABLE` |
| `NEEDS_INPUT` |
| `READY_FOR_LOCAL_REVIEW` |

## Example

```ruby
overall_state = OverallStateEnum::DUE_DATE_EXPIRED
```

