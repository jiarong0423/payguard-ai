
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `BEFORE_CUTOFF` |
| `AFTER_CUTOFF` |

## Example

```ruby
account_opened = AccountOpenedEnum::AFTER_CUTOFF
```

