
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [Reason5](../../doc/models/reason-5-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `status` | [`Status8Enum`](../../doc/models/status-8-enum.md) | Optional | Status. |
| `turn` | `Integer` | Optional | Turn. |

## Example

```ruby
analysis = Analysis.new(
  Reason5Enum::INVALID_REPLY,
  Status8Enum::REPLACED,
  198
)
```

