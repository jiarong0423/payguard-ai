
# Reference Digests

ReferenceDigests.

## Structure

`ReferenceDigests`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `chunks_sha_256` | `String` | Required | Chunks sha256.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |
| `sources_sha_256` | `String` | Required | Sources sha256.<br><br>**Constraints**: *Pattern*: `^[a-f0-9]{64}$` |

## Example

```ruby
reference_digests = ReferenceDigests.new(
  'chunks_sha2564',
  'sources_sha2566'
)
```

