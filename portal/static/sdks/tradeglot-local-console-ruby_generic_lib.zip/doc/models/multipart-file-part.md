
# Multipart File Part

MultipartFilePart.

## Structure

`MultipartFilePart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `byte_length` | `Integer` | Required | Byte length.<br><br>**Constraints**: `>= 0`, `<= 9999999` |
| `content_type` | [`ContentTypeEnum`](../../doc/models/content-type-enum.md) | Required | Content type. |
| `filename` | `String` | Required | Filename.<br><br>**Constraints**: *Maximum Length*: `255` |
| `name` | `String` | Required | Name.<br><br>**Constraints**: *Pattern*: `^file[0-9]{1,3}$` |

## Example

```ruby
multipart_file_part = MultipartFilePart.new(
  18,
  ContentTypeEnum::ENUM_IMAGEJPEG,
  'filename4',
  'name2'
)
```

