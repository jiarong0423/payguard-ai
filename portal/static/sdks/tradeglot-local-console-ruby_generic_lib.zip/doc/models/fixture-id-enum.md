
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `PAYGUARDFIXEDSYNTHETICBRIEFV1` |
| `PAYGUARDSESSIONBRIEFV1` |

## Example

```ruby
fixture_id = FixtureIdEnum::PAYGUARDFIXEDSYNTHETICBRIEFV1
```

