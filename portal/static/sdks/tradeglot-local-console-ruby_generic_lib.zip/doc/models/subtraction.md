
# Subtraction

Subtraction.

## Structure

`Subtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `left` | `Integer` | Optional | Left. |
| `needed` | `Integer` | Optional | Needed. |
| `taken` | `Integer` | Optional | Taken. |
| `text` | `String` | Optional | Text. |

## Example

```ruby
subtraction = Subtraction.new(
  232,
  102,
  90,
  'text6'
)
```

