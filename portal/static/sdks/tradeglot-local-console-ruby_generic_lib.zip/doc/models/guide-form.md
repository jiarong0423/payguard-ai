
# Guide Form

GuideForm.

## Structure

`GuideForm`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Required | Kind. |
| `options` | [`Array[GuideOption]`](../../doc/models/guide-option.md) | Required | Options. |
| `placeholder` | String | Required | This is a container for any-of cases. |

## Example

```ruby
guide_form = GuideForm.new(
  Kind2Enum::TEXT,
  [
    GuideOption.new(
      'label2',
      'value4'
    )
  ],
  'String7'
)
```

