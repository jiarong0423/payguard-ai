
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. |

## Example

```ruby
begin
  # make the API call
rescue ErrorBodyException => e
  puts "Caught ErrorBodyException: #{e.message}"
end
```

