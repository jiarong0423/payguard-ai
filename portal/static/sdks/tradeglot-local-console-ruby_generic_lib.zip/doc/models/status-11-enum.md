
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NOT_CONFIGURED` |
| `DISCONNECTED` |
| `CONNECTED` |
| `ERROR` |

## Example

```ruby
status11 = Status11Enum::CONNECTED
```

