
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_BASELINE` |
| `CALLER_SUPPLIED_UNVERIFIED` |

## Example

```ruby
baseline_provenance = BaselineProvenanceEnum::SYNTHETIC_BASELINE
```

