
# Guide Subtraction

GuideSubtraction.

## Structure

`GuideSubtraction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `left` | `Integer` | Required | Left. |
| `needed` | `Integer` | Required | Needed. |
| `taken` | `Integer` | Required | Taken. |
| `text` | `String` | Required | Text. |

## Example

```ruby
guide_subtraction = GuideSubtraction.new(
  174,
  44,
  32,
  'text2'
)
```

