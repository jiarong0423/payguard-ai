
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `READY_FOR_LOCAL_RULES` |
| `MANUAL_REVIEW` |

## Example

```ruby
intake_status = IntakeStatusEnum::READY_FOR_LOCAL_RULES
```

