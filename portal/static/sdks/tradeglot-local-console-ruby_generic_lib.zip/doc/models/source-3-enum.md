
# Source 3 Enum

Source.

## Enumeration

`Source3Enum`

## Fields

| Name |
|  --- |
| `REQUESTED_FROM_SELLER` |
| `REQUESTED_FROM_BUYER` |
| `SUBMITTED_BY_SELLER` |
| `SUBMITTED_BY_BUYER` |
| `SUBMITTED_BY_PARTNER` |
| `UNKNOWN` |

## Example

```ruby
source3 = Source3Enum::REQUESTED_FROM_SELLER
```

