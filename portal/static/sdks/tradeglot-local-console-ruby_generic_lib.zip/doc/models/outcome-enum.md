
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ERROR` |

## Example

```ruby
outcome = OutcomeEnum::OK
```

