
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONE_MATCH` |

## Example

```ruby
choice2 = Choice2Enum::CONFIRMED
```

