
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |
| `SUPERSEDED` |

## Example

```ruby
reason5 = Reason5Enum::INVALID_REPLY
```

