
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

## Example

```ruby
account_type = AccountTypeEnum::PERSONAL
```

