
# Evidence Input

EvidenceInput.

## Structure

`EvidenceInput`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `evidences` | [`Array[EvidenceInputItem]`](../../doc/models/evidence-input-item.md) | Required | Evidences.<br><br>**Constraints**: *Minimum Items*: `1`, *Maximum Items*: `20` |

## Example

```ruby
evidence_input = EvidenceInput.new(
  [
    EvidenceInputItem.new(
      EvidenceInfo.new(
        [
          TrackingInfo.new(
            CarrierNameEnum::DHL,
            'tracking_number6',
            'String1'
          )
        ]
      ),
      'evidence_type2',
      'notes2'
    )
  ]
)
```

