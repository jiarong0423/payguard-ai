
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | [`Kind2Enum`](../../doc/models/kind-2-enum.md) | Optional | Kind. |
| `options` | [`Array[GuideOption]`](../../doc/models/guide-option.md) | Optional | Options. |
| `placeholder` | String \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
form = Form.new(
  Kind2Enum::TEXT,
  [
    GuideOption.new(
      'label2',
      'value4'
    ),
    GuideOption.new(
      'label2',
      'value4'
    ),
    GuideOption.new(
      'label2',
      'value4'
    )
  ],
  'String9'
)
```

