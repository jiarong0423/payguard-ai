
# Guide Field Result

GuideFieldResult.

## Structure

`GuideFieldResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deferred` | `TrueClass \| FalseClass` | Required | Deferred. |
| `item` | `String` | Required | Item. |
| `valid` | `TrueClass \| FalseClass` | Required | Valid. |

## Example

```ruby
guide_field_result = GuideFieldResult.new(
  false,
  'item8',
  false
)
```

