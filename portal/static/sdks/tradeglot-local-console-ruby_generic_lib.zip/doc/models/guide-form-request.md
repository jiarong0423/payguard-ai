
# Guide Form Request

One field ({item, value}) or one round of up to three fields ({fields: [...]}), never both.

## Structure

`GuideFormRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `confirm_review` | `TrueClass \| FalseClass` | Optional | Confirm review.<br><br>**Default**: `false` |
| `fields` | Array[[GuideField](../../doc/models/guide-field.md)] \| nil | Optional | This is a container for any-of cases. |
| `item` | String \| nil | Optional | This is a container for any-of cases. |
| `scenario` | [Scenario1](../../doc/models/scenario-1-enum.md) \| nil | Optional | This is a container for any-of cases. |
| `value` | String \| nil | Optional | This is a container for any-of cases. |

## Example

```ruby
guide_form_request = GuideFormRequest.new(
  false,
  [
    GuideField.new(
      'item8',
      'value8'
    )
  ],
  'String9',
  Scenario1Enum::PREFLIGHT,
  'String9'
)
```

