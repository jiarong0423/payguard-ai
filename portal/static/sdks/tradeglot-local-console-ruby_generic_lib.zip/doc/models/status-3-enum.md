
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITING_FOR_SELLER_RESPONSE` |
| `WAITING_FOR_BUYER_RESPONSE` |
| `UNDER_REVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```ruby
status3 = Status3Enum::OPEN
```

