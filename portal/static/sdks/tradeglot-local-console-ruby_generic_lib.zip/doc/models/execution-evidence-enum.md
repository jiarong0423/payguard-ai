
# Execution Evidence Enum

Execution evidence.

## Enumeration

`ExecutionEvidenceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_TEST_RESPONSE` |
| `OPERATOR_LIVE_RESPONSE` |
| `LOCAL_RUNTIME_RESPONSE` |

## Example

```ruby
execution_evidence = ExecutionEvidenceEnum::OPERATOR_LIVE_RESPONSE
```

