
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```ruby
theme = ThemeEnum::SOURCE_COMPLIANCE
```

