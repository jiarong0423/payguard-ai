
# Form Result

Form result.

## Structure

`FormResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `String` | Optional | Item. |
| `valid` | `TrueClass \| FalseClass` | Optional | Valid. |

## Example

```ruby
form_result = FormResult.new(
  'item6',
  false
)
```

