
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTURE_OBSERVATION` |
| `STALE_OBSERVATION` |
| `WITHIN_OBSERVATION_BUDGET` |

## Example

```ruby
observation_status = ObservationStatusEnum::STALE_OBSERVATION
```

