
# Category Enum

Category.

## Enumeration

`CategoryEnum`

## Fields

| Name |
|  --- |
| `UNSUPPORTED_FINANCIAL_PROMISE` |
| `WEAPONS` |
| `CONTROLLED_SUBSTANCES` |
| `COUNTERFEIT_GOODS` |
| `REGULATED_ACTIVITY` |

## Example

```ruby
category = CategoryEnum::CONTROLLED_SUBSTANCES
```

