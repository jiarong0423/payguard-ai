
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `ENUM_PAYGUARDTIME_EVIDENCEV1` |

## Example

```ruby
schema_version = SchemaVersionEnum::ENUM_PAYGUARDTIME_EVIDENCEV1
```

