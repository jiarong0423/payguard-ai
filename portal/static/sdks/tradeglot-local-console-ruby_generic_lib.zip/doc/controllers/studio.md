# Studio

AG Studio agent route (local live mode only).

```ruby
studio_controller = client.studio
```

## Class Name

`StudioController`

## Methods

* [Get Studio Agent Status](../../doc/controllers/studio.md#get-studio-agent-status)
* [Post Studio Agent Turn](../../doc/controllers/studio.md#post-studio-agent-turn)


# Get Studio Agent Status

Studio Agent Status. Local console route GET /api/v1/studio/agent-status on synthetic data; advisory only.

```ruby
def get_studio_agent_status
```

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```ruby
result = studio_controller.get_studio_agent_status
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Studio Agent Turn

Studio Agent Turn. Local console route POST /api/v1/studio/agent-turn on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```ruby
def post_studio_agent_turn(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `Object` | Body, Required | - |

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```ruby
body = { 'key1' => 'val1', 'key2' => 'val2' }

result = studio_controller.post_studio_agent_turn(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

