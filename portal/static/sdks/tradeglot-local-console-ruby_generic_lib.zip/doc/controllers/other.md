# Other

Other console routes.

```ruby
other_controller = client.other
```

## Class Name

`OtherController`

## Methods

* [Post Advisory Evaluate](../../doc/controllers/other.md#post-advisory-evaluate)
* [Post Cases Route](../../doc/controllers/other.md#post-cases-route)
* [Get Connections](../../doc/controllers/other.md#get-connections)
* [Post Country Rules Check](../../doc/controllers/other.md#post-country-rules-check)
* [Get Country Rules Countries](../../doc/controllers/other.md#get-country-rules-countries)
* [Post Country Rules Search](../../doc/controllers/other.md#post-country-rules-search)
* [Post Disputes Case Ref Approve](../../doc/controllers/other.md#post-disputes-case-ref-approve)
* [Post Disputes Case Ref Draft](../../doc/controllers/other.md#post-disputes-case-ref-draft)
* [Post Policy Assess](../../doc/controllers/other.md#post-policy-assess)


# Post Advisory Evaluate

Advisory Evaluate. Local console route POST /api/v1/advisory/evaluate on synthetic data; advisory only.

```ruby
def post_advisory_evaluate(body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AdvisoryRequest`](../../doc/models/advisory-request.md) | Body, Required | JSON body for: Advisory Evaluate. |

## Response Type

**200**: Successful Response

[`AdvisoryEvaluationResponse`](../../doc/models/advisory-evaluation-response.md)

## Example Usage

```ruby
body = AdvisoryRequest.new(
  'examplexxxxxxxxxxxxx',
  'example',
  'US',
  0,
  ThemeEnum::SOURCE_COMPLIANCE
)

result = other_controller.post_advisory_evaluate(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Cases Route

Case Route. Local console route POST /api/v1/cases/route on synthetic data; advisory only.

```ruby
def post_cases_route(body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CaseRouteRequest`](../../doc/models/case-route-request.md) | Body, Required | JSON body for: Case Route. |

## Response Type

**200**: Successful Response

[`CaseRouteResponse`](../../doc/models/case-route-response.md)

## Example Usage

```ruby
body = CaseRouteRequest.new(
  'handmade ceramic coffee mug'
)

result = other_controller.post_cases_route(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Connections

Connections. Local console route GET /api/v1/connections on synthetic data; advisory only.

```ruby
def get_connections
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`ConnectionsResponse`](../../doc/models/connections-response.md)

## Example Usage

```ruby
result = other_controller.get_connections
puts result
```

## Example Response *(as JSON)*

```json
{
  "mode": "hosted_demo",
  "sandbox_reads": true
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Check

Country Rules Check. Local console route POST /api/v1/country-rules/check on synthetic data; advisory only.

```ruby
def post_country_rules_check(body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesCheckRequest`](../../doc/models/country-rules-check-request.md) | Body, Required | JSON body for: Country Rules Check. |

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```ruby
body = CountryRulesCheckRequest.new(
  BuyerCountryEnum::US,
  SellerCountryEnum::TW,
  envrr,
  AccountTypeEnum::BUSINESS,
  '120.00',
  CheckoutEnum::PAYPAL_ACCOUNT,
  'USD',
  []
)

result = other_controller.post_country_rules_check(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Country Rules Countries

Country Rules Countries. Local console route GET /api/v1/country-rules/countries on synthetic data; advisory only.

```ruby
def get_country_rules_countries
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```ruby
result = other_controller.get_country_rules_countries
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Country Rules Search

Country Rules Search. Local console route POST /api/v1/country-rules/search on synthetic data; advisory only.

```ruby
def post_country_rules_search(body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CountryRulesSearchRequest`](../../doc/models/country-rules-search-request.md) | Body, Required | JSON body for: Country Rules Search. |

## Response Type

**200**: Successful Response

`Object`

## Example Usage

```ruby
body = CountryRulesSearchRequest.new(
  'example'
)

result = other_controller.post_country_rules_search(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Approve

Approve. Local console route POST /api/v1/disputes/{case_ref}/approve on synthetic data; advisory only.

```ruby
def post_disputes_case_ref_approve(case_ref,
                                   body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | `String` | Template, Required | Case ref. |
| `body` | [`ApproveRequest`](../../doc/models/approve-request.md) | Body, Required | JSON body for: Approve. |

## Response Type

**200**: Successful Response

[`DisputeApprovalResponse`](../../doc/models/dispute-approval-response.md)

## Example Usage

```ruby
case_ref = 'case-ref-001'

body = ApproveRequest.new(
  'draft_digest6'
)

result = other_controller.post_disputes_case_ref_approve(
  case_ref,
  body
)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Disputes Case Ref Draft

Draft. Local console route POST /api/v1/disputes/{case_ref}/draft on synthetic data; advisory only.

```ruby
def post_disputes_case_ref_draft(case_ref,
                                 body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `case_ref` | `String` | Template, Required | Case ref. |
| `body` | `Object` | Body, Required | JSON body for: Draft. |

## Response Type

**200**: Successful Response

[`DisputeDraftResponse`](../../doc/models/dispute-draft-response.md)

## Example Usage

```ruby
case_ref = 'case-ref-001'

body = {  }

result = other_controller.post_disputes_case_ref_draft(
  case_ref,
  body
)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Policy Assess

Policy Assess. Local console route POST /api/v1/policy/assess on synthetic data; advisory only.

```ruby
def post_policy_assess(body)
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`PolicyRequest`](../../doc/models/policy-request.md) | Body, Required | JSON body for: Policy Assess. |

## Response Type

**200**: Successful Response

[`PolicyAssessmentResponse`](../../doc/models/policy-assessment-response.md)

## Example Usage

```ruby
body = PolicyRequest.new(
  '2026-10-07T00:00:00Z',
  'US',
  30,
  ThemeEnum::SOURCE_COMPLIANCE
)

result = other_controller.post_policy_assess(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

