# References

Pinned official references and search over them.

```ruby
references_controller = client.references
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```ruby
def post_references_search(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ReferenceResponse`](../../doc/models/reference-response.md)

## Example Usage

```ruby
body = ReferenceRequest.new(
  'US',
  'query6',
  ThemeEnum::DISPUTE_MEDIATION,
  nil,
  CaseStage2Enum::ANY,
  3,
  nil,
  nil,
  false
)

result = references_controller.post_references_search(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

