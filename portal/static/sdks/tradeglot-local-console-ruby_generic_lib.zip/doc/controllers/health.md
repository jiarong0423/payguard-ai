# Health

Liveness check.

```ruby
health_controller = client.health
```

## Class Name

`HealthController`


# Get Health

Health. Local console route GET /api/v1/health on synthetic data; advisory only.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_health
```

## Response Type

**200**: Successful Response

[`HealthResponse`](../../doc/models/health-response.md)

## Example Usage

```ruby
result = health_controller.get_health
puts result
```

## Example Response *(as JSON)*

```json
{
  "mode": "demo",
  "source": "synthetic",
  "status": "ok",
  "version": "0.0.0-example"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

