# Aup

Acceptable-use keyword check and the invoice review that follows it.

```ruby
aup_controller = client.aup
```

## Class Name

`AupController`

## Methods

* [Post Aup Acknowledge](../../doc/controllers/aup.md#post-aup-acknowledge)
* [Post Aup Category Signal](../../doc/controllers/aup.md#post-aup-category-signal)
* [Post Aup Product Reference](../../doc/controllers/aup.md#post-aup-product-reference)
* [Post Aup Product Reference Confirm](../../doc/controllers/aup.md#post-aup-product-reference-confirm)
* [Post Aup Review](../../doc/controllers/aup.md#post-aup-review)


# Post Aup Acknowledge

Acknowledge Aup. Local console route POST /api/v1/aup/acknowledge on synthetic data; advisory only.

```ruby
def post_aup_acknowledge(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupAcknowledgeRequest`](../../doc/models/aup-acknowledge-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AupAcknowledgeResponse`](../../doc/models/aup-acknowledge-response.md)

## Example Usage

```ruby
body = AupAcknowledgeRequest.new(
  ChoiceEnum::CANCEL,
  'description_digest4',
  'evaluation_id0'
)

result = aup_controller.post_aup_acknowledge(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Category Signal

Aup Category Signal. Local console route POST /api/v1/aup/category-signal on synthetic data; advisory only.

```ruby
def post_aup_category_signal(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupCategorySignalRequest`](../../doc/models/aup-category-signal-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AupCategorySignalResponse`](../../doc/models/aup-category-signal-response.md)

## Example Usage

```ruby
body = AupCategorySignalRequest.new(
  'description4',
  'evaluation_id0'
)

result = aup_controller.post_aup_category_signal(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference

Aup Product Reference. Local console route POST /api/v1/aup/product-reference on synthetic data; advisory only.

```ruby
def post_aup_product_reference(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductReferenceRequest`](../../doc/models/product-reference-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ProductReferenceResponse`](../../doc/models/product-reference-response.md)

## Example Usage

```ruby
body = ProductReferenceRequest.new(
  'description4',
  'evaluation_id0'
)

result = aup_controller.post_aup_product_reference(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference Confirm

Aup Product Confirm. Local console route POST /api/v1/aup/product-reference/confirm on synthetic data; advisory only.

```ruby
def post_aup_product_reference_confirm(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductConfirmRequest`](../../doc/models/product-confirm-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`ProductConfirmResponse`](../../doc/models/product-confirm-response.md)

## Example Usage

```ruby
body = ProductConfirmRequest.new(
  'description4',
  'evaluation_id0',
  'String3'
)

result = aup_controller.post_aup_product_reference_confirm(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Review

Aup. Local console route POST /api/v1/aup/review on synthetic data; advisory only.

```ruby
def post_aup_review(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupRequest`](../../doc/models/aup-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AupResponse`](../../doc/models/aup-response.md)

## Example Usage

```ruby
body = AupRequest.new(
  'description4'
)

result = aup_controller.post_aup_review(body)
puts result
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

