
# Custom Header Signature



Documentation for accessing and setting credentials for DemoCsrf.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| X-CSRF-Token | `String` | CSRF token for the same session. Get it from the csrf_token field of the response to POST /api/v1/demo/sessions. Every POST also needs it; without it the API answers 403 csrf_rejected. | `x_csrf_token` |



**Note:** Auth credentials can be set using `DemoCsrfCredentials` object, passed in as named parameter `demo_csrf_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
require 'trade_glot_local_console'
include TradeGlotLocalConsole

client = Client.new(
  demo_csrf_credentials: DemoCsrfCredentials.new(
    x_csrf_token: 'X-CSRF-Token'
  )
)
```


