
# Custom Header Signature



Documentation for accessing and setting credentials for DemoSession.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| X-Demo-Session | `String` | Demo session id. Get it from the session_id field of the response to POST /api/v1/demo/sessions (that request needs no header). Without it the API answers 401 session_required. | `x_demo_session` |



**Note:** Auth credentials can be set using `DemoSessionCredentials` object, passed in as named parameter `demo_session_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
require 'trade_glot_local_console'
include TradeGlotLocalConsole

client = Client.new(
  demo_session_credentials: DemoSessionCredentials.new(
    x_demo_session: 'X-Demo-Session'
  )
)
```


