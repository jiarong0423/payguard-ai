# References

Pinned official references and search over them.

```php
$referencesController = $client->getReferencesController();
```

## Class Name

`ReferencesController`


# Post References Search

References. Local console route POST /api/v1/references/search on synthetic data; advisory only.

```php
function postReferencesSearch(ReferenceRequest $body): ReferenceResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ReferenceRequest`](../../doc/models/reference-request.md) | Body, Required | JSON body for: References. |

## Response Type

**200**: Successful Response

[`ReferenceResponse`](../../doc/models/reference-response.md)

## Example Usage

```php
$body = ReferenceRequestBuilder::init(
    'example',
    ThemeEnum::SOURCE_COMPLIANCE
)->build();

$referencesController = $client->getReferencesController();

try {
    $result = $referencesController->postReferencesSearch($body);
    echo 'ReferenceResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

