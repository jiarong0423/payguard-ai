# Ai

Evidence brief (local console with a model profile only).

```php
$aiController = $client->getAiController();
```

## Class Name

`AiController`

## Methods

* [Post Ai Evidence Brief](../../doc/controllers/ai.md#post-ai-evidence-brief)
* [Get Ai Usage](../../doc/controllers/ai.md#get-ai-usage)


# Post Ai Evidence Brief

Evidence Brief. Local console route POST /api/v1/ai/evidence-brief on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postAiEvidenceBrief(AiBriefHttpRequest $body): AiBriefResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AiBriefHttpRequest`](../../doc/models/ai-brief-http-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`AiBriefResponse`](../../doc/models/ai-brief-response.md)

## Example Usage

```php
$body = AiBriefHttpRequestBuilder::init(
    StageEnum::VELOCITY_GUARD
)->build();

$aiController = $client->getAiController();

try {
    $result = $aiController->postAiEvidenceBrief($body);
    echo 'AiBriefResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (HTTPValidationErrorException $exp) {
    echo 'Caught HTTPValidationErrorException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Ai Usage

(optimise r24) This session's AI calls: stage, model, tokens, latency, estimated cost. No prompt or reply
text is ever stored; the hosted demo makes no model call and answers an empty list.

```php
function getAiUsage(): AiUsageResponse
```

## Response Type

**200**: Successful Response

[`AiUsageResponse`](../../doc/models/ai-usage-response.md)

## Example Usage

```php
$aiController = $client->getAiController();

try {
    $result = $aiController->getAiUsage();
    echo 'AiUsageResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

