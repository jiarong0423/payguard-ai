# Paypal

PayPal Sandbox connection, disputes and the gated evidence request (local console only).

```php
$paypalController = $client->getPaypalController();
```

## Class Name

`PaypalController`

## Methods

* [Post Paypal Connect](../../doc/controllers/paypal.md#post-paypal-connect)
* [Get Paypal Disputes](../../doc/controllers/paypal.md#get-paypal-disputes)
* [Post Paypal Disputes Add Tracking](../../doc/controllers/paypal.md#post-paypal-disputes-add-tracking)
* [Post Paypal Disputes Provide Evidence](../../doc/controllers/paypal.md#post-paypal-disputes-provide-evidence)
* [Get Paypal Disputes Dispute Id](../../doc/controllers/paypal.md#get-paypal-disputes-dispute-id)
* [Post Paypal Invoices Draft](../../doc/controllers/paypal.md#post-paypal-invoices-draft)
* [Post Paypal Invoices Review](../../doc/controllers/paypal.md#post-paypal-invoices-review)
* [Get Paypal Status](../../doc/controllers/paypal.md#get-paypal-status)
* [Post Paypal Webhooks Verify](../../doc/controllers/paypal.md#post-paypal-webhooks-verify)


# Post Paypal Connect

Connect. Local console route POST /api/v1/paypal/connect on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postPaypalConnect(array $body): PaypalStatusResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `array` | Body, Required | JSON body for: Connect. |

## Response Type

**200**: Successful Response

[`PaypalStatusResponse`](../../doc/models/paypal-status-response.md)

## Example Usage

```php
$body = ApiHelper::deserialize('{}');

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalConnect($body);
    echo 'PaypalStatusResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes

List Disputes. Local console route GET /api/v1/paypal/disputes on synthetic data; advisory only.

```php
function getPaypalDisputes(): DisputeListResponse
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`DisputeListResponse`](../../doc/models/dispute-list-response.md)

## Example Usage

```php
$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->getPaypalDisputes();
    echo 'DisputeListResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Add Tracking

Add Tracking. Local console route POST /api/v1/paypal/disputes/add-tracking on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postPaypalDisputesAddTracking(AddTrackingRequest $body): AddTrackingResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AddTrackingRequest`](../../doc/models/add-tracking-request.md) | Body, Required | JSON body for: Add Tracking. |

## Response Type

**200**: Successful Response

[`AddTrackingResponse`](../../doc/models/add-tracking-response.md)

## Example Usage

```php
$body = AddTrackingRequestBuilder::init(
    'case-ref-001',
    'PP-R-BNP-XXXX7173'
)->build();

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalDisputesAddTracking($body);
    echo 'AddTrackingResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Disputes Provide Evidence

Provide Evidence. Local console route POST /api/v1/paypal/disputes/provide-evidence on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postPaypalDisputesProvideEvidence(ProvideEvidenceRequest $body): ProvideEvidenceResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProvideEvidenceRequest`](../../doc/models/provide-evidence-request.md) | Body, Required | JSON body for: Provide Evidence. |

## Response Type

**200**: Successful Response

[`ProvideEvidenceResponse`](../../doc/models/provide-evidence-response.md)

## Example Usage

```php
$body = ProvideEvidenceRequestBuilder::init(
    'case-ref-001',
    'PP-R-BNP-XXXX7173'
)
    ->submit(false)
    ->build();

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalDisputesProvideEvidence($body);
    echo 'ProvideEvidenceResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Disputes Dispute Id

Get Dispute. Local console route GET /api/v1/paypal/disputes/{dispute_id} on synthetic data; advisory only.

```php
function getPaypalDisputesDisputeId(string $disputeId): DisputeDetailResponse
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `disputeId` | `string` | Template, Required | Dispute id. |

## Response Type

**200**: Successful Response

[`DisputeDetailResponse`](../../doc/models/dispute-detail-response.md)

## Example Usage

```php
$disputeId = 'PP-R-BNP-XXXX7173';

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->getPaypalDisputesDisputeId($disputeId);
    echo 'DisputeDetailResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Draft

Invoice Draft. Local console route POST /api/v1/paypal/invoices/draft on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postPaypalInvoicesDraft(InvoiceDraftRequest $body): InvoiceDraftResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InvoiceDraftRequest`](../../doc/models/invoice-draft-request.md) | Body, Required | JSON body for: Invoice Draft. |

## Response Type

**200**: Successful Response

[`InvoiceDraftResponse`](../../doc/models/invoice-draft-response.md)

## Example Usage

```php
$body = InvoiceDraftRequestBuilder::init(
    'amount8',
    CurrencyEnum::USD,
    'description4',
    'payload_digest4',
    'review_token4'
)->build();

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalInvoicesDraft($body);
    echo 'InvoiceDraftResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Invoices Review

Invoice Review. Local console route POST /api/v1/paypal/invoices/review on synthetic data; advisory only.

```php
function postPaypalInvoicesReview(InvoiceReviewRequest $body): InvoiceReviewResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InvoiceReviewRequest`](../../doc/models/invoice-review-request.md) | Body, Required | JSON body for: Invoice Review. |

## Response Type

**200**: Successful Response

[`InvoiceReviewResponse`](../../doc/models/invoice-review-response.md)

## Example Usage

```php
$body = InvoiceReviewRequestBuilder::init(
    '42.50',
    false,
    CurrencyEnum::USD,
    'example'
)->build();

$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalInvoicesReview($body);
    echo 'InvoiceReviewResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Paypal Status

Paypal Status. Local console route GET /api/v1/paypal/status on synthetic data; advisory only.

```php
function getPaypalStatus(): PaypalStatusResponse
```

## Authentication

This endpoint requires [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`PaypalStatusResponse`](../../doc/models/paypal-status-response.md)

## Example Usage

```php
$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->getPaypalStatus();
    echo 'PaypalStatusResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Paypal Webhooks Verify

Verify Webhook. Local console route POST /api/v1/paypal/webhooks/verify on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postPaypalWebhooksVerify(): WebhookVerifyResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Response Type

**200**: Successful Response

[`WebhookVerifyResponse`](../../doc/models/webhook-verify-response.md)

## Example Usage

```php
$paypalController = $client->getPaypalController();

try {
    $result = $paypalController->postPaypalWebhooksVerify();
    echo 'WebhookVerifyResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 503 | Hosted demo only: this route makes no provider call (hosted_demo_disabled). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

