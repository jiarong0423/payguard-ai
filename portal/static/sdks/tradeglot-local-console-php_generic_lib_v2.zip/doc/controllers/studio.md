# Studio

AG Studio agent route (local live mode only).

```php
$studioController = $client->getStudioController();
```

## Class Name

`StudioController`

## Methods

* [Get Studio Agent Status](../../doc/controllers/studio.md#get-studio-agent-status)
* [Post Studio Agent Turn](../../doc/controllers/studio.md#post-studio-agent-turn)


# Get Studio Agent Status

Studio Agent Status. Local console route GET /api/v1/studio/agent-status on synthetic data; advisory only.

```php
function getStudioAgentStatus(): array
```

## Response Type

**200**: Successful Response

`array`

## Example Usage

```php
$studioController = $client->getStudioController();

try {
    $result = $studioController->getStudioAgentStatus();
    echo 'array:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Studio Agent Turn

Studio Agent Turn. Local console route POST /api/v1/studio/agent-turn on synthetic data; advisory only. The hosted demo answers 503 hosted_demo_disabled here: it makes no provider calls.

```php
function postStudioAgentTurn(array $body): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `array` | Body, Required | - |

## Response Type

**200**: Successful Response

`array`

## Example Usage

```php
$body = ApiHelper::deserialize('{"key1":"val1","key2":"val2"}');

$studioController = $client->getStudioController();

try {
    $result = $studioController->postStudioAgentTurn($body);
    echo 'array:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (HTTPValidationErrorException $exp) {
    echo 'Caught HTTPValidationErrorException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

