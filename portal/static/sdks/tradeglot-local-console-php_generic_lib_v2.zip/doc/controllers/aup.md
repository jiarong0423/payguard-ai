# Aup

Acceptable-use keyword check and the invoice review that follows it.

```php
$aupController = $client->getAupController();
```

## Class Name

`AupController`

## Methods

* [Post Aup Acknowledge](../../doc/controllers/aup.md#post-aup-acknowledge)
* [Post Aup Category Signal](../../doc/controllers/aup.md#post-aup-category-signal)
* [Post Aup Product Reference](../../doc/controllers/aup.md#post-aup-product-reference)
* [Post Aup Product Reference Confirm](../../doc/controllers/aup.md#post-aup-product-reference-confirm)
* [Post Aup Review](../../doc/controllers/aup.md#post-aup-review)


# Post Aup Acknowledge

Acknowledge Aup. Local console route POST /api/v1/aup/acknowledge on synthetic data; advisory only.

```php
function postAupAcknowledge(AupAcknowledgeRequest $body): AupAcknowledgeResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupAcknowledgeRequest`](../../doc/models/aup-acknowledge-request.md) | Body, Required | JSON body for: Acknowledge Aup. |

## Response Type

**200**: Successful Response

[`AupAcknowledgeResponse`](../../doc/models/aup-acknowledge-response.md)

## Example Usage

```php
$body = AupAcknowledgeRequestBuilder::init(
    ChoiceEnum::CANCEL,
    'description_digest4',
    'evaluation_id0'
)->build();

$aupController = $client->getAupController();

try {
    $result = $aupController->postAupAcknowledge($body);
    echo 'AupAcknowledgeResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Category Signal

Aup Category Signal. Local console route POST /api/v1/aup/category-signal on synthetic data; advisory only.

```php
function postAupCategorySignal(AupCategorySignalRequest $body): AupCategorySignalResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupCategorySignalRequest`](../../doc/models/aup-category-signal-request.md) | Body, Required | JSON body for: Aup Category Signal. |

## Response Type

**200**: Successful Response

[`AupCategorySignalResponse`](../../doc/models/aup-category-signal-response.md)

## Example Usage

```php
$body = AupCategorySignalRequestBuilder::init(
    'example',
    'examplexxxxxxxxxxxxxxxxxxxxxxxxx'
)->build();

$aupController = $client->getAupController();

try {
    $result = $aupController->postAupCategorySignal($body);
    echo 'AupCategorySignalResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference

Aup Product Reference. Local console route POST /api/v1/aup/product-reference on synthetic data; advisory only.

```php
function postAupProductReference(ProductReferenceRequest $body): ProductReferenceResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductReferenceRequest`](../../doc/models/product-reference-request.md) | Body, Required | JSON body for: Aup Product Reference. |

## Response Type

**200**: Successful Response

[`ProductReferenceResponse`](../../doc/models/product-reference-response.md)

## Example Usage

```php
$body = ProductReferenceRequestBuilder::init(
    'example',
    'examplexxxxxxxxxxxxxxxxxxxxxxxxx'
)->build();

$aupController = $client->getAupController();

try {
    $result = $aupController->postAupProductReference($body);
    echo 'ProductReferenceResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Product Reference Confirm

Aup Product Confirm. Local console route POST /api/v1/aup/product-reference/confirm on synthetic data; advisory only.

```php
function postAupProductReferenceConfirm(ProductConfirmRequest $body): ProductConfirmResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`ProductConfirmRequest`](../../doc/models/product-confirm-request.md) | Body, Required | JSON body for: Aup Product Confirm. |

## Response Type

**200**: Successful Response

[`ProductConfirmResponse`](../../doc/models/product-confirm-response.md)

## Example Usage

```php
$body = ProductConfirmRequestBuilder::init(
    'example',
    'examplexxxxxxxxxxxxxxxxxxxxxxxxx',
    'example'
)->build();

$aupController = $client->getAupController();

try {
    $result = $aupController->postAupProductReferenceConfirm($body);
    echo 'ProductConfirmResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Aup Review

Aup. Local console route POST /api/v1/aup/review on synthetic data; advisory only.

```php
function postAupReview(AupRequest $body): AupResponse
```

## Authentication

This endpoint requires [DemoCsrf](../../doc/auth/custom-header-signature.md) **AND** [DemoSession](../../doc/auth/custom-header-signature-1.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`AupRequest`](../../doc/models/aup-request.md) | Body, Required | JSON body for: Aup. |

## Response Type

**200**: Successful Response

[`AupResponse`](../../doc/models/aup-response.md)

## Example Usage

```php
$body = AupRequestBuilder::init(
    'Handmade ceramic coffee mug, shipped in a padded box'
)->build();

$aupController = $client->getAupController();

try {
    $result = $aupController->postAupReview($body);
    echo 'AupResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 403 | Origin missing or not allowed, or the CSRF token is wrong (origin_required, origin_rejected, csrf_rejected). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | The request does not match the accepted contract (schema_invalid). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

