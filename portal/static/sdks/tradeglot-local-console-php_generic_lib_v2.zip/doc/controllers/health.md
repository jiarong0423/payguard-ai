# Health

Liveness check.

```php
$healthController = $client->getHealthController();
```

## Class Name

`HealthController`


# Get Health

Health. Local console route GET /api/v1/health on synthetic data; advisory only.

```php
function getHealth(): HealthResponse
```

## Response Type

**200**: Successful Response

[`HealthResponse`](../../doc/models/health-response.md)

## Example Usage

```php
$healthController = $client->getHealthController();

try {
    $result = $healthController->getHealth();
    echo 'HealthResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

