# Demo

Demo session, scenarios and local state.

```php
$demoController = $client->getDemoController();
```

## Class Name

`DemoController`

## Methods

* [Post Demo Inject](../../doc/controllers/demo.md#post-demo-inject)
* [Post Demo Sessions](../../doc/controllers/demo.md#post-demo-sessions)
* [Get Demo State](../../doc/controllers/demo.md#get-demo-state)


# Post Demo Inject

Inject. Local console route POST /api/v1/demo/inject on synthetic data; advisory only.

```php
function postDemoInject(InjectRequest $body): StateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`InjectRequest`](../../doc/models/inject-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```php
$body = InjectRequestBuilder::init(
    Scenario5Enum::DISPUTE
)->build();

$demoController = $client->getDemoController();

try {
    $result = $demoController->postDemoInject($body);
    echo 'StateResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (HTTPValidationErrorException $exp) {
    echo 'Caught HTTPValidationErrorException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Post Demo Sessions

New Session. Local console route POST /api/v1/demo/sessions on synthetic data; advisory only.

```php
function postDemoSessions(array $body): SessionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | `array` | Body, Required | - |

## Response Type

**201**: Successful Response

[`SessionResponse`](../../doc/models/session-response.md)

## Example Usage

```php
$body = ApiHelper::deserialize('{"key1":"val1","key2":"val2"}');

$demoController = $client->getDemoController();

try {
    $result = $demoController->postDemoSessions($body);
    echo 'SessionResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (HTTPValidationErrorException $exp) {
    echo 'Caught HTTPValidationErrorException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 422 | Validation Error | [`HTTPValidationErrorException`](../../doc/models/http-validation-error-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |


# Get Demo State

State. Local console route GET /api/v1/demo/state on synthetic data; advisory only.

```php
function getDemoState(): StateResponse
```

## Response Type

**200**: Successful Response

[`StateResponse`](../../doc/models/state-response.md)

## Example Usage

```php
$demoController = $client->getDemoController();

try {
    $result = $demoController->getDemoState();
    echo 'StateResponse:';
    var_dump($result);
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught:', $exp;
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | A valid demo session is required (session_required). | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |
| 429 | Too many requests; the body says when to retry. | [`ErrorBodyException`](../../doc/models/error-body-exception.md) |

