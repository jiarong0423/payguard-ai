
# Observation Status Enum

Observation status.

## Enumeration

`ObservationStatusEnum`

## Fields

| Name |
|  --- |
| `FUTURE_OBSERVATION` |
| `STALE_OBSERVATION` |
| `WITHIN_OBSERVATION_BUDGET` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ObservationStatusEnum;

$observationStatus = ObservationStatusEnum::FUTURE_OBSERVATION;
```

