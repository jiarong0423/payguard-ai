
# Case Stage 2 Enum

Case stage.

## Enumeration

`CaseStage2Enum`

## Fields

| Name |
|  --- |
| `ANY` |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CaseStage2Enum;

$caseStage2 = CaseStage2Enum::ANY;
```

