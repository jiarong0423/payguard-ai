
# Evidence Info

EvidenceInfo.

## Structure

`EvidenceInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `trackingInfo` | [`TrackingInfo[]`](../../doc/models/tracking-info.md) | Required | Tracking info.<br><br>**Constraints**: *Maximum Items*: `10` | getTrackingInfo(): array | setTrackingInfo(array trackingInfo): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\EvidenceInfoBuilder;
use TradeGlotLocalConsoleLib\Models\Builders\TrackingInfoBuilder;
use TradeGlotLocalConsoleLib\Models\CarrierNameEnum;

$evidenceInfo = EvidenceInfoBuilder::init(
    [
        TrackingInfoBuilder::init(
            CarrierNameEnum::DHL,
            'tracking_number6'
        )
            ->carrierNameOther(
                'String1'
            )
            ->build()
    ]
)->build();
```

