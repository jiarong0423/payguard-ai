
# Missing Official Policy Theme Enum

## Enumeration

`MissingOfficialPolicyThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\MissingOfficialPolicyThemeEnum;

$missingOfficialPolicyTheme = MissingOfficialPolicyThemeEnum::SOURCE_COMPLIANCE;
```

