
# Source Updated Date Status Enum

Source updated date status.

## Enumeration

`SourceUpdatedDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `MISSING` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SourceUpdatedDateStatusEnum;

$sourceUpdatedDateStatus = SourceUpdatedDateStatusEnum::DOCUMENT_STATED;
```

