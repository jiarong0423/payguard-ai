
# Guide Start Request

GuideStartRequest.

## Structure

`GuideStartRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `goodsType` | string([GoodsTypeEnum](../../doc/models/goods-type-enum.md))\|null | Optional | This is a container for any-of cases. | getGoodsType(): ?string | setGoodsType(?string goodsType): void |
| `scenario` | [`string(Scenario2Enum)`](../../doc/models/scenario-2-enum.md) | Required | Scenario. | getScenario(): string | setScenario(string scenario): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideStartRequestBuilder;
use TradeGlotLocalConsoleLib\Models\Scenario2Enum;
use TradeGlotLocalConsoleLib\Models\GoodsTypeEnum;

$guideStartRequest = GuideStartRequestBuilder::init(
    Scenario2Enum::VELOCITY
)
    ->goodsType(
        GoodsTypeEnum::PHYSICAL
    )
    ->build();
```

