
# Fixture Id Enum

Fixture id.

## Enumeration

`FixtureIdEnum`

## Fields

| Name |
|  --- |
| `PAYGUARDFIXEDSYNTHETICBRIEFV1` |
| `PAYGUARDSESSIONBRIEFV1` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\FixtureIdEnum;

$fixtureId = FixtureIdEnum::PAYGUARDFIXEDSYNTHETICBRIEFV1;
```

