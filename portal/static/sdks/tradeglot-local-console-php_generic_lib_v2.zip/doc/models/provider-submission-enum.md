
# Provider Submission Enum

Provider submission.

## Enumeration

`ProviderSubmissionEnum`

## Fields

| Name |
|  --- |
| `NOT_PERFORMED` |
| `PERFORMED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ProviderSubmissionEnum;

$providerSubmission = ProviderSubmissionEnum::NOT_PERFORMED;
```

