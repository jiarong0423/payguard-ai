
# Goods Type Enum

## Enumeration

`GoodsTypeEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\GoodsTypeEnum;

$goodsType = GoodsTypeEnum::PHYSICAL;
```

