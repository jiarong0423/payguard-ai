
# External Send Enum

External send.

## Enumeration

`ExternalSendEnum`

## Fields

| Name |
|  --- |
| `FROZEN` |
| `SUBMITTED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ExternalSendEnum;

$externalSend = ExternalSendEnum::FROZEN;
```

