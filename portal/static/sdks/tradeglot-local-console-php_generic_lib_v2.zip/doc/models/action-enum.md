
# Action Enum

Action.

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `OAUTH_CONNECT` |
| `CREATE_INVOICE_DRAFT` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ActionEnum;

$action = ActionEnum::OAUTH_CONNECT;
```

