
# Reason 5 Enum

## Enumeration

`Reason5Enum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |
| `SUPERSEDED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Reason5Enum;

$reason5 = Reason5Enum::INVALID_REPLY;
```

