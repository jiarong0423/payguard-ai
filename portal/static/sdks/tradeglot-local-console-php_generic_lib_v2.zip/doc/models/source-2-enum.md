
# Source 2 Enum

Source.

## Enumeration

`Source2Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source2Enum;

$source2 = Source2Enum::CHANNEL3;
```

