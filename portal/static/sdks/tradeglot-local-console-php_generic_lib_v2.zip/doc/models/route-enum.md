
# Route Enum

Route.

## Enumeration

`RouteEnum`

## Fields

| Name |
|  --- |
| `PHYSICAL` |
| `DIGITAL` |
| `SERVICE` |
| `UNKNOWN` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\RouteEnum;

$route = RouteEnum::PHYSICAL;
```

