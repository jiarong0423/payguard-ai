
# Source 8 Enum

Source.

## Enumeration

`Source8Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL` |
| `SUGGESTION` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source8Enum;

$source8 = Source8Enum::OFFICIAL;
```

