
# Environment Enum

Environment.

## Enumeration

`EnvironmentEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\EnvironmentEnum;

$environment = EnvironmentEnum::SANDBOX;
```

