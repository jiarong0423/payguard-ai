
# Error Body Exception

The error body every refusal uses.

## Structure

`ErrorBodyException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `error` | [`Error`](../../doc/models/error.md) | Required | What was refused and why. | getError(): Error | setError(Error error): void |

## Example

```php
try {
    // make the API call
} catch (ErrorBodyException $exp) {
    echo 'Caught ErrorBodyException:', $exp;
} catch (ApiException $exp) {
    echo 'Caught ApiException:', $exp;
}
```

