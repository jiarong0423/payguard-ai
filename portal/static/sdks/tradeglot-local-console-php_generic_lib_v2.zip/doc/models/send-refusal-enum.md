
# Send Refusal Enum

## Enumeration

`SendRefusalEnum`

## Fields

| Name |
|  --- |
| `ACCOUNT_IDENTITY_UNKNOWN` |
| `DISPUTE_NOT_THIS_ACCOUNT` |
| `DISPUTE_DETAIL_REQUIRED` |
| `SELLER_EVIDENCE_ALREADY_SUBMITTED` |
| `DISPUTE_NOT_AWAITING_SELLER` |
| `DISPUTE_EVIDENCE_NOT_OFFERED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SendRefusalEnum;

$sendRefusal = SendRefusalEnum::ACCOUNT_IDENTITY_UNKNOWN;
```

