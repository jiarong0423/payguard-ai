
# Confidence Enum

## Enumeration

`ConfidenceEnum`

## Fields

| Name |
|  --- |
| `HIGH` |
| `LOW` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ConfidenceEnum;

$confidence = ConfidenceEnum::HIGH;
```

