
# Reason 7 Enum

## Enumeration

`Reason7Enum`

## Fields

| Name |
|  --- |
| `NOTHING_TO_SEND` |
| `NOT_RECORDED` |
| `BUDGET_EXHAUSTED` |
| `TIMEOUT` |
| `UPSTREAM_ERROR` |
| `CONTRACT_REJECTED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Reason7Enum;

$reason7 = Reason7Enum::NOTHING_TO_SEND;
```

