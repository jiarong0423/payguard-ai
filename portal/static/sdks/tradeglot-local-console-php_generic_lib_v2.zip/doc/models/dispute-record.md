
# Dispute Record

DisputeRecord.

## Structure

`DisputeRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `createTime` | `string` | Required | Create time.<br><br>**Constraints**: *Pattern*: `^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z$` | getCreateTime(): string | setCreateTime(string createTime): void |
| `disputeAmount` | [`ProviderMoney`](../../doc/models/provider-money.md) | Required | ProviderMoney. | getDisputeAmount(): ProviderMoney | setDisputeAmount(ProviderMoney disputeAmount): void |
| `disputeId` | `string` | Required | Dispute id.<br><br>**Constraints**: *Pattern*: `^PP-[A-Z0-9][A-Z0-9-]{2,62}$` | getDisputeId(): string | setDisputeId(string disputeId): void |
| `disputeLifeCycleStage` | [`string(DisputeLifeCycleStageEnum)`](../../doc/models/dispute-life-cycle-stage-enum.md) | Required | Dispute life cycle stage. | getDisputeLifeCycleStage(): string | setDisputeLifeCycleStage(string disputeLifeCycleStage): void |
| `disputeState` | string\|null | Optional | This is a container for any-of cases. | getDisputeState(): ?string | setDisputeState(?string disputeState): void |
| `reason` | [`string(Reason2Enum)`](../../doc/models/reason-2-enum.md) | Required | Reason. | getReason(): string | setReason(string reason): void |
| `sellerResponseDueDate` | string\|null | Optional | This is a container for any-of cases. | getSellerResponseDueDate(): ?string | setSellerResponseDueDate(?string sellerResponseDueDate): void |
| `status` | [`string(Status3Enum)`](../../doc/models/status-3-enum.md) | Required | Status. | getStatus(): string | setStatus(string status): void |
| `updateTime` | string\|null | Optional | This is a container for any-of cases. | getUpdateTime(): ?string | setUpdateTime(?string updateTime): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\DisputeRecordBuilder;
use TradeGlotLocalConsoleLib\Models\Builders\ProviderMoneyBuilder;
use TradeGlotLocalConsoleLib\Models\DisputeLifeCycleStageEnum;
use TradeGlotLocalConsoleLib\Models\Reason2Enum;
use TradeGlotLocalConsoleLib\Models\Status3Enum;

$disputeRecord = DisputeRecordBuilder::init(
    'create_time0',
    ProviderMoneyBuilder::init(
        'currency_code6',
        'value0'
    )->build(),
    'dispute_id6',
    DisputeLifeCycleStageEnum::ARBITRATION,
    Reason2Enum::MERCHANDISE_OR_SERVICE_NOT_RECEIVED,
    Status3Enum::OPEN
)
    ->disputeState(
        'String7'
    )
    ->sellerResponseDueDate(
        'String3'
    )
    ->updateTime(
        'String7'
    )
    ->build();
```

