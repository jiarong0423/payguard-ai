
# Baseline Provenance Enum

Baseline provenance.

## Enumeration

`BaselineProvenanceEnum`

## Fields

| Name |
|  --- |
| `SYNTHETIC_BASELINE` |
| `CALLER_SUPPLIED_UNVERIFIED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\BaselineProvenanceEnum;

$baselineProvenance = BaselineProvenanceEnum::SYNTHETIC_BASELINE;
```

