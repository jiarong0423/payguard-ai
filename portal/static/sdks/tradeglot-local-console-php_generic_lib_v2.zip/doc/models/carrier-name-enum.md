
# Carrier Name Enum

Carrier name.

## Enumeration

`CarrierNameEnum`

## Fields

| Name |
|  --- |
| `USPS` |
| `UPS` |
| `FEDEX` |
| `DHL` |
| `TW_CHUNGHWA_POST` |
| `JP_JAPANPOST` |
| `OTHER` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CarrierNameEnum;

$carrierName = CarrierNameEnum::JP_JAPANPOST;
```

