
# Kind 2 Enum

Kind.

## Enumeration

`Kind2Enum`

## Fields

| Name |
|  --- |
| `DATE` |
| `CHOICE` |
| `TEXT` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Kind2Enum;

$kind2 = Kind2Enum::CHOICE;
```

