
# Choice Enum

Choice.

## Enumeration

`ChoiceEnum`

## Fields

| Name |
|  --- |
| `RETURN_TO_EDIT` |
| `CANCEL` |
| `ACKNOWLEDGE_AND_CONTINUE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ChoiceEnum;

$choice = ChoiceEnum::RETURN_TO_EDIT;
```

