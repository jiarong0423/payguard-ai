
# Status 14 Enum

Status.

## Enumeration

`Status14Enum`

## Fields

| Name |
|  --- |
| `NORMAL` |
| `REVIEW_VELOCITY` |
| `INSUFFICIENT_BASELINE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status14Enum;

$status14 = Status14Enum::REVIEW_VELOCITY;
```

