
# Kind Enum

Kind.

## Enumeration

`KindEnum`

## Fields

| Name |
|  --- |
| `PAYMENT` |
| `ORDER_RECORD_CREATED` |
| `DELIVERY` |
| `CLAIM_OPENED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\KindEnum;

$kind = KindEnum::DELIVERY;
```

