
# Aup Category Signal Response

Optional Channel3 signal shown next to the AUP result; it never changes the rule decision.

## Structure

`AupCategorySignalResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `affectsDecision` | `string` | Required, Constant | Affects decision.<br><br>**Value**: `'False'` | getAffectsDecision(): string | setAffectsDecision(string affectsDecision): void |
| `reason` | string([ReasonEnum](../../doc/models/reason-enum.md)) | Required | This is a container for any-of cases. | getReason(): string | setReason(string reason): void |
| `signal` | [CategorySignal](../../doc/models/category-signal.md) | Required | This is a container for any-of cases. | getSignal(): CategorySignal | setSignal(CategorySignal signal): void |
| `status` | [`string(Status2Enum)`](../../doc/models/status-2-enum.md) | Required | Status. | getStatus(): string | setStatus(string status): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\AupCategorySignalResponseBuilder;
use TradeGlotLocalConsoleLib\Models\ReasonEnum;
use TradeGlotLocalConsoleLib\Models\Builders\CategorySignalBuilder;
use TradeGlotLocalConsoleLib\Models\ConfidenceEnum;
use TradeGlotLocalConsoleLib\Models\Status2Enum;

$aupCategorySignalResponse = AupCategorySignalResponseBuilder::init(
    ReasonEnum::BUDGET_EXHAUSTED,
    CategorySignalBuilder::init(
        'String9',
        ConfidenceEnum::HIGH
    )->build(),
    Status2Enum::NOT_SENT
)->build();
```

