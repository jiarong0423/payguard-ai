
# Stage Enum

Stage.

## Enumeration

`StageEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\StageEnum;

$stage = StageEnum::DISPUTE_MEDIATION;
```

