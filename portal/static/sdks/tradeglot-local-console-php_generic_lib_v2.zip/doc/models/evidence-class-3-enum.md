
# Evidence Class 3 Enum

Evidence class.

## Enumeration

`EvidenceClass3Enum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\EvidenceClass3Enum;

$evidenceClass3 = EvidenceClass3Enum::AUTHENTIC_SANDBOX_RESPONSE;
```

