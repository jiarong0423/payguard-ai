
# Field Enum

## Enumeration

`FieldEnum`

## Fields

| Name |
|  --- |
| `NAME` |
| `ADDRESS` |
| `EMAIL` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\FieldEnum;

$field = FieldEnum::ADDRESS;
```

