
# Currency Enum

Currency.

## Enumeration

`CurrencyEnum`

## Fields

| Name |
|  --- |
| `USD` |
| `TWD` |
| `JPY` |
| `HUF` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CurrencyEnum;

$currency = CurrencyEnum::USD;
```

