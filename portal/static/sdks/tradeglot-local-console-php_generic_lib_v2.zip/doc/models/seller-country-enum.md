
# Seller Country Enum

Seller country.

## Enumeration

`SellerCountryEnum`

## Fields

| Name |
|  --- |
| `US` |
| `TW` |
| `CN` |
| `HK` |
| `GB` |
| `DE` |
| `JP` |
| `SG` |
| `AU` |
| `CA` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SellerCountryEnum;

$sellerCountry = SellerCountryEnum::AU;
```

