
# Account Opened Enum

Account opened.

## Enumeration

`AccountOpenedEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `BEFORE_CUTOFF` |
| `AFTER_CUTOFF` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\AccountOpenedEnum;

$accountOpened = AccountOpenedEnum::AFTER_CUTOFF;
```

