
# Guide Form Request

One field ({item, value}) or one round of up to three fields ({fields: [...]}), never both.

## Structure

`GuideFormRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `confirmReview` | `?bool` | Optional | Confirm review.<br><br>**Default**: `false` | getConfirmReview(): ?bool | setConfirmReview(?bool confirmReview): void |
| `fields` | [GuideField](../../doc/models/guide-field.md)[]\|null | Optional | This is a container for any-of cases. | getFields(): ?array | setFields(?array fields): void |
| `item` | string\|null | Optional | This is a container for any-of cases. | getItem(): ?string | setItem(?string item): void |
| `scenario` | string([Scenario1Enum](../../doc/models/scenario-1-enum.md))\|null | Optional | This is a container for any-of cases. | getScenario(): ?string | setScenario(?string scenario): void |
| `value` | string\|null | Optional | This is a container for any-of cases. | getValue(): ?string | setValue(?string value): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideFormRequestBuilder;
use TradeGlotLocalConsoleLib\Models\Builders\GuideFieldBuilder;
use TradeGlotLocalConsoleLib\Models\Scenario1Enum;

$guideFormRequest = GuideFormRequestBuilder::init()
    ->confirmReview(false)
    ->fields(
        [
            GuideFieldBuilder::init(
                'item8',
                'value8'
            )->build()
        ]
    )
    ->item(
        'String1'
    )
    ->scenario(
        Scenario1Enum::PREFLIGHT
    )
    ->value(
        'String1'
    )
    ->build();
```

