
# Status 10 Enum

Status.

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `CONNECTED` |
| `DRAFT` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status10Enum;

$status10 = Status10Enum::CONNECTED;
```

