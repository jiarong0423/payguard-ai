
# Due State Enum

Due state.

## Enumeration

`DueStateEnum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `EXPIRED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\DueStateEnum;

$dueState = DueStateEnum::OPEN;
```

