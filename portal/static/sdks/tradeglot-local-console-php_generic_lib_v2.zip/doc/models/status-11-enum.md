
# Status 11 Enum

Status.

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `NOT_CONFIGURED` |
| `DISCONNECTED` |
| `CONNECTED` |
| `ERROR` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status11Enum;

$status11 = Status11Enum::CONNECTED;
```

