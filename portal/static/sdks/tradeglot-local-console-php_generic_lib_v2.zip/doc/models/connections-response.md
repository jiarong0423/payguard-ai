
# Connections Response

Deployment mode only. Never a key, a key's presence, a value or a variable name.

## Structure

`ConnectionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mode` | [`string(ModeEnum)`](../../doc/models/mode-enum.md) | Required | Mode. | getMode(): string | setMode(string mode): void |
| `sandboxReads` | bool\|null | Optional | This is a container for any-of cases. | getSandboxReads(): ?bool | setSandboxReads(?bool sandboxReads): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\ConnectionsResponseBuilder;
use TradeGlotLocalConsoleLib\Models\ModeEnum;

$connectionsResponse = ConnectionsResponseBuilder::init(
    ModeEnum::LOCAL
)
    ->sandboxReads(
        true
    )
    ->build();
```

