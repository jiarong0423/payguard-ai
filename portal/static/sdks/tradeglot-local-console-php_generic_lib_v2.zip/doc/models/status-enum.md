
# Status Enum

Status.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `STRUCTURE_COMPATIBLE` |
| `INCOMPLETE_EVIDENCE` |
| `REJECTED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\StatusEnum;

$status = StatusEnum::REJECTED;
```

