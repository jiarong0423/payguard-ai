
# Signal

Signal.

## Structure

`Signal`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `category` | string\|null | Optional | This is a container for any-of cases. | getCategory(): ?string | setCategory(?string category): void |
| `confidence` | string([ConfidenceEnum](../../doc/models/confidence-enum.md))\|null | Optional | This is a container for any-of cases. | getConfidence(): ?string | setConfidence(?string confidence): void |
| `source` | [`?string(Source2Enum)`](../../doc/models/source-2-enum.md) | Optional | Source. | getSource(): ?string | setSource(?string source): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\SignalBuilder;
use TradeGlotLocalConsoleLib\Models\ConfidenceEnum;
use TradeGlotLocalConsoleLib\Models\Source2Enum;

$signal = SignalBuilder::init()
    ->category(
        'String1'
    )
    ->confidence(
        ConfidenceEnum::HIGH
    )
    ->source(Source2Enum::CHANNEL3)
    ->build();
```

