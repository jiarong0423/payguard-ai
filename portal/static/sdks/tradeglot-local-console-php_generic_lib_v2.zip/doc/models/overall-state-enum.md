
# Overall State Enum

Overall state.

## Enumeration

`OverallStateEnum`

## Fields

| Name |
|  --- |
| `CASE_NOT_ACTIONABLE` |
| `MANUAL_REVIEW` |
| `DUE_DATE_EXPIRED` |
| `ACTION_NOT_AVAILABLE` |
| `NEEDS_INPUT` |
| `READY_FOR_LOCAL_REVIEW` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\OverallStateEnum;

$overallState = OverallStateEnum::DUE_DATE_EXPIRED;
```

