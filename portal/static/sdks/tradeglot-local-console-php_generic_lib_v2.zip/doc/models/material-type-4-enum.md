
# Material Type 4 Enum

## Enumeration

`MaterialType4Enum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |
| `PUBLIC_COURT_ORDER_COPY` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\MaterialType4Enum;

$materialType4 = MaterialType4Enum::OFFICIAL_API_REFERENCE;
```

