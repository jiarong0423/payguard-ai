
# Choice 2 Enum

Choice.

## Enumeration

`Choice2Enum`

## Fields

| Name |
|  --- |
| `CONFIRMED` |
| `NONE_MATCH` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Choice2Enum;

$choice2 = Choice2Enum::CONFIRMED;
```

