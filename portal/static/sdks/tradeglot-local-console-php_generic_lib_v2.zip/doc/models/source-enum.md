
# Source Enum

Source.

## Enumeration

`SourceEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_SANDBOX` |
| `SYNTHETIC_FIXTURE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SourceEnum;

$source = SourceEnum::PAYPAL_SANDBOX;
```

