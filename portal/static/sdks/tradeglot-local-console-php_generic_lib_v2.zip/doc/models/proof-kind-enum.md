
# Proof Kind Enum

Proof kind.

## Enumeration

`ProofKindEnum`

## Fields

| Name |
|  --- |
| `POST_RESPONSE_ONLY` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ProofKindEnum;

$proofKind = ProofKindEnum::POST_RESPONSE_ONLY;
```

