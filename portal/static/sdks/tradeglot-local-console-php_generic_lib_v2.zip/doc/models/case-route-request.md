
# Case Route Request

CaseRouteRequest.

## Structure

`CaseRouteRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `text` | `string` | Required | Text.<br><br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `200` | getText(): string | setText(string text): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\CaseRouteRequestBuilder;

$caseRouteRequest = CaseRouteRequestBuilder::init(
    'text6'
)->build();
```

