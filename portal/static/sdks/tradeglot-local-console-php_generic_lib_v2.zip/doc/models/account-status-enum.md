
# Account Status Enum

Account status.

## Enumeration

`AccountStatusEnum`

## Fields

| Name |
|  --- |
| `MATCH` |
| `MISMATCH` |
| `UNKNOWN` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\AccountStatusEnum;

$accountStatus = AccountStatusEnum::UNKNOWN;
```

