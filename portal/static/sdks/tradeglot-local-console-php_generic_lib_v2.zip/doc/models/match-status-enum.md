
# Match Status Enum

Match status.

## Enumeration

`MatchStatusEnum`

## Fields

| Name |
|  --- |
| `NO_MATCH` |
| `REVIEW_SIGNAL` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\MatchStatusEnum;

$matchStatus = MatchStatusEnum::NO_MATCH;
```

