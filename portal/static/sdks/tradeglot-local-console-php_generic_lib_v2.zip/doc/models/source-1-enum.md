
# Source 1 Enum

Source.

## Enumeration

`Source1Enum`

## Fields

| Name |
|  --- |
| `SESSION_MEMORY` |
| `HOSTED_DEMO` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source1Enum;

$source1 = Source1Enum::SESSION_MEMORY;
```

