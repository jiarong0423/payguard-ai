
# Analysis

Analysis.

## Structure

`Analysis`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reason` | string([Reason5Enum](../../doc/models/reason-5-enum.md))\|null | Optional | This is a container for any-of cases. | getReason(): ?string | setReason(?string reason): void |
| `status` | [`?string(Status8Enum)`](../../doc/models/status-8-enum.md) | Optional | Status. | getStatus(): ?string | setStatus(?string status): void |
| `turn` | `?int` | Optional | Turn. | getTurn(): ?int | setTurn(?int turn): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\AnalysisBuilder;
use TradeGlotLocalConsoleLib\Models\Reason5Enum;
use TradeGlotLocalConsoleLib\Models\Status8Enum;

$analysis = AnalysisBuilder::init()
    ->reason(
        Reason5Enum::INVALID_REPLY
    )
    ->status(Status8Enum::REPLACED)
    ->turn(198)
    ->build();
```

