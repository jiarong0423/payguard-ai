
# Stage 3 Enum

## Enumeration

`Stage3Enum`

## Fields

| Name |
|  --- |
| `FUNNEL` |
| `ECHO_` |
| `FILL` |
| `REVIEW` |
| `DONE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Stage3Enum;

$stage3 = Stage3Enum::DONE;
```

