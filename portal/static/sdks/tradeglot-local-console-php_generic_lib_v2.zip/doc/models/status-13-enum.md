
# Status 13 Enum

Status.

## Enumeration

`Status13Enum`

## Fields

| Name |
|  --- |
| `REFERENCES_FOUND` |
| `EVIDENCE_MISSING` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status13Enum;

$status13 = Status13Enum::REFERENCES_FOUND;
```

