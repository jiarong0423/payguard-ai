
# Material Type Enum

Material type.

## Enumeration

`MaterialTypeEnum`

## Fields

| Name |
|  --- |
| `OFFICIAL_API_REFERENCE` |
| `OFFICIAL_POLICY` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\MaterialTypeEnum;

$materialType = MaterialTypeEnum::OFFICIAL_API_REFERENCE;
```

