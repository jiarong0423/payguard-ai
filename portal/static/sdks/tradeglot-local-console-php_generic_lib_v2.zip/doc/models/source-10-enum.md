
# Source 10 Enum

Source.

## Enumeration

`Source10Enum`

## Fields

| Name |
|  --- |
| `CHANNEL3_LIVE` |
| `CHANNEL3_RECORDED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source10Enum;

$source10 = Source10Enum::CHANNEL3_LIVE;
```

