
# Evidence Receipt

Evidence receipt.

## Structure

`EvidenceReceipt`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `action` | [`?string(ActionEnum)`](../../doc/models/action-enum.md) | Optional | Action. | getAction(): ?string | setAction(?string action): void |
| `environment` | [`?string(EnvironmentEnum)`](../../doc/models/environment-enum.md) | Optional | Environment. | getEnvironment(): ?string | setEnvironment(?string environment): void |
| `evidenceClass` | [`?string(EvidenceClass3Enum)`](../../doc/models/evidence-class-3-enum.md) | Optional | Evidence class. | getEvidenceClass(): ?string | setEvidenceClass(?string evidenceClass): void |
| `externalSend` | [`?string(ExternalSend1Enum)`](../../doc/models/external-send-1-enum.md) | Optional | External send. | getExternalSend(): ?string | setExternalSend(?string externalSend): void |
| `invoiceId` | string\|null | Optional | This is a container for any-of cases. | getInvoiceId(): ?string | setInvoiceId(?string invoiceId): void |
| `observedAt` | `?string` | Optional | Observed at.<br><br>**Constraints**: *Minimum Length*: `20`, *Maximum Length*: `27` | getObservedAt(): ?string | setObservedAt(?string observedAt): void |
| `paypalDebugId` | string\|null | Optional | This is a container for any-of cases. | getPaypalDebugId(): ?string | setPaypalDebugId(?string paypalDebugId): void |
| `proofKind` | [`?string(ProofKindEnum)`](../../doc/models/proof-kind-enum.md) | Optional | Proof kind. | getProofKind(): ?string | setProofKind(?string proofKind): void |
| `schemaVersion` | [`?int(SchemaVersion1Enum)`](../../doc/models/schema-version-1-enum.md) | Optional | Schema version. | getSchemaVersion(): ?int | setSchemaVersion(?int schemaVersion): void |
| `separateGetReadback` | `?bool` | Optional | Separate get readback. | getSeparateGetReadback(): ?bool | setSeparateGetReadback(?bool separateGetReadback): void |
| `status` | [`?string(Status10Enum)`](../../doc/models/status-10-enum.md) | Optional | Status. | getStatus(): ?string | setStatus(?string status): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\EvidenceReceiptBuilder;
use TradeGlotLocalConsoleLib\Models\ActionEnum;
use TradeGlotLocalConsoleLib\Models\EnvironmentEnum;
use TradeGlotLocalConsoleLib\Models\EvidenceClass3Enum;
use TradeGlotLocalConsoleLib\Models\ExternalSend1Enum;

$evidenceReceipt = EvidenceReceiptBuilder::init()
    ->action(ActionEnum::OAUTH_CONNECT)
    ->environment(EnvironmentEnum::SANDBOX)
    ->evidenceClass(EvidenceClass3Enum::AUTHENTIC_SANDBOX_RESPONSE)
    ->externalSend(ExternalSend1Enum::FROZEN)
    ->invoiceId(
        'String1'
    )
    ->build();
```

