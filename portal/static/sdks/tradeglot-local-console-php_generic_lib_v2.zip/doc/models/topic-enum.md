
# Topic Enum

Topic.

## Enumeration

`TopicEnum`

## Fields

| Name |
|  --- |
| `PAYMENT_NOTICE` |
| `ORDER_DETAILS_REQUEST` |
| `ORDER_DETAILS_PROVIDED` |
| `DELIVERY_NOTICE` |
| `REFUND_REQUEST` |
| `OTHER` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\TopicEnum;

$topic = TopicEnum::ORDER_DETAILS_PROVIDED;
```

