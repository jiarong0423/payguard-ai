
# Match Type Enum

Match type.

## Enumeration

`MatchTypeEnum`

## Fields

| Name |
|  --- |
| `EXACT` |
| `CLOSE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\MatchTypeEnum;

$matchType = MatchTypeEnum::EXACT;
```

