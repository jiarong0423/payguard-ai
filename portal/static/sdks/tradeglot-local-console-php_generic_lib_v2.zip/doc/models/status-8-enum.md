
# Status 8 Enum

Status.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `ANALYSING` |
| `REPLACED` |
| `KEPT` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status8Enum;

$status8 = Status8Enum::REPLACED;
```

