
# Mode Enum

Mode.

## Enumeration

`ModeEnum`

## Fields

| Name |
|  --- |
| `LOCAL` |
| `HOSTED_DEMO` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ModeEnum;

$mode = ModeEnum::LOCAL;
```

