
# Chooser Enum

Chooser.

## Enumeration

`ChooserEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `KEYWORD` |
| `MODEL` |
| `KEYWORD_FALLBACK` |
| `FORM` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ChooserEnum;

$chooser = ChooserEnum::FORM;
```

