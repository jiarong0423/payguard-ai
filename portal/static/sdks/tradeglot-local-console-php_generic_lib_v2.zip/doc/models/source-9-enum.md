
# Source 9 Enum

Source.

## Enumeration

`Source9Enum`

## Fields

| Name |
|  --- |
| `WORDS` |
| `WORDS_PENDING` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source9Enum;

$source9 = Source9Enum::WORDS;
```

