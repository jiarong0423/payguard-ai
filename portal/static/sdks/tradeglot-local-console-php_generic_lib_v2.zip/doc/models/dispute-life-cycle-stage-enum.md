
# Dispute Life Cycle Stage Enum

Dispute life cycle stage.

## Enumeration

`DisputeLifeCycleStageEnum`

## Fields

| Name |
|  --- |
| `INQUIRY` |
| `CHARGEBACK` |
| `PRE_ARBITRATION` |
| `ARBITRATION` |
| `UNKNOWN` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\DisputeLifeCycleStageEnum;

$disputeLifeCycleStage = DisputeLifeCycleStageEnum::INQUIRY;
```

