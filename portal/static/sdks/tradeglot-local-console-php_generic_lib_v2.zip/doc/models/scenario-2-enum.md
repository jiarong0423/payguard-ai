
# Scenario 2 Enum

Scenario.

## Enumeration

`Scenario2Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Scenario2Enum;

$scenario2 = Scenario2Enum::VELOCITY;
```

