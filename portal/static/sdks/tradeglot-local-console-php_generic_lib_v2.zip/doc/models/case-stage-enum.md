
# Case Stage Enum

Case stage.

## Enumeration

`CaseStageEnum`

## Fields

| Name |
|  --- |
| `PROCEDURAL_ORDER` |
| `NOT_APPLICABLE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CaseStageEnum;

$caseStage = CaseStageEnum::PROCEDURAL_ORDER;
```

