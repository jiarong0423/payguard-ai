
# Status 2 Enum

Status.

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `OFF` |
| `SIGNAL` |
| `NOT_SENT` |
| `UNAVAILABLE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status2Enum;

$status2 = Status2Enum::NOT_SENT;
```

