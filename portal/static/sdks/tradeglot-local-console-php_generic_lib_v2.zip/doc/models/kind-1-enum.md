
# Kind 1 Enum

Kind.

## Enumeration

`Kind1Enum`

## Fields

| Name |
|  --- |
| `MESSAGE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Kind1Enum;

$kind1 = Kind1Enum::MESSAGE;
```

