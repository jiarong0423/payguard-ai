
# Status 5 Enum

Status.

## Enumeration

`Status5Enum`

## Fields

| Name |
|  --- |
| `MANUAL_REVIEW` |
| `REVIEW_EVIDENCE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status5Enum;

$status5 = Status5Enum::MANUAL_REVIEW;
```

