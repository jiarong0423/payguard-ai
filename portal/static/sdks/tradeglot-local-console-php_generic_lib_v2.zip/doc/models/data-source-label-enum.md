
# Data Source Label Enum

Data source label.

## Enumeration

`DataSourceLabelEnum`

## Fields

| Name |
|  --- |
| `SANDBOX` |
| `FIXTURE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\DataSourceLabelEnum;

$dataSourceLabel = DataSourceLabelEnum::SANDBOX;
```

