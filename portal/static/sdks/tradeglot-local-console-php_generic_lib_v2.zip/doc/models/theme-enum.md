
# Theme Enum

Theme.

## Enumeration

`ThemeEnum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ThemeEnum;

$theme = ThemeEnum::SOURCE_COMPLIANCE;
```

