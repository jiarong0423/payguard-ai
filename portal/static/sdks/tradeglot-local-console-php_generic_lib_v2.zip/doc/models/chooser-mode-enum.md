
# Chooser Mode Enum

Chooser mode.

## Enumeration

`ChooserModeEnum`

## Fields

| Name |
|  --- |
| `KEYWORD` |
| `GEMINI` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ChooserModeEnum;

$chooserMode = ChooserModeEnum::KEYWORD;
```

