
# Guide Analysis

GuideAnalysis.

## Structure

`GuideAnalysis`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reason` | string([Reason5Enum](../../doc/models/reason-5-enum.md)) | Required | This is a container for any-of cases. | getReason(): string | setReason(string reason): void |
| `status` | [`string(Status8Enum)`](../../doc/models/status-8-enum.md) | Required | Status. | getStatus(): string | setStatus(string status): void |
| `turn` | `int` | Required | Turn. | getTurn(): int | setTurn(int turn): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideAnalysisBuilder;
use TradeGlotLocalConsoleLib\Models\Reason5Enum;
use TradeGlotLocalConsoleLib\Models\Status8Enum;

$guideAnalysis = GuideAnalysisBuilder::init(
    Reason5Enum::INVALID_REPLY,
    Status8Enum::ANALYSING,
    236
)->build();
```

