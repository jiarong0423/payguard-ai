
# Stage 2 Enum

Stage.

## Enumeration

`Stage2Enum`

## Fields

| Name |
|  --- |
| `SOURCE_COMPLIANCE` |
| `VELOCITY_GUARD` |
| `DISPUTE_MEDIATION` |
| `GUIDE` |
| `STUDIO_AGENT` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Stage2Enum;

$stage2 = Stage2Enum::STUDIO_AGENT;
```

