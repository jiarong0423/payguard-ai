
# Guide Dropped

GuideDropped.

## Structure

`GuideDropped`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `item` | `string` | Required | Item. | getItem(): string | setItem(string item): void |
| `reason` | [`string(Reason6Enum)`](../../doc/models/reason-6-enum.md) | Required | Reason. | getReason(): string | setReason(string reason): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideDroppedBuilder;
use TradeGlotLocalConsoleLib\Models\Reason6Enum;

$guideDropped = GuideDroppedBuilder::init(
    'item6',
    Reason6Enum::OTHER_PARTY
)->build();
```

