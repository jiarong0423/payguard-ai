
# Form

Form.

## Structure

`Form`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `kind` | [`?string(Kind2Enum)`](../../doc/models/kind-2-enum.md) | Optional | Kind. | getKind(): ?string | setKind(?string kind): void |
| `options` | [`?(GuideOption[])`](../../doc/models/guide-option.md) | Optional | Options. | getOptions(): ?array | setOptions(?array options): void |
| `placeholder` | string\|null | Optional | This is a container for any-of cases. | getPlaceholder(): ?string | setPlaceholder(?string placeholder): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\FormBuilder;
use TradeGlotLocalConsoleLib\Models\Kind2Enum;
use TradeGlotLocalConsoleLib\Models\Builders\GuideOptionBuilder;

$form = FormBuilder::init()
    ->kind(Kind2Enum::TEXT)
    ->options(
        [
            GuideOptionBuilder::init(
                'label2',
                'value4'
            )->build(),
            GuideOptionBuilder::init(
                'label2',
                'value4'
            )->build(),
            GuideOptionBuilder::init(
                'label2',
                'value4'
            )->build()
        ]
    )
    ->placeholder(
        'String9'
    )
    ->build();
```

