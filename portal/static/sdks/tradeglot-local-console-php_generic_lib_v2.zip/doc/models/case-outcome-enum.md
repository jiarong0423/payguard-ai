
# Case Outcome Enum

## Enumeration

`CaseOutcomeEnum`

## Fields

| Name |
|  --- |
| `SETTLEMENT_APPROVAL_NOT_FINAL_MERITS` |
| `ARBITRATION_COMPELLED_UNDERLYING_MERITS_NOT_DECIDED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CaseOutcomeEnum;

$caseOutcome = CaseOutcomeEnum::SETTLEMENT_APPROVAL_NOT_FINAL_MERITS;
```

