
# Inject Request

InjectRequest.

## Structure

`InjectRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `scenario` | [`string(Scenario5Enum)`](../../doc/models/scenario-5-enum.md) | Required | Scenario. | getScenario(): string | setScenario(string scenario): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\InjectRequestBuilder;
use TradeGlotLocalConsoleLib\Models\Scenario5Enum;

$injectRequest = InjectRequestBuilder::init(
    Scenario5Enum::BURST
)->build();
```

