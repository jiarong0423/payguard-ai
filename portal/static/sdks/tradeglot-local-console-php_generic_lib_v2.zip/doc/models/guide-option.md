
# Guide Option

GuideOption.

## Structure

`GuideOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `label` | `string` | Required | Label. | getLabel(): string | setLabel(string label): void |
| `value` | `string` | Required | Value. | getValue(): string | setValue(string value): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideOptionBuilder;

$guideOption = GuideOptionBuilder::init(
    'label2',
    'value4'
)->build();
```

