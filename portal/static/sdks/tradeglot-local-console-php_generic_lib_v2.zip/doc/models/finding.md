
# Finding

Finding.

## Structure

`Finding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `category` | [`string(CategoryEnum)`](../../doc/models/category-enum.md) | Required | Category. | getCategory(): string | setCategory(string category): void |
| `code` | `string` | Required, Constant | Code.<br><br>**Value**: `'keyword_requires_policy_review'` | getCode(): string | setCode(string code): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\FindingBuilder;
use TradeGlotLocalConsoleLib\Models\CategoryEnum;

$finding = FindingBuilder::init(
    CategoryEnum::UNSUPPORTED_FINANCIAL_PROMISE
)->build();
```

