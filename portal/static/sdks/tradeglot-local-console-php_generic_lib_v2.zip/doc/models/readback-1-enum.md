
# Readback 1 Enum

Readback.

## Enumeration

`Readback1Enum`

## Fields

| Name |
|  --- |
| `PROVIDE_EVIDENCE_PREVIEW` |
| `PROVIDE_EVIDENCE_SUBMITTED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Readback1Enum;

$readback1 = Readback1Enum::PROVIDE_EVIDENCE_PREVIEW;
```

