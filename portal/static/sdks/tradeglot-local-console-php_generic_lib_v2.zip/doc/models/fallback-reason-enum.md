
# Fallback Reason Enum

## Enumeration

`FallbackReasonEnum`

## Fields

| Name |
|  --- |
| `BUDGET` |
| `PROVIDER_ERROR` |
| `INVALID_REPLY` |
| `LATE` |
| `NO_ITEMS` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\FallbackReasonEnum;

$fallbackReason = FallbackReasonEnum::NO_ITEMS;
```

