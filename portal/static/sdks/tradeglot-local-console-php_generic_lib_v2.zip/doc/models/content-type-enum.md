
# Content Type Enum

Content type.

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_IMAGEJPEG` |
| `ENUM_IMAGEGIF` |
| `ENUM_IMAGEPNG` |
| `ENUM_APPLICATIONPDF` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ContentTypeEnum;

$contentType = ContentTypeEnum::ENUM_IMAGEPNG;
```

