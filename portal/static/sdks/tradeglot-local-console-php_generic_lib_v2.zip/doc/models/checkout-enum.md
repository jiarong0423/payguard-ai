
# Checkout Enum

Checkout.

## Enumeration

`CheckoutEnum`

## Fields

| Name |
|  --- |
| `PAYPAL_ACCOUNT` |
| `GUEST_CARD` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\CheckoutEnum;

$checkout = CheckoutEnum::PAYPAL_ACCOUNT;
```

