
# Decision Date Status Enum

Decision date status.

## Enumeration

`DecisionDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_STATED_IN_REVIEWED_DOCUMENT` |
| `NOT_APPLICABLE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\DecisionDateStatusEnum;

$decisionDateStatus = DecisionDateStatusEnum::DOCUMENT_STATED;
```

