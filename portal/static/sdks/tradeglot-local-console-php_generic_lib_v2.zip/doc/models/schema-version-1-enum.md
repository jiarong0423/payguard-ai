
# Schema Version 1 Enum

Schema version.

## Enumeration

`SchemaVersion1Enum`

## Fields

| Name |
|  --- |
| `ENUM_1` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SchemaVersion1Enum;

$schemaVersion1 = SchemaVersion1Enum::ENUM_1;
```

