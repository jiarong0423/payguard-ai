
# Evidence Class Enum

Evidence class.

## Enumeration

`EvidenceClassEnum`

## Fields

| Name |
|  --- |
| `AUTHENTIC_SANDBOX_RESPONSE` |
| `SYNTHETIC_TEST_RESPONSE` |
| `SYNTHETIC_FIXTURE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\EvidenceClassEnum;

$evidenceClass = EvidenceClassEnum::SYNTHETIC_FIXTURE;
```

