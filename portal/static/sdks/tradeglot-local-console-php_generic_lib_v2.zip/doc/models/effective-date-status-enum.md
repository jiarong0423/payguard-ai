
# Effective Date Status Enum

Effective date status.

## Enumeration

`EffectiveDateStatusEnum`

## Fields

| Name |
|  --- |
| `DOCUMENT_STATED` |
| `NOT_VERIFIED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\EffectiveDateStatusEnum;

$effectiveDateStatus = EffectiveDateStatusEnum::DOCUMENT_STATED;
```

