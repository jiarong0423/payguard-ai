
# Schema Version Enum

Schema version.

## Enumeration

`SchemaVersionEnum`

## Fields

| Name |
|  --- |
| `ENUM_PAYGUARDTIME_EVIDENCEV1` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\SchemaVersionEnum;

$schemaVersion = SchemaVersionEnum::ENUM_PAYGUARDTIME_EVIDENCEV1;
```

