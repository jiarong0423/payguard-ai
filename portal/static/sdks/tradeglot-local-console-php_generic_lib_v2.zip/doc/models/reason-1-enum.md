
# Reason 1 Enum

Reason.

## Enumeration

`Reason1Enum`

## Fields

| Name |
|  --- |
| `CATALOGUE_MATCH` |
| `LIVE_CATALOGUE_MATCH` |
| `DIGITAL_WORD` |
| `SERVICE_WORD` |
| `FILTERED_CONFLICT` |
| `NO_CLOSE_MATCH` |
| `NOTHING_TO_MATCH` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Reason1Enum;

$reason1 = Reason1Enum::DIGITAL_WORD;
```

