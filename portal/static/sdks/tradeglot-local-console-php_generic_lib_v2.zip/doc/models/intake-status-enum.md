
# Intake Status Enum

Intake status.

## Enumeration

`IntakeStatusEnum`

## Fields

| Name |
|  --- |
| `READY_FOR_LOCAL_RULES` |
| `MANUAL_REVIEW` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\IntakeStatusEnum;

$intakeStatus = IntakeStatusEnum::READY_FOR_LOCAL_RULES;
```

