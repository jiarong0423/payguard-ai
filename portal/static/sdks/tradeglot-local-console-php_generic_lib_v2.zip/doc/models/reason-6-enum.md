
# Reason 6 Enum

Reason.

## Enumeration

`Reason6Enum`

## Fields

| Name |
|  --- |
| `OTHER_PARTY` |
| `INFERRED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Reason6Enum;

$reason6 = Reason6Enum::OTHER_PARTY;
```

