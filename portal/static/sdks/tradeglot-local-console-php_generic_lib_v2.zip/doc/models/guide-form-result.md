
# Guide Form Result

GuideFormResult.

## Structure

`GuideFormResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `item` | `string` | Required | Item. | getItem(): string | setItem(string item): void |
| `valid` | `bool` | Required | Valid. | getValid(): bool | setValid(bool valid): void |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Builders\GuideFormResultBuilder;

$guideFormResult = GuideFormResultBuilder::init(
    'item2',
    false
)->build();
```

