
# Account Type Enum

Account type.

## Enumeration

`AccountTypeEnum`

## Fields

| Name |
|  --- |
| `PERSONAL` |
| `BUSINESS` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\AccountTypeEnum;

$accountType = AccountTypeEnum::PERSONAL;
```

