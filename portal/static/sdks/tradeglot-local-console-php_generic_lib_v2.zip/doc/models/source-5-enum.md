
# Source 5 Enum

Source.

## Enumeration

`Source5Enum`

## Fields

| Name |
|  --- |
| `PROVIDER` |
| `SELLER_PROVIDED_UNVERIFIED` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Source5Enum;

$source5 = Source5Enum::PROVIDER;
```

