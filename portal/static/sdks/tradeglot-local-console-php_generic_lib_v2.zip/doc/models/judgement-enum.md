
# Judgement Enum

Judgement.

## Enumeration

`JudgementEnum`

## Fields

| Name |
|  --- |
| `NOT_MADE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\JudgementEnum;

$judgement = JudgementEnum::NOT_MADE;
```

