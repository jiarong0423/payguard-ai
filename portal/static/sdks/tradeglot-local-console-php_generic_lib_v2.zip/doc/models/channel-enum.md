
# Channel Enum

Channel.

## Enumeration

`ChannelEnum`

## Fields

| Name |
|  --- |
| `EMAIL` |
| `PRIVATE_MESSAGE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ChannelEnum;

$channel = ChannelEnum::EMAIL;
```

