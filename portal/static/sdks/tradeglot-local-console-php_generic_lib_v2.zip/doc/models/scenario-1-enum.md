
# Scenario 1 Enum

## Enumeration

`Scenario1Enum`

## Fields

| Name |
|  --- |
| `PREFLIGHT` |
| `VELOCITY` |
| `DISPUTE` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Scenario1Enum;

$scenario1 = Scenario1Enum::VELOCITY;
```

