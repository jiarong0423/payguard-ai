
# Direction Enum

Direction.

## Enumeration

`DirectionEnum`

## Fields

| Name |
|  --- |
| `INBOUND` |
| `OUTBOUND` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\DirectionEnum;

$direction = DirectionEnum::INBOUND;
```

