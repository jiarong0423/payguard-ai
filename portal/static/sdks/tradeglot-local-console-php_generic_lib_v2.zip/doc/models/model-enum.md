
# Model Enum

Model.

## Enumeration

`ModelEnum`

## Fields

| Name |
|  --- |
| `ENUM_GEMINI38FLASH` |
| `NVIDIANEMOTRON3NANO4B` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\ModelEnum;

$model = ModelEnum::ENUM_GEMINI38FLASH;
```

