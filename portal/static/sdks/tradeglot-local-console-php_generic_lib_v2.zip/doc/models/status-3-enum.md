
# Status 3 Enum

Status.

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `OPEN` |
| `WAITING_FOR_SELLER_RESPONSE` |
| `WAITING_FOR_BUYER_RESPONSE` |
| `UNDER_REVIEW` |
| `RESOLVED` |
| `CLOSED` |
| `UNKNOWN` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\Status3Enum;

$status3 = Status3Enum::OPEN;
```

