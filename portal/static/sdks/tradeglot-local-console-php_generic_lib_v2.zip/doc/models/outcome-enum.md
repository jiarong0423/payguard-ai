
# Outcome Enum

Outcome.

## Enumeration

`OutcomeEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ERROR` |

## Example

```php
use TradeGlotLocalConsoleLib\Models\OutcomeEnum;

$outcome = OutcomeEnum::OK;
```

